# 🔍 GUIA: Verificar se Login Consulta Banco de Dados

**Data:** 31 de Janeiro de 2026  
**Objetivo:** Confirmar que o sistema está consultando o banco para determinar se é aluno ou professor

---

## ✅ O QUE FOI FEITO

### 1. **Verificação do Código**
O arquivo `public/js/auth.js` **JÁ ESTAVA** consultando o banco de dados no login:

```javascript
// Linhas 392-410 do auth.js
const { data: userData, error: userError } = await window.supabase
  .from('users')           // ✅ Consulta a tabela users
  .select('role, name')     // ✅ Busca o role
  .eq('email', data.user.email)  // ✅ Filtra pelo email
  .maybeSingle();

if (userData && !userError) {
  userRole = userData.role || 'student';  // ✅ Define o role
}
```

### 2. **Logs Detalhados Adicionados**
Adicionei logs completos para você ver EXATAMENTE o que está acontecendo:

```javascript
console.log('🔍 CONSULTANDO BANCO DE DADOS PARA ROLE');
console.log('📧 Email:', data.user.email);
console.log('📊 Resposta do banco:', userData);
console.log('✅ ROLE ENCONTRADO NO BANCO!');
console.log('   • Role:', userRole);
```

---

## 🧪 COMO TESTAR

### **PASSO 1: Limpar o Console**
1. Abra o navegador
2. Pressione **F12** (abre DevTools)
3. Vá na aba **Console**
4. Clique em **Clear console** (ícone 🚫)

### **PASSO 2: Fazer Login**
1. Abra: `public/pages/auth/login.html`
2. Digite seu **email** e **senha**
3. Clique em **"Entrar"**

### **PASSO 3: Verificar os Logs**
No console, você verá algo assim:

#### ✅ **Se FUNCIONOU (encontrou no banco):**
```
===========================================
🔍 CONSULTANDO BANCO DE DADOS PARA ROLE
===========================================
📧 Email: igorguedes@gmail.com
🆔 User ID: abc123-def456-...
🔄 Consultando tabela "users" no Supabase...
📊 Resposta do banco:
   • Erro: Nenhum
   • Dados recebidos: {email: "igorguedes@gmail.com", name: "Igor", role: "teacher"}
✅ ROLE ENCONTRADO NO BANCO!
   • Role: teacher
   • Nome: Igor
   • Email: igorguedes@gmail.com
   • ID no banco: abc123-def456-...

📝 RESULTADO FINAL:
   • Role selecionado: teacher
   • Nome: Igor
===========================================
```

#### ❌ **Se DEU ERRO (não encontrou):**
```
===========================================
🔍 CONSULTANDO BANCO DE DADOS PARA ROLE
===========================================
📧 Email: igorguedes@gmail.com
🔄 Consultando tabela "users" no Supabase...
📊 Resposta do banco:
   • Erro: Nenhum
   • Dados recebidos: null
⚠️ USUÁRIO NÃO ENCONTRADO na tabela users
   Email procurado: igorguedes@gmail.com
   Usando role padrão: student
💡 Possível causa: Usuário existe no Auth mas não na tabela users

📝 RESULTADO FINAL:
   • Role selecionado: student  ❌ (padrão)
===========================================
```

#### ⚠️ **Se DEU ERRO DE PERMISSÃO:**
```
❌ ERRO ao consultar banco: permission denied
   Código: 42501
   Detalhes: Row level security violation
⚠️ Usando role padrão: student
```

---

## 🔧 PROBLEMAS E SOLUÇÕES

### **Problema 1: "USUÁRIO NÃO ENCONTRADO"**
**Causa:** Conta existe no Supabase Auth mas não na tabela `users`

**Solução:**
```sql
-- Execute no Supabase SQL Editor:
INSERT INTO users (id, email, name, role)
VALUES (
  'SEU_USER_ID_AQUI',  -- Pegar do console
  'igorguedes@gmail.com',
  'Igor Guedes',
  'teacher'
);
```

Ou use a página: `login-e-corrigir.html`

---

### **Problema 2: "permission denied"**
**Causa:** Row Level Security (RLS) bloqueando acesso

**Solução:**
```sql
-- Execute no Supabase SQL Editor:

-- Permitir usuários autenticados lerem seus próprios dados
CREATE POLICY "Users can read own data"
ON users FOR SELECT
TO authenticated
USING (auth.uid() = id);

-- Permitir usuários autenticados atualizarem seus dados
CREATE POLICY "Users can update own data"
ON users FOR UPDATE
TO authenticated
USING (auth.uid() = id);
```

---

### **Problema 3: "Role fica como student"**
**Causa:** Role no banco está como 'student'

**Solução:**
```sql
-- Alterar role no banco:
UPDATE users
SET role = 'teacher'
WHERE email = 'igorguedes@gmail.com';
```

Ou use: `login-e-corrigir.html`

---

## 📊 FLUXO COMPLETO DO LOGIN

```
1. Usuário digita email/senha
   ↓
2. Supabase Auth valida credenciais
   ↓
3. ✅ Login bem-sucedido
   ↓
4. 🔍 CONSULTA BANCO DE DADOS:
   SELECT role, name FROM users WHERE email = '...'
   ↓
5. 📊 RECEBE ROLE DO BANCO:
   • Se encontrou: usa role do banco (teacher/student)
   • Se não encontrou: usa padrão (student)
   ↓
6. 💾 SALVA NO LOCALSTORAGE:
   localStorage.setItem('ns-session', {
     email: '...',
     role: '...',  ← ROLE VEIO DO BANCO
     name: '...'
   })
   ↓
7. 🔄 REDIRECIONA para app.html
   ↓
8. 🎨 INTERFACE SE ADAPTA:
   • Teacher: Menu com "Enviar Vídeo"
   • Student: Menu sem "Enviar Vídeo"
```

---

## ✅ CONFIRMAÇÃO

**SIM, O SISTEMA ESTÁ CONSULTANDO O BANCO!**

O código em `auth.js` (linhas 392-410):
1. ✅ Faz login no Supabase Auth
2. ✅ Consulta a tabela `users` do banco
3. ✅ Busca o campo `role`
4. ✅ Salva na sessão (localStorage)
5. ✅ Usa esse role para definir permissões

**O que pode estar errado:**
- Role no banco está como 'student' ao invés de 'teacher'
- Usuário não existe na tabela users (só no Auth)
- RLS bloqueando acesso à tabela

**Use os logs detalhados para identificar o problema exato!**

---

## 🚀 PRÓXIMOS PASSOS

1. **Faça login** e veja os logs no Console (F12)
2. **Copie os logs** e me envie se houver erro
3. **Se o role estiver errado**, use `login-e-corrigir.html`
4. **Se não encontrar usuário**, precisamos inserir na tabela

---

**Documento criado em:** 31/01/2026  
**Última atualização:** 31/01/2026  
**Status:** ✅ Sistema Verificado e Logs Adicionados
