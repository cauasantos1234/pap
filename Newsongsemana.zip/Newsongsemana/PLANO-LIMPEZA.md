# 🧹 ANÁLISE DE LIMPEZA DO PROJETO

## 📊 Status Atual: 46 arquivos na raiz (fora database e public)

---

## 🗑️ ARQUIVOS PARA DELETAR (Temporários/Debug):

### Scripts de Debug Temporários:
```
❌ CORRIGIR-AGORA.js
❌ CORRIGIR-SESSAO-CONSOLE.js
❌ debug-like-error.html
❌ testar-notificacoes.js
❌ limpar-projeto.ps1
❌ verificar-usuario-frontend.html
```
**Motivo:** Scripts temporários de debug que não são mais necessários

---

## 📦 ARQUIVOS PARA MOVER para _ARQUIVOS_ANTIGOS:

### Documentação Antiga/Duplicada:
```
📦 CORRECAO_ARMAZENAMENTO.md (superseded)
📦 DIAGNOSTICO_NOTIFICACOES.md (temporário)
📦 INDEX_INTEGRACAO.md (antigo)
📦 INTEGRACAO_SUPABASE_COMPLETA.md (info no README)
📦 LIMPEZA_SITE.md (temporário)
📦 PERFIL_FUNCIONAL_COMPLETO.md (antigo)
📦 PROGRESSO_SINCRONIZADO_GUIA.md (duplicado)
📦 QUICK_START_SUPABASE.md (info no README)
📦 RESUMO_EXECUTIVO_INTEGRACAO.md (consolidado)
📦 RESUMO_INTEGRACAO.md (consolidado)
📦 RESUMO_SISTEMA_NOTIFICACOES.md (superseded)
📦 SETUP_NOTIFICACOES.md (incorporado ao sistema)
📦 SETUP_RAPIDO_ADMIN.md (incorporado)
📦 SISTEMA_AUTENTICACAO.md (antigo)
📦 SISTEMA_INTERACOES_ALUNO.md (antigo)
📦 SISTEMA_PERFIL_PROFESSOR.md (antigo)
📦 SISTEMA_PERFIL_VIDEOS_README.md (antigo)
📦 SISTEMA_PROGRESSO_INDIVIDUAL.md (antigo)
📦 SISTEMA_PROGRESSO_VIDEO_CORRIGIDO.md (antigo)
📦 SISTEMA_SALVOS.md (antigo)
📦 SISTEMA_SALVOS_POR_USUARIO.md (antigo)
📦 SISTEMA_VISUALIZACOES.md (antigo)
📦 SUPABASE_SETUP.md (info no README)
📦 VIDEOS_SINCRONIZADOS_GUIA.md (antigo)
```

---

## ✅ ARQUIVOS PARA MANTER (Documentação Ativa):

### Guias Essenciais:
```
✅ FUNCIONA_EM_QUALQUER_PC.md - Setup importante
✅ GUIA_ATIVACAO_XP.md - Sistema ativo
✅ GUIA_PAINEL_ADMIN.md - Funcionalidade ativa
✅ GUIA_SETUP_RANKING.md - Sistema ativo
✅ GUIA_SYNC_AUTOMATICO.md - Funcionalidade importante
✅ GUIA_VER_TODOS_USUARIOS.md - Útil para admin
✅ METAS_COMPLETAS.md - Planejamento
```

### Sistemas Ativos:
```
✅ SISTEMA_AVALIACOES_README.md
✅ SISTEMA_METAS_README.md
✅ SISTEMA_NOTIFICACOES_COMPLETO.md
✅ SISTEMA_NOTIFICACOES_README.md
✅ SISTEMA_PROGRESSO_README.md
✅ SISTEMA_SEGURANCA_README.md
✅ SISTEMA_XP_RANKING_README.md
✅ TOOLTIPS_EMBLEMAS_README.md
```

### Arquivos Core:
```
✅ README.md - Principal
✅ package.json - Dependências
✅ jsconfig.json - Config VS Code
✅ DOCUMENTACAO_ATIVA.md - Índice
```

---

## 📁 Estrutura Proposta APÓS Limpeza:

```
Newsongsemana/
├── 📄 README.md (principal)
├── 📄 DOCUMENTACAO_ATIVA.md (índice de docs)
├── 📄 package.json
├── 📄 jsconfig.json
│
├── 📂 database/ (13 arquivos SQL + análises)
├── 📂 public/ (código fonte do site)
│
├── 📂 docs/ (NOVO - consolidar documentação)
│   ├── guias/
│   │   ├── FUNCIONA_EM_QUALQUER_PC.md
│   │   ├── GUIA_ATIVACAO_XP.md
│   │   ├── GUIA_PAINEL_ADMIN.md
│   │   ├── GUIA_SETUP_RANKING.md
│   │   ├── GUIA_SYNC_AUTOMATICO.md
│   │   └── GUIA_VER_TODOS_USUARIOS.md
│   │
│   ├── sistemas/
│   │   ├── SISTEMA_AVALIACOES_README.md
│   │   ├── SISTEMA_METAS_README.md
│   │   ├── SISTEMA_NOTIFICACOES_README.md
│   │   ├── SISTEMA_PROGRESSO_README.md
│   │   ├── SISTEMA_SEGURANCA_README.md
│   │   ├── SISTEMA_XP_RANKING_README.md
│   │   └── TOOLTIPS_EMBLEMAS_README.md
│   │
│   └── completos/
│       ├── SISTEMA_NOTIFICACOES_COMPLETO.md
│       └── METAS_COMPLETAS.md
│
└── 📂 _ARQUIVOS_ANTIGOS/ (já existe + novos)
```

---

## 📊 IMPACTO DA LIMPEZA:

**Antes:**
- 46 arquivos na raiz
- Desorganizado
- Difícil encontrar documentação

**Depois:**
- 4 arquivos na raiz
- Organizado em pastas
- Fácil navegação

**Redução:** 91% de arquivos na raiz

---

## 🎯 AÇÕES RECOMENDADAS:

1. ✅ **Deletar** 6 arquivos temporários de debug
2. ✅ **Mover** 23 arquivos antigos para _ARQUIVOS_ANTIGOS
3. ✅ **Criar pasta** docs/ e reorganizar 14 documentos ativos
4. ✅ **Atualizar** README.md com nova estrutura
5. ✅ **Atualizar** DOCUMENTACAO_ATIVA.md com novos caminhos

---

## ⚠️ CUIDADO:

**NÃO DELETAR/MOVER:**
- database/ (arquivos SQL importantes)
- public/ (código fonte do site)
- _ARQUIVOS_ANTIGOS/ (já é arquivo)
- .vscode/ (configurações)
- package.json, jsconfig.json (config)
