// video-progress-tracker.js - Rastreia e salva progresso de vídeos no Supabase
(function() {
  console.log('🎬 Video Progress Tracker carregando...');

  // Aguardar Supabase API carregar
  function waitForSupabase(callback) {
    if (window.SupabaseAPI && window.SupabaseAPI.isReady()) {
      callback();
    } else {
      setTimeout(() => waitForSupabase(callback), 100);
    }
  }

  // Salvar progresso de um vídeo específico
  async function saveVideoProgress(videoId, progressData) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      
      // Obter sessão
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError || !session) {
        console.warn('Usuário não autenticado');
        return { success: false, error: 'Usuário não autenticado' };
      }

      const userId = session.user.id;

      // Preparar dados para salvar
      const dataToSave = {
        user_id: userId,
        video_id: videoId,  // ← IMPORTANTE: video_id é obrigatório!
        progress_percentage: Math.floor(progressData.percentage || 0),
        completed: (progressData.percentage || 0) >= 90,
        last_watched_at: new Date().toISOString()
      };

      // Adicionar campos opcionais se disponíveis
      if (progressData.instrument) dataToSave.instrument = progressData.instrument;
      if (progressData.module) dataToSave.module = progressData.module;
      if (progressData.lessonId) dataToSave.lesson_id = progressData.lessonId;

      console.log('💾 Salvando progresso do vídeo:', videoId, dataToSave);

      // Upsert (insert ou update baseado em user_id + video_id)
      const { data, error } = await supabase
        .from('user_progress')
        .upsert(dataToSave, {
          onConflict: 'user_id,video_id'
        })
        .select()
        .single();

      if (error) {
        console.error('❌ Erro ao salvar progresso:', error);
        return { success: false, error: error.message };
      }

      console.log('✅ Progresso salvo:', data);
      return { success: true, data };
    } catch (error) {
      console.error('❌ Erro ao salvar progresso:', error);
      return { success: false, error: error.message };
    }
  }

  // Carregar progresso de um vídeo específico
  async function loadVideoProgress(videoId) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError || !session) {
        return { success: false, data: null };
      }

      const userId = session.user.id;

      const { data: progress, error } = await supabase
        .from('user_progress')
        .select('*')
        .eq('user_id', userId)
        .eq('video_id', videoId)
        .single();

      if (error && error.code !== 'PGRST116') { // PGRST116 = not found (ok)
        console.error('Erro ao carregar progresso:', error);
        return { success: false, data: null };
      }

      return { success: true, data: progress };
    } catch (error) {
      console.error('Erro ao carregar progresso:', error);
      return { success: false, data: null };
    }
  }

  // Rastrear progresso de iframe do YouTube
  function trackYouTubeVideo(iframe, videoData) {
    if (!iframe || !videoData || !videoData.id) {
      console.warn('trackYouTubeVideo: dados inválidos', { iframe, videoData });
      return;
    }

    console.log('🎬 Iniciando tracking do vídeo YouTube:', videoData.id);

    let lastSavedPercentage = 0;
    let player = null;

    // Usar YouTube IFrame API
    if (window.YT && window.YT.Player) {
      player = new YT.Player(iframe, {
        events: {
          onReady: () => console.log('▶️ Player YouTube pronto'),
          onStateChange: (event) => {
            // Quando o vídeo está tocando
            if (event.data === YT.PlayerState.PLAYING) {
              startTracking();
            }
          }
        }
      });
    }

    function startTracking() {
      const trackingInterval = setInterval(async () => {
        try {
          if (!player || typeof player.getCurrentTime !== 'function') {
            clearInterval(trackingInterval);
            return;
          }

          const currentTime = player.getCurrentTime();
          const duration = player.getDuration();
          
          if (!duration || duration === 0) return;

          const percentage = (currentTime / duration) * 100;

          // Salvar a cada 10% de progresso
          if (Math.floor(percentage / 10) > Math.floor(lastSavedPercentage / 10)) {
            await saveVideoProgress(videoData.id, {
              percentage: percentage,
              instrument: videoData.instrument,
              module: videoData.module,
              lessonId: videoData.lessonId
            });
            
            lastSavedPercentage = percentage;

            // Notificar XP System se disponível
            if (window.XPSystem && typeof window.XPSystem.trackVideoProgress === 'function') {
              window.XPSystem.trackVideoProgress(videoData.id, percentage / 100);
            }
          }
        } catch (e) {
          console.error('Erro no tracking:', e);
        }
      }, 5000); // Verificar a cada 5 segundos

      // Limpar interval quando o modal fechar
      return () => clearInterval(trackingInterval);
    }
  }

  // Rastrear progresso de vídeo HTML5 (<video> tag)
  function trackHTML5Video(videoElement, videoData) {
    if (!videoElement || !videoData || !videoData.id) {
      console.warn('trackHTML5Video: dados inválidos');
      return;
    }

    console.log('🎬 Iniciando tracking do vídeo HTML5:', videoData.id);

    let lastSavedPercentage = 0;

    videoElement.addEventListener('timeupdate', async () => {
      try {
        const currentTime = videoElement.currentTime;
        const duration = videoElement.duration;
        
        if (!duration || duration === 0) return;

        const percentage = (currentTime / duration) * 100;

        // Salvar a cada 10% de progresso
        if (Math.floor(percentage / 10) > Math.floor(lastSavedPercentage / 10)) {
          await saveVideoProgress(videoData.id, {
            percentage: percentage,
            instrument: videoData.instrument,
            module: videoData.module,
            lessonId: videoData.lessonId
          });
          
          lastSavedPercentage = percentage;

          // Notificar XP System
          if (window.XPSystem && typeof window.XPSystem.trackVideoProgress === 'function') {
            window.XPSystem.trackVideoProgress(videoData.id, percentage / 100);
          }
        }
      } catch (e) {
        console.error('Erro no tracking HTML5:', e);
      }
    });
  }

  // Exportar API global
  window.VideoProgressTracker = {
    saveVideoProgress,
    loadVideoProgress,
    trackYouTubeVideo,
    trackHTML5Video
  };

  console.log('✅ Video Progress Tracker carregado!');
})();
