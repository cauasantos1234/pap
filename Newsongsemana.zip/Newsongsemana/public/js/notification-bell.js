// @ts-nocheck
// ============================================
// COMPONENTE DE NOTIFICAÇÕES (SININHO)
// UI para exibir e gerenciar notificações
// ============================================

(function() {
  'use strict';

  let notificationSubscription = null;
  let updateInterval = null;
  let allPanelNotifications = [];
  let filteredPanelNotifications = [];

  // ============================================
  // CRIAR COMPONENTE HTML DO SININHO
  // ============================================
  function createNotificationBell() {
    // Verificar se já existe
    if (document.getElementById('notificationBell')) {
      return;
    }

    // Criar HTML do sininho
    const bellHTML = `
      <div class="notification-bell-container" id="notificationBell">
        <button class="notification-bell-btn" id="notificationBellBtn" aria-label="Notificações">
          <span class="bell-icon">🔔</span>
          <span class="notification-badge" id="notificationBadge">0</span>
        </button>
        
        <div class="notification-dropdown" id="notificationDropdown">
          <div class="notification-dropdown-header">
            <h3>Notificações</h3>
            <button class="mark-all-read-btn" id="markAllReadBtn" title="Marcar todas como lidas">
              ✓ Marcar todas
            </button>
          </div>
          
          <div class="notification-list" id="notificationList">
            <div class="notification-loading">
              <div class="spinner"></div>
              <p>Carregando...</p>
            </div>
          </div>
          
          <div class="notification-dropdown-footer">
            <button class="view-all-link" id="viewAllNotificationsBtn">Ver todas →</button>
          </div>
        </div>
      </div>

      <!-- Painel Lateral de Todas as Notificações -->
      <div class="notifications-panel" id="notificationsPanel">
        <div class="notifications-panel-overlay" id="panelOverlay"></div>
        <div class="notifications-panel-content">
          <div class="notifications-panel-header">
            <h2>Todas as Notificações</h2>
            <button class="close-panel-btn" id="closePanelBtn" aria-label="Fechar">✕</button>
          </div>
          
          <div class="notifications-panel-actions">
            <button class="panel-action-btn" id="panelMarkAllReadBtn">
              ✓ Marcar todas como lidas
            </button>
            <button class="panel-action-btn secondary" id="panelClearAllBtn">
              🗑️ Limpar tudo
            </button>
          </div>

          <div class="notifications-panel-filters">
            <button class="filter-btn active" data-filter="all">Todas</button>
            <button class="filter-btn" data-filter="unread">Não lidas</button>
            <button class="filter-btn" data-filter="new_video,new_video_following">🎥 Vídeos</button>
            <button class="filter-btn" data-filter="rating_received">⭐ Avaliações</button>
            <button class="filter-btn" data-filter="feedback_received,video_comment,comment_liked">💬 Comentários</button>
            <button class="filter-btn" data-filter="video_liked">❤️ Curtidas</button>
            <button class="filter-btn" data-filter="new_follower">👥 Seguidores</button>
            <button class="filter-btn" data-filter="ranking_up">🏆 Ranking</button>
          </div>
          
          <div class="notifications-panel-list" id="panelNotificationList">
            <div class="notification-loading">
              <div class="spinner"></div>
              <p>Carregando...</p>
            </div>
          </div>
        </div>
      </div>
    `;

    // Adicionar CSS
    const style = document.createElement('style');
    style.textContent = `
      /* Container do Sininho */
      .notification-bell-container {
        position: fixed;
        top: 20px;
        right: 20px;
        z-index: 1001;
      }

      /* Botão do Sininho */
      .notification-bell-btn {
        position: relative;
        width: 60px;
        height: 60px;
        background: linear-gradient(135deg, #d4af37, #f4d03f);
        border: 3px solid #0a0a0a;
        border-radius: 50%;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: 0 8px 24px rgba(212, 175, 55, 0.4), inset 0 2px 4px rgba(255, 255, 255, 0.2);
        transition: all 0.3s cubic-bezier(0.68, -0.55, 0.265, 1.55);
      }

      .notification-bell-btn:hover {
        transform: scale(1.1) rotate(15deg);
        box-shadow: 0 12px 32px rgba(212, 175, 55, 0.6), inset 0 2px 4px rgba(255, 255, 255, 0.3);
      }

      .notification-bell-btn:active {
        transform: scale(0.95);
      }

      .bell-icon {
        font-size: 28px;
        animation: bellShake 2s ease-in-out infinite;
      }

      @keyframes bellShake {
        0%, 50%, 100% { transform: rotate(0deg); }
        5%, 15% { transform: rotate(15deg); }
        10%, 20% { transform: rotate(-15deg); }
      }

      /* Badge de Contagem */
      .notification-badge {
        position: absolute;
        top: -5px;
        right: -5px;
        min-width: 24px;
        height: 24px;
        background: #ef4444;
        color: white;
        border-radius: 12px;
        font-size: 12px;
        font-weight: 700;
        display: flex;
        align-items: center;
        justify-content: center;
        padding: 0 6px;
        border: 2px solid #0a0a0a;
        box-shadow: 0 2px 8px rgba(239, 68, 68, 0.5);
        opacity: 0;
        transform: scale(0);
        transition: all 0.3s ease;
      }

      .notification-badge.visible {
        opacity: 1;
        transform: scale(1);
        animation: badgePulse 2s ease-in-out infinite;
      }

      @keyframes badgePulse {
        0%, 100% { transform: scale(1); }
        50% { transform: scale(1.1); }
      }

      /* Dropdown de Notificações */
      .notification-dropdown {
        position: absolute;
        top: 70px;
        right: 0;
        width: 380px;
        max-height: 500px;
        background: linear-gradient(180deg, #1a1a1a 0%, #0f0f0f 100%);
        border: 2px solid rgba(212, 175, 55, 0.3);
        border-radius: 16px;
        box-shadow: 0 12px 48px rgba(0, 0, 0, 0.8);
        opacity: 0;
        visibility: hidden;
        transform: translateY(-10px);
        transition: all 0.3s ease;
        overflow: hidden;
        display: flex;
        flex-direction: column;
      }

      .notification-dropdown.show {
        opacity: 1;
        visibility: visible;
        transform: translateY(0);
      }

      /* Header do Dropdown */
      .notification-dropdown-header {
        padding: 16px 20px;
        background: linear-gradient(135deg, rgba(212, 175, 55, 0.15), rgba(212, 175, 55, 0.05));
        border-bottom: 2px solid rgba(212, 175, 55, 0.2);
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .notification-dropdown-header h3 {
        margin: 0;
        font-size: 18px;
        font-weight: 700;
        color: #d4af37;
      }

      .mark-all-read-btn {
        background: rgba(212, 175, 55, 0.1);
        border: 1px solid rgba(212, 175, 55, 0.3);
        color: #d4af37;
        padding: 6px 12px;
        border-radius: 8px;
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
      }

      .mark-all-read-btn:hover {
        background: rgba(212, 175, 55, 0.2);
        border-color: rgba(212, 175, 55, 0.5);
      }

      /* Lista de Notificações */
      .notification-list {
        flex: 1;
        overflow-y: auto;
        max-height: 380px;
      }

      .notification-item {
        padding: 16px 20px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
        cursor: pointer;
        transition: all 0.2s ease;
        display: flex;
        gap: 12px;
        align-items: flex-start;
      }

      .notification-item:hover {
        background: rgba(212, 175, 55, 0.05);
      }

      .notification-item.unread {
        background: rgba(212, 175, 55, 0.08);
        border-left: 4px solid #d4af37;
      }

      .notification-icon {
        font-size: 28px;
        flex-shrink: 0;
      }

      .notification-content {
        flex: 1;
      }

      .notification-title {
        font-size: 14px;
        font-weight: 600;
        color: #f7f2e6;
        margin: 0 0 4px 0;
      }

      .notification-message {
        font-size: 13px;
        color: rgba(255, 255, 255, 0.7);
        margin: 0 0 8px 0;
        line-height: 1.4;
      }

      .notification-time {
        font-size: 11px;
        color: rgba(212, 175, 55, 0.6);
      }

      .notification-empty {
        padding: 40px 20px;
        text-align: center;
        color: rgba(255, 255, 255, 0.5);
      }

      .notification-empty-icon {
        font-size: 48px;
        margin-bottom: 12px;
        opacity: 0.3;
      }

      .notification-loading {
        padding: 40px 20px;
        text-align: center;
        color: rgba(255, 255, 255, 0.5);
      }

      .spinner {
        width: 40px;
        height: 40px;
        border: 4px solid rgba(212, 175, 55, 0.2);
        border-top-color: #d4af37;
        border-radius: 50%;
        animation: spin 1s linear infinite;
        margin: 0 auto 12px;
      }

      @keyframes spin {
        to { transform: rotate(360deg); }
      }

      /* Footer do Dropdown */
      .notification-dropdown-footer {
        padding: 12px 20px;
        background: rgba(0, 0, 0, 0.3);
        border-top: 1px solid rgba(212, 175, 55, 0.1);
        text-align: center;
      }

      .view-all-link {
        background: none;
        border: none;
        color: #d4af37;
        text-decoration: none;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
        padding: 0;
      }

      .view-all-link:hover {
        color: #f4d03f;
      }

      /* Painel Lateral de Notificações */
      .notifications-panel {
        position: fixed;
        top: 0;
        right: 0;
        width: 100%;
        height: 100%;
        z-index: 10000;
        pointer-events: none;
      }

      .notifications-panel.show {
        pointer-events: all;
      }

      .notifications-panel-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
        opacity: 0;
        transition: opacity 0.3s ease;
      }

      .notifications-panel.show .notifications-panel-overlay {
        opacity: 1;
      }

      .notifications-panel-content {
        position: absolute;
        top: 0;
        right: 0;
        width: 480px;
        max-width: 100%;
        height: 100%;
        background: linear-gradient(180deg, #1a1a1a 0%, #0f0f0f 100%);
        border-left: 2px solid rgba(212, 175, 55, 0.3);
        box-shadow: -8px 0 48px rgba(0, 0, 0, 0.8);
        transform: translateX(100%);
        transition: transform 0.4s cubic-bezier(0.68, -0.55, 0.265, 1.55);
        display: flex;
        flex-direction: column;
        overflow: hidden;
      }

      .notifications-panel.show .notifications-panel-content {
        transform: translateX(0);
      }

      .notifications-panel-header {
        padding: 24px 32px;
        background: linear-gradient(135deg, rgba(212, 175, 55, 0.15), rgba(212, 175, 55, 0.05));
        border-bottom: 2px solid rgba(212, 175, 55, 0.3);
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .notifications-panel-header h2 {
        margin: 0;
        font-size: 24px;
        font-weight: 800;
        background: linear-gradient(135deg, #d4af37, #f4d03f);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
      }

      .close-panel-btn {
        width: 40px;
        height: 40px;
        background: rgba(255, 255, 255, 0.05);
        border: 1px solid rgba(255, 255, 255, 0.1);
        border-radius: 50%;
        color: rgba(255, 255, 255, 0.8);
        font-size: 24px;
        cursor: pointer;
        transition: all 0.2s ease;
        display: flex;
        align-items: center;
        justify-content: center;
        line-height: 1;
      }

      .close-panel-btn:hover {
        background: rgba(239, 68, 68, 0.2);
        border-color: rgba(239, 68, 68, 0.5);
        color: #ef4444;
        transform: rotate(90deg);
      }

      .notifications-panel-actions {
        padding: 16px 32px;
        display: flex;
        gap: 12px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
      }

      .panel-action-btn {
        flex: 1;
        padding: 10px 16px;
        background: rgba(212, 175, 55, 0.1);
        border: 1px solid rgba(212, 175, 55, 0.3);
        border-radius: 10px;
        color: #d4af37;
        font-size: 13px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
      }

      .panel-action-btn:hover {
        background: rgba(212, 175, 55, 0.2);
        border-color: rgba(212, 175, 55, 0.5);
      }

      .panel-action-btn.secondary {
        background: rgba(239, 68, 68, 0.1);
        border-color: rgba(239, 68, 68, 0.3);
        color: #ef4444;
      }

      .panel-action-btn.secondary:hover {
        background: rgba(239, 68, 68, 0.2);
        border-color: rgba(239, 68, 68, 0.5);
      }

      .notifications-panel-filters {
        padding: 16px 32px;
        display: flex;
        gap: 8px;
        overflow-x: auto;
        border-bottom: 1px solid rgba(255, 255, 255, 0.05);
      }

      .filter-btn {
        padding: 8px 16px;
        background: rgba(255, 255, 255, 0.03);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 20px;
        color: rgba(255, 255, 255, 0.6);
        font-size: 12px;
        font-weight: 600;
        cursor: pointer;
        transition: all 0.2s ease;
        white-space: nowrap;
      }

      .filter-btn:hover {
        background: rgba(255, 255, 255, 0.05);
        border-color: rgba(255, 255, 255, 0.15);
        color: rgba(255, 255, 255, 0.8);
      }

      .filter-btn.active {
        background: linear-gradient(135deg, rgba(212, 175, 55, 0.2), rgba(212, 175, 55, 0.1));
        border-color: rgba(212, 175, 55, 0.5);
        color: #d4af37;
      }

      .notifications-panel-list {
        flex: 1;
        overflow-y: auto;
        padding: 8px 0;
      }

      .panel-notification-item {
        padding: 20px 32px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.03);
        cursor: pointer;
        transition: all 0.2s ease;
        display: flex;
        gap: 16px;
        align-items: flex-start;
      }

      .panel-notification-item:hover {
        background: rgba(212, 175, 55, 0.05);
      }

      .panel-notification-item.unread {
        background: rgba(212, 175, 55, 0.08);
        border-left: 4px solid #d4af37;
      }

      .panel-notification-icon {
        font-size: 32px;
        flex-shrink: 0;
        line-height: 1;
      }

      .panel-notification-content {
        flex: 1;
        min-width: 0;
      }

      .panel-notification-title {
        font-size: 15px;
        font-weight: 700;
        color: #f7f2e6;
        margin: 0 0 6px 0;
      }

      .panel-notification-message {
        font-size: 14px;
        color: rgba(255, 255, 255, 0.7);
        margin: 0 0 8px 0;
        line-height: 1.5;
      }

      .panel-notification-time {
        font-size: 12px;
        color: rgba(212, 175, 55, 0.6);
      }

      .panel-notification-empty {
        padding: 80px 32px;
        text-align: center;
      }

      .panel-empty-icon {
        font-size: 64px;
        margin-bottom: 16px;
        opacity: 0.3;
      }

      .panel-empty-text {
        font-size: 16px;
        color: rgba(255, 255, 255, 0.5);
        margin: 0;
      }

      /* Responsivo */
      @media (max-width: 640px) {
        .notification-bell-container {
          top: 15px;
          right: 15px;
        }

        .notification-bell-btn {
          width: 50px;
          height: 50px;
        }

        .bell-icon {
          font-size: 24px;
        }

        .notification-dropdown {
          width: calc(100vw - 30px);
          right: -15px;
        }

        .notifications-panel-content {
          width: 100%;
        }

        .notifications-panel-header {
          padding: 20px 24px;
        }

        .notifications-panel-actions {
          padding: 12px 24px;
          flex-direction: column;
        }

        .notifications-panel-filters {
          padding: 12px 24px;
        }
      }
    `;
    document.head.appendChild(style);

    // Inserir no body
    document.body.insertAdjacentHTML('beforeend', bellHTML);

    // Inicializar eventos
    initializeEvents();
  }

  // ============================================
  // INICIALIZAR EVENTOS
  // ============================================
  function initializeEvents() {
    const bellBtn = document.getElementById('notificationBellBtn');
    const dropdown = document.getElementById('notificationDropdown');
    const markAllBtn = document.getElementById('markAllReadBtn');
    const viewAllBtn = document.getElementById('viewAllNotificationsBtn');

    // Toggle dropdown
    if (bellBtn) {
      bellBtn.addEventListener('click', (e) => {
        e.stopPropagation();
        dropdown.classList.toggle('show');
        if (dropdown.classList.contains('show')) {
          loadNotifications();
        }
      });
    }

    // Fechar dropdown ao clicar fora
    document.addEventListener('click', (e) => {
      if (!e.target.closest('.notification-bell-container')) {
        dropdown.classList.remove('show');
      }
    });

    // Marcar todas como lidas
    if (markAllBtn) {
      markAllBtn.addEventListener('click', async () => {
        await markAllAsRead();
      });
    }

    // Abrir painel lateral
    if (viewAllBtn) {
      viewAllBtn.addEventListener('click', (e) => {
        e.preventDefault();
        openNotificationsPanel();
        dropdown.classList.remove('show');
      });
    }

    // Eventos do painel lateral
    initializePanelEvents();
  }

  // ============================================
  // INICIALIZAR EVENTOS DO PAINEL
  // ============================================
  function initializePanelEvents() {
    const panel = document.getElementById('notificationsPanel');
    const overlay = document.getElementById('panelOverlay');
    const closeBtn = document.getElementById('closePanelBtn');
    const markAllBtn = document.getElementById('panelMarkAllReadBtn');
    const clearAllBtn = document.getElementById('panelClearAllBtn');
    const filterBtns = document.querySelectorAll('.filter-btn');

    // Fechar painel
    const closePanel = () => {
      panel.classList.remove('show');
    };

    if (overlay) {
      overlay.addEventListener('click', closePanel);
    }

    if (closeBtn) {
      closeBtn.addEventListener('click', closePanel);
    }

    // ESC para fechar
    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && panel.classList.contains('show')) {
        closePanel();
      }
    });

    // Marcar todas como lidas
    if (markAllBtn) {
      markAllBtn.addEventListener('click', async () => {
        await markAllAsReadInPanel();
      });
    }

    // Limpar todas
    if (clearAllBtn) {
      clearAllBtn.addEventListener('click', async () => {
        await clearAllNotifications();
      });
    }

    // Filtros
    filterBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        filterBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        const filter = btn.dataset.filter;
        filterPanelNotifications(filter);
      });
    });
  }

  // ============================================
  // CARREGAR NOTIFICAÇÕES
  // ============================================
  async function loadNotifications() {
    const list = document.getElementById('notificationList');
    const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
    
    if (!session || !session.email) {
      list.innerHTML = `
        <div class="notification-empty">
          <div class="notification-empty-icon">🔒</div>
          <p>Faça login para ver suas notificações</p>
        </div>
      `;
      return;
    }

    try {
      const result = await window.NotificationsAPI.getAllNotifications(session.email, 10);
      
      if (!result.success || !result.data || result.data.length === 0) {
        list.innerHTML = `
          <div class="notification-empty">
            <div class="notification-empty-icon">🎵</div>
            <p>Nenhuma notificação ainda</p>
          </div>
        `;
        return;
      }

      list.innerHTML = result.data.map(notification => {
        const style = window.NotificationsAPI.getNotificationStyle(notification.type);
        const timeAgo = window.NotificationsAPI.formatTimeAgo(notification.created_at);
        
        return `
          <div class="notification-item ${!notification.is_read ? 'unread' : ''}" 
               data-id="${notification.id}"
               data-link="${notification.link || ''}">
            <div class="notification-icon">${style.icon}</div>
            <div class="notification-content">
              <p class="notification-title">${notification.title}</p>
              <p class="notification-message">${notification.message}</p>
              <span class="notification-time">${timeAgo}</span>
            </div>
          </div>
        `;
      }).join('');

      // Adicionar eventos de clique
      list.querySelectorAll('.notification-item').forEach(item => {
        item.addEventListener('click', async () => {
          const id = parseInt(item.dataset.id);
          const link = item.dataset.link;
          
          // Marcar como lida
          await window.NotificationsAPI.markAsRead(id);
          item.classList.remove('unread');
          
          // Redirecionar se houver link
          if (link && link !== 'null') {
            setTimeout(() => {
              window.location.href = link;
            }, 200);
          }
          
          // Atualizar badge
          updateBadge();
        });
      });

    } catch (error) {
      console.error('❌ Erro ao carregar notificações:', error);
      list.innerHTML = `
        <div class="notification-empty">
          <div class="notification-empty-icon">⚠️</div>
          <p>Erro ao carregar notificações</p>
        </div>
      `;
    }
  }

  // ============================================
  // ABRIR PAINEL LATERAL
  // ============================================
  async function openNotificationsPanel() {
    const panel = document.getElementById('notificationsPanel');
    panel.classList.add('show');
    await loadPanelNotifications();
  }

  // ============================================
  // CARREGAR NOTIFICAÇÕES DO PAINEL
  // ============================================
  async function loadPanelNotifications() {
    const list = document.getElementById('panelNotificationList');
    const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
    
    if (!session || !session.email) {
      list.innerHTML = '<div class="panel-notification-empty">' +
        '<div class="panel-empty-icon">🔒</div>' +
        '<p class="panel-empty-text">Faça login para ver suas notificações</p>' +
        '</div>';
      return;
    }

    try {
      const result = await window.NotificationsAPI.getAllNotifications(session.email, 100);
      
      if (!result.success || !result.data || result.data.length === 0) {
        list.innerHTML = '<div class="panel-notification-empty">' +
          '<div class="panel-empty-icon">🎵</div>' +
          '<p class="panel-empty-text">Nenhuma notificação ainda</p>' +
          '</div>';
        return;
      }

      allPanelNotifications = result.data;
      filteredPanelNotifications = result.data;
      renderPanelNotifications(filteredPanelNotifications);

    } catch (error) {
      console.error('❌ Erro ao carregar notificações do painel:', error);
      list.innerHTML = '<div class="panel-notification-empty">' +
        '<div class="panel-empty-icon">⚠️</div>' +
        '<p class="panel-empty-text">Erro ao carregar notificações</p>' +
        '</div>';
    }
  }

  // ============================================
  // RENDERIZAR NOTIFICAÇÕES DO PAINEL
  // ============================================
  function renderPanelNotifications(notifications) {
    const list = document.getElementById('panelNotificationList');
    
    if (!notifications || notifications.length === 0) {
      list.innerHTML = '<div class="panel-notification-empty">' +
        '<div class="panel-empty-icon">🔍</div>' +
        '<p class="panel-empty-text">Nenhuma notificação encontrada</p>' +
        '</div>';
      return;
    }

    list.innerHTML = notifications.map(notification => {
      const style = window.NotificationsAPI.getNotificationStyle(notification.type);
      const timeAgo = window.NotificationsAPI.formatTimeAgo(notification.created_at);
      const unreadClass = !notification.is_read ? 'unread' : '';
      const link = notification.link || '';
      
      return '<div class="panel-notification-item ' + unreadClass + '" ' +
             'data-id="' + notification.id + '" ' +
             'data-link="' + link + '">' +
          '<div class="panel-notification-icon">' + style.icon + '</div>' +
          '<div class="panel-notification-content">' +
            '<p class="panel-notification-title">' + notification.title + '</p>' +
            '<p class="panel-notification-message">' + notification.message + '</p>' +
            '<span class="panel-notification-time">' + timeAgo + '</span>' +
          '</div>' +
        '</div>';
    }).join('');

    // Adicionar eventos de clique
    list.querySelectorAll('.panel-notification-item').forEach(item => {
      item.addEventListener('click', async () => {
        const id = parseInt(item.dataset.id);
        const link = item.dataset.link;
        
        // Marcar como lida
        await window.NotificationsAPI.markAsRead(id);
        item.classList.remove('unread');
        
        // Atualizar badge
        updateBadge();
        
        // Redirecionar se houver link
        if (link && link !== 'null') {
          setTimeout(() => {
            window.location.href = link;
          }, 200);
        }
      });
    });
  }

  // ============================================
  // FILTRAR NOTIFICAÇÕES DO PAINEL
  // ============================================
  function filterPanelNotifications(filter) {
    if (filter === 'all') {
      filteredPanelNotifications = allPanelNotifications;
    } else if (filter === 'unread') {
      filteredPanelNotifications = allPanelNotifications.filter(n => !n.is_read);
    } else {
      // Suportar múltiplos tipos separados por vírgula
      const types = filter.split(',');
      filteredPanelNotifications = allPanelNotifications.filter(n => types.includes(n.type));
    }
    
    renderPanelNotifications(filteredPanelNotifications);
  }

  // ============================================
  // ATUALIZAR BADGE
  // ============================================
  async function updateBadge() {
    const badge = document.getElementById('notificationBadge');
    const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
    
    if (!session || !session.email || !badge) return;

    try {
      const result = await window.NotificationsAPI.countUnread(session.email);
      
      if (result.success) {
        const count = result.count || 0;
        badge.textContent = count > 99 ? '99+' : count;
        
        if (count > 0) {
          badge.classList.add('visible');
        } else {
          badge.classList.remove('visible');
        }
      }
    } catch (error) {
      console.error('❌ Erro ao atualizar badge:', error);
    }
  }

  // ============================================
  // MARCAR TODAS COMO LIDAS
  // ============================================
  async function markAllAsRead() {
    const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
    if (!session || !session.email) return;

    try {
      await window.NotificationsAPI.markAllAsRead(session.email);
      await loadNotifications();
      updateBadge();
    } catch (error) {
      console.error('❌ Erro ao marcar todas como lidas:', error);
    }
  }

  // ============================================
  // MARCAR TODAS COMO LIDAS NO PAINEL
  // ============================================
  async function markAllAsReadInPanel() {
    const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
    if (!session || !session.email) return;

    try {
      await window.NotificationsAPI.markAllAsRead(session.email);
      await loadPanelNotifications();
      updateBadge();
      
      // Mostrar feedback
      const btn = document.getElementById('panelMarkAllReadBtn');
      const originalText = btn.textContent;
      btn.textContent = '✓ Marcadas!';
      setTimeout(() => {
        btn.textContent = originalText;
      }, 2000);
    } catch (error) {
      console.error('❌ Erro ao marcar todas como lidas:', error);
    }
  }

  // ============================================
  // LIMPAR TODAS NOTIFICAÇÕES
  // ============================================
  async function clearAllNotifications() {
    const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
    if (!session || !session.email) return;

    if (!confirm('Tem certeza que deseja apagar todas as notificações?')) {
      return;
    }

    try {
      const supabase = window.SupabaseAPI.getClient();
      
      const { error } = await supabase
        .from('notifications')
        .delete()
        .eq('user_email', session.email);
      
      if (error) throw error;

      allPanelNotifications = [];
      filteredPanelNotifications = [];
      renderPanelNotifications([]);
      updateBadge();
      
      // Mostrar feedback
      const btn = document.getElementById('panelClearAllBtn');
      const originalText = btn.textContent;
      btn.textContent = '✓ Limpas!';
      setTimeout(() => {
        btn.textContent = originalText;
      }, 2000);
    } catch (error) {
      console.error('❌ Erro ao limpar notificações:', error);
      alert('Erro ao limpar notificações. Tente novamente.');
    }
  }

  // ============================================
  // INICIALIZAR COMPONENTE
  // ============================================
  function initialize() {
    // Aguardar NotificationsAPI carregar
    if (!window.NotificationsAPI) {
      setTimeout(initialize, 100);
      return;
    }
    
    // Criar componente
    createNotificationBell();

    // Atualizar badge inicial
    updateBadge();

    // Atualizar badge periodicamente (a cada 30 segundos)
    updateInterval = setInterval(updateBadge, 30000);

    // Inscrever para notificações em tempo real
    const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
    if (session && session.email) {
      notificationSubscription = window.NotificationsAPI.subscribeToNotifications(
        session.email,
        (newNotification) => {
          updateBadge();
          
          // Mostrar notificação nativa do navegador
          if ('Notification' in window && Notification.permission === 'granted') {
            new Notification(newNotification.title, {
              body: newNotification.message,
              icon: '/icon-192x192.png',
              badge: '/badge-72x72.png'
            });
          }
        }
      );
    }
  }

  // Limpar ao sair
  window.addEventListener('beforeunload', () => {
    if (notificationSubscription) {
      window.NotificationsAPI.unsubscribeFromNotifications(notificationSubscription);
    }
    if (updateInterval) {
      clearInterval(updateInterval);
    }
  });

  // Solicitar permissão para notificações do navegador
  if ('Notification' in window && Notification.permission === 'default') {
    Notification.requestPermission();
  }

  // Inicializar quando DOM estiver pronto
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }

  // Exportar funções úteis
  window.NotificationBell = {
    updateBadge,
    loadNotifications,
    markAllAsRead,
    openPanel: openNotificationsPanel,
    closePanel: () => document.getElementById('notificationsPanel')?.classList.remove('show')
  };

})();
