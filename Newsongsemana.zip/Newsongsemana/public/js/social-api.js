// ============================================
// API DE CURTIDAS E SEGUIDORES - NewSong
// Funções para curtir vídeos, comentários e seguir professores
// ============================================

console.log('🚀 social-api.js: Iniciando carregamento...');

(function() {
  'use strict';

  console.log('🔧 social-api.js: Dentro da IIFE');

  // Aguardar Supabase carregar
  function waitForSupabase(callback) {
    if (window.SupabaseAPI && window.SupabaseAPI.getClient()) {
      callback();
    } else {
      setTimeout(() => waitForSupabase(callback), 100);
    }
  }

  // ============================================
  // CURTIDAS EM VÍDEOS
  // ============================================
  
  async function likeVideo(videoId) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
      
      // ✅ Verificar múltiplos campos para compatibilidade
      const userId = session?.user_id || session?.supabase_id;
      const userEmail = session?.email;
      
      if (!session || !userId || !userEmail) {
        return { success: false, error: 'Usuário não autenticado' };
      }

      const { data, error } = await supabase
        .from('video_likes')
        .insert({
          video_id: videoId,
          user_id: userId,
          user_email: userEmail
        });

      if (error) throw error;

      console.log('✅ Vídeo curtido:', videoId);
      return { success: true, data };
    } catch (error) {
      console.error('❌ Erro ao curtir vídeo:', error);
      return { success: false, error: error.message };
    }
  }

  async function unlikeVideo(videoId) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
      
      const userId = session?.user_id || session?.supabase_id;
      
      if (!session || !userId) {
        return { success: false, error: 'Usuário não autenticado' };
      }

      const { data, error } = await supabase
        .from('video_likes')
        .delete()
        .eq('video_id', videoId)
        .eq('user_id', userId);

      if (error) throw error;

      console.log('✅ Curtida removida:', videoId);
      return { success: true, data };
    } catch (error) {
      console.error('❌ Erro ao remover curtida:', error);
      return { success: false, error: error.message };
    }
  }

  async function getVideoLikes(videoId) {
    try {
      const supabase = window.SupabaseAPI.getClient();

      const { data, error, count } = await supabase
        .from('video_likes')
        .select('*', { count: 'exact' })
        .eq('video_id', videoId);

      if (error) throw error;

      return { success: true, data, count };
    } catch (error) {
      console.error('❌ Erro ao buscar curtidas:', error);
      return { success: false, error: error.message };
    }
  }

  async function hasUserLikedVideo(videoId) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
      
      const userId = session?.user_id || session?.supabase_id;
      
      if (!session || !userId) {
        return { success: true, liked: false };
      }

      const { data, error } = await supabase
        .from('video_likes')
        .select('id')
        .eq('video_id', videoId)
        .eq('user_id', userId)
        .single();

      return { success: true, liked: !!data };
    } catch (error) {
      // Se não encontrar, é porque não curtiu
      return { success: true, liked: false };
    }
  }

  // ============================================
  // CURTIDAS EM COMENTÁRIOS
  // ============================================
  
  async function likeComment(commentId) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
      
      const userId = session?.user_id || session?.supabase_id;
      const userEmail = session?.email;
      
      if (!session || !userId || !userEmail) {
        return { success: false, error: 'Usuário não autenticado' };
      }

      const { data, error } = await supabase
        .from('comment_likes')
        .insert({
          comment_id: commentId,
          user_id: userId,
          user_email: userEmail
        });

      if (error) throw error;

      // Atualizar contador no comentário
      await supabase.rpc('increment_comment_likes', { comment_id: commentId });

      console.log('✅ Comentário curtido:', commentId);
      return { success: true, data };
    } catch (error) {
      console.error('❌ Erro ao curtir comentário:', error);
      return { success: false, error: error.message };
    }
  }

  async function unlikeComment(commentId) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
      
      if (!session || !session.user_id) {
        return { success: false, error: 'Usuário não autenticado' };
      }

      const { data, error } = await supabase
        .from('comment_likes')
        .delete()
        .eq('comment_id', commentId)
        .eq('user_id', session.user_id);

      if (error) throw error;

      // Decrementar contador no comentário
      await supabase.rpc('decrement_comment_likes', { comment_id: commentId });

      console.log('✅ Curtida de comentário removida:', commentId);
      return { success: true, data };
    } catch (error) {
      console.error('❌ Erro ao remover curtida:', error);
      return { success: false, error: error.message };
    }
  }

  async function getCommentLikes(commentId) {
    try {
      const supabase = window.SupabaseAPI.getClient();

      const { data, error, count } = await supabase
        .from('comment_likes')
        .select('*', { count: 'exact' })
        .eq('comment_id', commentId);

      if (error) throw error;

      return { success: true, data, count };
    } catch (error) {
      console.error('❌ Erro ao buscar curtidas:', error);
      return { success: false, error: error.message };
    }
  }

  async function hasUserLikedComment(commentId) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
      
      if (!session || !session.user_id) {
        return { success: true, liked: false };
      }

      const { data, error } = await supabase
        .from('comment_likes')
        .select('id')
        .eq('comment_id', commentId)
        .eq('user_id', session.user_id)
        .single();

      return { success: true, liked: !!data };
    } catch (error) {
      return { success: true, liked: false };
    }
  }

  // ============================================
  // SEGUIDORES
  // ============================================
  
  async function followTeacher(teacherId, teacherEmail) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
      
      const userId = session?.user_id || session?.supabase_id;
      const userEmail = session?.email;
      
      if (!session || !userId || !userEmail) {
        return { success: false, error: 'Usuário não autenticado' };
      }

      const { data, error } = await supabase
        .from('follows')
        .insert({
          follower_id: userId,
          follower_email: userEmail,
          following_id: teacherId,
          following_email: teacherEmail
        });

      if (error) throw error;

      console.log('✅ Professor seguido:', teacherEmail);
      return { success: true, data };
    } catch (error) {
      console.error('❌ Erro ao seguir professor:', error);
      return { success: false, error: error.message };
    }
  }

  async function unfollowTeacher(teacherId) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
      
      if (!session || !session.user_id) {
        return { success: false, error: 'Usuário não autenticado' };
      }

      const { data, error } = await supabase
        .from('follows')
        .delete()
        .eq('follower_id', session.user_id)
        .eq('following_id', teacherId);

      if (error) throw error;

      console.log('✅ Deixou de seguir professor');
      return { success: true, data };
    } catch (error) {
      console.error('❌ Erro ao deixar de seguir:', error);
      return { success: false, error: error.message };
    }
  }

  async function isFollowingTeacher(teacherId) {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
      
      if (!session || !session.user_id) {
        return { success: true, following: false };
      }

      const { data, error } = await supabase
        .from('follows')
        .select('id')
        .eq('follower_id', session.user_id)
        .eq('following_id', teacherId)
        .single();

      return { success: true, following: !!data };
    } catch (error) {
      return { success: true, following: false };
    }
  }

  async function getTeacherFollowers(teacherId) {
    try {
      const supabase = window.SupabaseAPI.getClient();

      const { data, error, count } = await supabase
        .from('follows')
        .select('follower_id, follower_email, created_at', { count: 'exact' })
        .eq('following_id', teacherId)
        .order('created_at', { ascending: false });

      if (error) throw error;

      return { success: true, data, count };
    } catch (error) {
      console.error('❌ Erro ao buscar seguidores:', error);
      return { success: false, error: error.message };
    }
  }

  async function getUserFollowing() {
    try {
      const supabase = window.SupabaseAPI.getClient();
      const session = JSON.parse(localStorage.getItem('ns-session') || 'null');
      
      if (!session || !session.user_id) {
        return { success: false, error: 'Usuário não autenticado' };
      }

      const { data, error, count } = await supabase
        .from('follows')
        .select('following_id, following_email, created_at', { count: 'exact' })
        .eq('follower_id', session.user_id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      return { success: true, data, count };
    } catch (error) {
      console.error('❌ Erro ao buscar professores seguidos:', error);
      return { success: false, error: error.message };
    }
  }

  // ============================================
  // EXPORTAR API
  // ============================================
  
  waitForSupabase(() => {
    window.SocialAPI = {
      // Vídeos
      likeVideo,
      unlikeVideo,
      getVideoLikes,
      hasUserLikedVideo,
      
      // Comentários
      likeComment,
      unlikeComment,
      getCommentLikes,
      hasUserLikedComment,
      
      // Seguidores
      followTeacher,
      unfollowTeacher,
      isFollowingTeacher,
      getTeacherFollowers,
      getUserFollowing
    };

    console.log('✅ SocialAPI carregada');
  });

})();
