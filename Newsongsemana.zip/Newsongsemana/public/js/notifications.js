// ============================================
// SISTEMA DE NOTIFICAÇÕES - SUPABASE
// Gerenciamento de notificações em tempo real
// ============================================

(function() {
  'use strict';

  // Aguardar Supabase carregar
  function waitForSupabase(callback) {
    if (window.SupabaseAPI && window.SupabaseAPI.isReady()) {
      callback();
    } else {
      setTimeout(() => waitForSupabase(callback), 100);
    }
  }

  // ============================================
  // MÓDULO DE NOTIFICAÇÕES
  // ============================================
  
  window.NotificationsAPI = {
    
    // Obter notificações não lidas
    async getUnreadNotifications(userEmail) {
      try {
        const supabase = window.SupabaseAPI.getClient();
        
        const { data, error } = await supabase
          .from('notifications')
          .select('*')
          .eq('user_email', userEmail)
          .eq('is_read', false)
          .order('created_at', { ascending: false });
        
        if (error) {
          console.error('❌ Erro ao buscar notificações:', error);
          return { success: false, error };
        }
        
        return { success: true, data: data || [] };
      } catch (error) {
        console.error('❌ Erro ao buscar notificações:', error);
        return { success: false, error };
      }
    },
    
    // Obter todas notificações (com limite)
    async getAllNotifications(userEmail, limit = 50) {
      try {
        const supabase = window.SupabaseAPI.getClient();
        
        const { data, error } = await supabase
          .from('notifications')
          .select('*')
          .eq('user_email', userEmail)
          .order('created_at', { ascending: false })
          .limit(limit);
        
        if (error) {
          console.error('❌ Erro ao buscar notificações:', error);
          return { success: false, error };
        }
        
        return { success: true, data: data || [] };
      } catch (error) {
        console.error('❌ Erro ao buscar notificações:', error);
        return { success: false, error };
      }
    },
    
    // Contar notificações não lidas
    async countUnread(userEmail) {
      try {
        const supabase = window.SupabaseAPI.getClient();
        
        const { count, error } = await supabase
          .from('notifications')
          .select('*', { count: 'exact', head: true })
          .eq('user_email', userEmail)
          .eq('is_read', false);
        
        if (error) {
          console.error('❌ Erro ao contar notificações:', error);
          return { success: false, error, count: 0 };
        }
        
        return { success: true, count: count || 0 };
      } catch (error) {
        console.error('❌ Erro ao contar notificações:', error);
        return { success: false, error, count: 0 };
      }
    },
    
    // Marcar notificação como lida
    async markAsRead(notificationId) {
      try {
        const supabase = window.SupabaseAPI.getClient();
        
        const { error } = await supabase
          .from('notifications')
          .update({ 
            is_read: true,
            read_at: new Date().toISOString()
          })
          .eq('id', notificationId);
        
        if (error) {
          console.error('❌ Erro ao marcar como lida:', error);
          return { success: false, error };
        }
        
        return { success: true };
      } catch (error) {
        console.error('❌ Erro ao marcar como lida:', error);
        return { success: false, error };
      }
    },
    
    // Marcar todas como lidas
    async markAllAsRead(userEmail) {
      try {
        const supabase = window.SupabaseAPI.getClient();
        
        const { error } = await supabase
          .from('notifications')
          .update({ 
            is_read: true,
            read_at: new Date().toISOString()
          })
          .eq('user_email', userEmail)
          .eq('is_read', false);
        
        if (error) {
          console.error('❌ Erro ao marcar todas como lidas:', error);
          return { success: false, error };
        }
        
        return { success: true };
      } catch (error) {
        console.error('❌ Erro ao marcar todas como lidas:', error);
        return { success: false, error };
      }
    },
    
    // Criar notificação manualmente
    async createNotification(data) {
      try {
        const supabase = window.SupabaseAPI.getClient();
        
        const { data: notification, error } = await supabase
          .from('notifications')
          .insert([{
            user_email: data.userEmail,
            type: data.type,
            title: data.title,
            message: data.message,
            link: data.link || null,
            metadata: data.metadata || {}
          }])
          .select()
          .single();
        
        if (error) {
          console.error('❌ Erro ao criar notificação:', error);
          return { success: false, error };
        }
        
        console.log('✅ Notificação criada:', notification);
        return { success: true, data: notification };
      } catch (error) {
        console.error('❌ Erro ao criar notificação:', error);
        return { success: false, error };
      }
    },
    
    // Deletar notificação
    async deleteNotification(notificationId) {
      try {
        const supabase = window.SupabaseAPI.getClient();
        
        const { error } = await supabase
          .from('notifications')
          .delete()
          .eq('id', notificationId);
        
        if (error) {
          console.error('❌ Erro ao deletar notificação:', error);
          return { success: false, error };
        }
        
        return { success: true };
      } catch (error) {
        console.error('❌ Erro ao deletar notificação:', error);
        return { success: false, error };
      }
    },
    
    // Inscrever para receber notificações em tempo real
    subscribeToNotifications(userEmail, callback) {
      try {
        const supabase = window.SupabaseAPI.getClient();
        
        const subscription = supabase
          .channel('notifications')
          .on(
            'postgres_changes',
            {
              event: 'INSERT',
              schema: 'public',
              table: 'notifications',
              filter: `user_email=eq.${userEmail}`
            },
            (payload) => {
              console.log('🔔 Nova notificação recebida:', payload);
              callback(payload.new);
            }
          )
          .subscribe();
        
        console.log('✅ Inscrito em notificações em tempo real');
        return subscription;
      } catch (error) {
        console.error('❌ Erro ao se inscrever em notificações:', error);
        return null;
      }
    },
    
    // Cancelar inscrição
    unsubscribeFromNotifications(subscription) {
      try {
        if (subscription) {
          subscription.unsubscribe();
          console.log('✅ Desincrito de notificações');
        }
      } catch (error) {
        console.error('❌ Erro ao desinscrever:', error);
      }
    },
    
    // Obter ícone e cor por tipo
    getNotificationStyle(type) {
      const styles = {
        // Notificações de Professores
        'rating_received': { icon: '⭐', color: '#ffc107' },
        'feedback_received': { icon: '💬', color: '#06b6d4' },
        'video_liked': { icon: '❤️', color: '#ef4444' },
        'new_follower': { icon: '👥', color: '#3b82f6' },
        'video_comment': { icon: '💬', color: '#22c55e' },
        
        // Notificações de Alunos
        'new_video': { icon: '🎥', color: '#7c3aed' },
        'new_video_following': { icon: '🎥', color: '#7c3aed' },
        'ranking_up': { icon: '🏆', color: '#d4af37' },
        'comment_liked': { icon: '👍', color: '#f59e0b' },
        'achievement': { icon: '🎯', color: '#10b981' },
        
        // Genéricas
        'comment': { icon: '💭', color: '#22c55e' },
        'default': { icon: '🔔', color: '#8b8b8b' }
      };
      
      return styles[type] || styles.default;
    },
    
    // Formatar tempo relativo
    formatTimeAgo(dateString) {
      const now = new Date();
      const date = new Date(dateString);
      const seconds = Math.floor((now - date) / 1000);
      
      const intervals = {
        ano: 31536000,
        mês: 2592000,
        semana: 604800,
        dia: 86400,
        hora: 3600,
        minuto: 60
      };
      
      for (const [name, secondsInInterval] of Object.entries(intervals)) {
        const interval = Math.floor(seconds / secondsInInterval);
        if (interval >= 1) {
          return `há ${interval} ${name}${interval > 1 && name !== 'mês' ? 's' : name === 'mês' && interval > 1 ? 'es' : ''}`;
        }
      }
      
      return 'agora mesmo';
    }
  };

  // Inicializar quando Supabase estiver pronto
  waitForSupabase(() => {
    console.log('✅ NotificationsAPI carregado');
  });

})();
