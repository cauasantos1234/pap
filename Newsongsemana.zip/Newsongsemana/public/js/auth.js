// auth.js - front-end auth simulation
(function(){
  const loginForm = document.getElementById('loginForm');
  const registerForm = document.getElementById('registerForm');

  // Função para criar modal de notificação personalizado
  function showNotification(title, message, type = 'success') {
    // Remove notificação anterior se existir
    const existing = document.querySelector('.custom-notification');
    if (existing) existing.remove();

    const notification = document.createElement('div');
    notification.className = 'custom-notification';
    notification.innerHTML = `
      <div class="notification-content ${type}">
        <div class="notification-header">
          <div class="notification-icon">
            ${type === 'success' ? `
              <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                <polyline points="22 4 12 14.01 9 11.01"></polyline>
              </svg>
            ` : `
              <svg width="64" height="64" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"></circle>
                <line x1="12" y1="8" x2="12" y2="12"></line>
                <line x1="12" y1="16" x2="12.01" y2="16"></line>
              </svg>
            `}
          </div>
          <h2>${title}</h2>
        </div>
        <div class="notification-body">
          <p>${message}</p>
        </div>
        <div class="notification-footer">
          <button class="notification-btn" onclick="this.closest('.custom-notification').remove()">
            <span>Entendi</span>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="9 18 15 12 9 6"></polyline>
            </svg>
          </button>
        </div>
      </div>
    `;

    // Adicionar estilos
    const style = document.createElement('style');
    style.textContent = `
      .custom-notification {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.95);
        backdrop-filter: blur(12px);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 10000;
        animation: fadeIn 0.4s ease;
        padding: 20px;
      }
      
      @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
      }
      
      .notification-content {
        background: linear-gradient(135deg, #1a1a1a 0%, #0f0f0f 100%);
        border: 3px solid rgba(212,175,55,0.4);
        border-radius: 28px;
        padding: 0;
        max-width: 600px;
        width: 100%;
        box-shadow: 0 25px 80px rgba(212,175,55,0.3), 0 0 100px rgba(212,175,55,0.1);
        animation: slideUp 0.5s cubic-bezier(0.34, 1.56, 0.64, 1);
        overflow: hidden;
        position: relative;
      }
      
      .notification-content::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        height: 6px;
        background: linear-gradient(90deg, var(--gold-1, #d4af37), var(--gold-2, #ffd700), var(--gold-1, #d4af37));
        background-size: 200% 100%;
        animation: gradientMove 3s ease infinite;
      }
      
      @keyframes gradientMove {
        0%, 100% { background-position: 0% 50%; }
        50% { background-position: 100% 50%; }
      }
      
      @keyframes slideUp {
        from { 
          transform: translateY(50px) scale(0.95); 
          opacity: 0; 
        }
        to { 
          transform: translateY(0) scale(1); 
          opacity: 1; 
        }
      }
      
      .notification-header {
        padding: 48px 48px 32px;
        text-align: center;
        background: linear-gradient(180deg, rgba(212,175,55,0.08) 0%, transparent 100%);
      }
      
      .notification-content.success .notification-icon {
        color: var(--gold-1, #d4af37);
      }
      
      .notification-content.error .notification-icon {
        color: #ff4444;
      }
      
      .notification-icon {
        margin: 0 auto 24px;
        width: 100px;
        height: 100px;
        background: linear-gradient(135deg, rgba(212,175,55,0.15), rgba(212,175,55,0.05));
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        animation: pulse 2.5s ease infinite;
        border: 3px solid rgba(212,175,55,0.3);
        box-shadow: 0 0 40px rgba(212,175,55,0.2);
      }
      
      @keyframes pulse {
        0%, 100% { 
          transform: scale(1);
          box-shadow: 0 0 40px rgba(212,175,55,0.2);
        }
        50% { 
          transform: scale(1.05);
          box-shadow: 0 0 60px rgba(212,175,55,0.4);
        }
      }
      
      .notification-content h2 {
        font-size: 36px;
        font-weight: 900;
        background: linear-gradient(135deg, var(--gold-1, #d4af37), var(--gold-2, #ffd700));
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        margin: 0;
        letter-spacing: -0.5px;
        line-height: 1.2;
      }
      
      .notification-body {
        padding: 0 48px 32px;
        text-align: center;
      }
      
      .notification-body p {
        font-size: 17px;
        color: rgba(255,255,255,0.8);
        line-height: 1.7;
        margin: 0;
      }
      
      .notification-body p strong {
        color: var(--gold-1, #d4af37);
        font-weight: 700;
      }
      
      .notification-body p em {
        display: block;
        margin-top: 20px;
        font-size: 14px;
        color: rgba(255,255,255,0.5);
        font-style: normal;
      }
      
      .notification-footer {
        padding: 0 48px 48px;
        text-align: center;
      }
      
      .notification-btn {
        padding: 18px 56px;
        background: linear-gradient(135deg, var(--gold-1, #d4af37), var(--gold-2, #ffd700));
        border: none;
        border-radius: 14px;
        color: #0a0a0a;
        font-size: 17px;
        font-weight: 700;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 10px 30px rgba(212,175,55,0.4);
        display: inline-flex;
        align-items: center;
        gap: 10px;
        letter-spacing: 0.5px;
      }
      
      .notification-btn:hover {
        transform: translateY(-3px);
        box-shadow: 0 15px 40px rgba(212,175,55,0.6);
      }
      
      .notification-btn:active {
        transform: translateY(-1px);
      }
      
      .notification-btn svg {
        transition: transform 0.3s ease;
      }
      
      .notification-btn:hover svg {
        transform: translateX(4px);
      }
      
      /* Responsivo */
      @media (max-width: 600px) {
        .notification-content {
          border-radius: 20px;
          margin: 20px;
        }
        
        .notification-header {
          padding: 32px 24px 24px;
        }
        
        .notification-body {
          padding: 0 24px 24px;
        }
        
        .notification-footer {
          padding: 0 24px 32px;
        }
        
        .notification-content h2 {
          font-size: 28px;
        }
        
        .notification-body p {
          font-size: 15px;
        }
        
        .notification-icon {
          width: 80px;
          height: 80px;
        }
        
        .notification-icon svg {
          width: 48px;
          height: 48px;
        }
        
        .notification-btn {
          padding: 16px 40px;
          font-size: 16px;
        }
      }
    `;
    
    document.head.appendChild(style);
    document.body.appendChild(notification);
  }

  function saveUser(data){
    // Garantir que a senha seja criptografada antes de salvar
    if (data.password && !data.password.startsWith('$')) {
      console.warn('⚠️ Tentativa de salvar senha em texto plano - será criptografada');
      // A senha será criptografada pelo auth.js antes de chamar saveUser
    }
    
    const users = JSON.parse(localStorage.getItem('ns-users')||'[]');
    users.push(data); 
    localStorage.setItem('ns-users', JSON.stringify(users));
    console.log('✅ Usuário salvo com segurança:', {
      name: data.name,
      email: data.email,
      role: data.role,
      hashStatus: data.password ? (data.password.startsWith('$') ? '🔒 Criptografado' : '⚠️ Texto plano') : 'N/A'
    });
    console.log('Total de usuários:', users.length);
  }
  
  // Funções de debug disponíveis no console
  window.debugAuth = {
    listarUsuarios: () => {
      const users = JSON.parse(localStorage.getItem('ns-users')||'[]');
      console.table(users.map(u => ({
        nome: u.name,
        email: u.email,
        tipo: u.role,
        senha: u.password
      })));
      return users;
    },
    limparUsuarios: () => {
      localStorage.removeItem('ns-users');
      console.log('✅ Todos os usuários foram removidos!');
    },
    criarProfessorTeste: () => {
      const testTeacher = {
        name: 'Professor Teste',
        email: 'professor@gmail.com',
        password: '123456',
        role: 'teacher'
      };
      saveUser(testTeacher);
      console.log('✅ Professor de teste criado!');
      console.log('Email: professor@gmail.com');
      console.log('Senha: 123456');
    },
    criarAlunoTeste: () => {
      const testStudent = {
        name: 'Aluno Teste',
        email: 'aluno@gmail.com',
        password: '123456',
        role: 'student'
      };
      saveUser(testStudent);
      console.log('✅ Aluno de teste criado!');
      console.log('Email: aluno@gmail.com');
      console.log('Senha: 123456');
    },
    sessaoAtual: () => {
      const session = JSON.parse(localStorage.getItem('ns-session')||'null');
      console.log('Sessão atual:', session);
      return session;
    }
  };
  
  console.log('🔧 Debug Auth disponível!');
  console.log('Digite "debugAuth.listarUsuarios()" para ver todos os usuários');
  console.log('Digite "debugAuth.criarProfessorTeste()" para criar um professor de teste');

  if(loginForm){
    loginForm.addEventListener('submit', async e=>{
      e.preventDefault();
      const emailInput = document.getElementById('email');
      const passInput = document.getElementById('password');
      const email = emailInput.value.toLowerCase().trim();
      const pass = passInput.value;
      
      console.log('=== TENTATIVA DE LOGIN ====================');
      console.log('Email:', email);
      console.log('Tentando autenticar via Supabase primeiro...');
      
      // PRIORIDADE 1: Tentar login no Supabase primeiro
      if (typeof window.supabase !== 'undefined' && window.supabase.auth) {
        try {
          const { data, error } = await window.supabase.auth.signInWithPassword({
            email: email,
            password: pass
          });
          
          if (error) {
            console.error('❌ Erro ao fazer login no Supabase:', error);
            
            // Verificar tipo de erro
            if (error.message.includes('Invalid login credentials') || error.message.includes('credentials')) {
              showNotification(
                'Credenciais inválidas',
                'Email ou senha incorretos. Verifique suas credenciais e tente novamente.',
                'error'
              );
              return;
            } else if (error.message.includes('Email not confirmed')) {
              showNotification(
                'Email não confirmado',
                'Seu email ainda não foi confirmado. Por favor, verifique sua caixa de entrada ou confirme no Dashboard do Supabase.',
                'error'
              );
              return;
            } else {
              // Para outros erros, mostrar mensagem genérica mas ainda tentar localStorage como fallback
              console.warn('⚠️ Erro no Supabase, tentando localStorage como fallback...');
              tryLocalStorageLogin();
              return;
            }
          } else {
            
            // Buscar role correto da tabela users
            console.log('===========================================');
            console.log('🔍 CONSULTANDO BANCO DE DADOS PARA ROLE');
            console.log('===========================================');
            console.log('📧 Email:', data.user.email);
            console.log('🆔 User ID:', data.user.id);
            
            let userRole = 'student';
            let userName = data.user.user_metadata?.name || data.user.email.split('@')[0];
            
            try {
              console.log('🔄 Consultando tabela "users" no Supabase...');
              
              const { data: userData, error: userError } = await window.supabase
                .from('users')
                .select('role, name, email, id')
                .eq('email', data.user.email)
                .maybeSingle();
              
              console.log('📊 Resposta do banco:');
              console.log('   • Erro:', userError?.message || 'Nenhum');
              console.log('   • Dados recebidos:', userData);
              
              if (userData && !userError) {
                userRole = userData.role || 'student';
                userName = userData.name || userName;
                console.log('✅ ROLE ENCONTRADO NO BANCO!');
                console.log('   • Role:', userRole);
                console.log('   • Nome:', userName);
                console.log('   • Email:', userData.email);
                console.log('   • ID no banco:', userData.id);
              } else if (userError) {
                console.error('❌ ERRO ao consultar banco:', userError.message);
                console.error('   Código:', userError.code);
                console.error('   Detalhes:', userError.details);
                console.warn('⚠️ Usando role padrão: student');
              } else {
                console.warn('⚠️ USUÁRIO NÃO ENCONTRADO na tabela users');
                console.warn('   Email procurado:', data.user.email);
                console.warn('   Usando role padrão: student');
                console.warn('💡 Possível causa: Usuário existe no Auth mas não na tabela users');
              }
            } catch(e) {
              console.error('❌ EXCEÇÃO ao buscar role:', e);
              console.error('   Stack:', e.stack);
              console.warn('⚠️ Usando role padrão: student');
            }
            
            console.log('');
            console.log('📝 RESULTADO FINAL:');
            console.log('   • Role selecionado:', userRole);
            console.log('   • Nome:', userName);
            console.log('===========================================');
            
            // Salvar sessão local
            localStorage.setItem('ns-session', JSON.stringify({
              email: data.user.email,
              name: userName,
              role: userRole,
              user_id: data.user.id,      // ✅ Adicionado user_id para compatibilidade
              supabase_id: data.user.id
            }));
            
            console.log('📝 Sessão salva:', { email: data.user.email, name: userName, role: userRole });
            
            // ✅ SINCRONIZAR COM TABELA 'users' DO SUPABASE
            if (window.SupabaseAuth && typeof window.SupabaseAuth.syncUserToSupabase === 'function') {
              console.log('🔄 Iniciando sincronização com Supabase...');
              try {
                const syncResult = await window.SupabaseAuth.syncUserToSupabase({
                  email: data.user.email,
                  name: userName,
                  role: userRole
                });
                
                if (syncResult && syncResult.success) {
                  console.log('✅ Usuário sincronizado com tabela users do Supabase:', syncResult.data);
                } else {
                  console.warn('⚠️ Sincronização não foi bem-sucedida:', syncResult?.error);
                }
              } catch(syncError) {
                console.error('❌ Erro ao sincronizar usuário:', syncError);
              }
            } else {
              console.warn('⚠️ SupabaseAuth.syncUserToSupabase não disponível');
            }
            
            // Sincronizar com localStorage também
            const users = JSON.parse(localStorage.getItem('ns-users')||'[]');
            const localUser = users.find(u=>u.email.toLowerCase().trim() === email);
            if (!localUser) {
              saveUser({
                name: userName,
                email: data.user.email,
                password: pass,
                role: userRole
              });
              console.log('✅ Usuário sincronizado no localStorage');
            }
            
            // Carregar progresso do Supabase (se existir)
            const userProgressKey = `newsong-user-progress-${data.user.email}`;
            
            if (window.SupabaseProgress && window.SupabaseProgress.loadProgress) {
              console.log('🔄 Carregando progresso do Supabase...');
              window.SupabaseProgress.loadProgress().then(result => {
                if (result.success && result.data) {
                  console.log('✅ Progresso carregado do Supabase');
                  localStorage.setItem(userProgressKey, JSON.stringify(result.data));
                } else {
                  console.log('ℹ️ Nenhum progresso no Supabase, criando novo');
                  // Criar progresso vazio
                  const emptyProgress = {
                    completedLessons: [],
                    studyTime: 0,
                    lastStudyDate: null,
                    studyStreak: 0,
                    achievements: [],
                    instrumentProgress: {},
                    startDate: new Date().toISOString()
                  };
                  localStorage.setItem(userProgressKey, JSON.stringify(emptyProgress));
                }
                // Redirecionar após carregar progresso
                window.location.href = '../../pages/app/app.html';
              }).catch(err => {
                console.warn('⚠️ Erro ao carregar progresso:', err);
                // Criar progresso vazio em caso de erro
                const emptyProgress = {
                  completedLessons: [],
                  studyTime: 0,
                  lastStudyDate: null,
                  studyStreak: 0,
                  achievements: [],
                  instrumentProgress: {},
                  startDate: new Date().toISOString()
                };
                localStorage.setItem(userProgressKey, JSON.stringify(emptyProgress));
                window.location.href = '../../pages/app/app.html';
              });
            } else {
              // Se SupabaseProgress não disponível, criar progresso vazio
              if(!localStorage.getItem(userProgressKey)){
                const emptyProgress = {
                  completedLessons: [],
                  studyTime: 0,
                  lastStudyDate: null,
                  studyStreak: 0,
                  achievements: [],
                  instrumentProgress: {},
                  startDate: new Date().toISOString()
                };
                localStorage.setItem(userProgressKey, JSON.stringify(emptyProgress));
                console.log(`Progresso inicial criado para ${data.user.email}`);
              }
              console.log('🚀 REDIRECIONANDO PARA APP.HTML (sem Supabase Progress)...');
              console.log('Sessão salva:', localStorage.getItem('ns-session'));
              setTimeout(() => {
                window.location.href = '../../pages/app/app.html';
              }, 100);
            }
          }
        } catch (err) {
          console.warn('⚠️ Erro ao conectar com Supabase:', err);
          tryLocalStorageLogin();
        }
      } else {
        console.warn('⚠️ Supabase não disponível - usando localStorage');
        tryLocalStorageLogin();
      }
      
      // FALLBACK: Login via localStorage
      function tryLocalStorageLogin() {
        console.log('🔄 Tentando login via localStorage...');
        const users = JSON.parse(localStorage.getItem('ns-users')||'[]');
        console.log('Total de usuários no localStorage:', users.length);
        console.log('Emails cadastrados:', users.map(u => u.email));
        console.log('Email buscado:', email);
        
        // Procurar usuário por email
        let userFound = users.find(u => u.email.toLowerCase().trim() === email);
        
        if (!userFound) {
          console.log('❌ Usuário não encontrado no localStorage');
          console.log('🔄 Criando usuário automaticamente para facilitar o login...');
          
          // AUTO-CRIAR usuário no localStorage para facilitar uso do sistema
          userFound = {
            name: email.split('@')[0],
            email: email,
            password: pass,
            role: 'student'
          };
          
          users.push(userFound);
          localStorage.setItem('ns-users', JSON.stringify(users));
          console.log('✅ Usuário criado automaticamente:', userFound.email);
          
          // Continuar com o login
          loginSuccess(userFound);
          return;
        }
        
        // Comparar senha (com suporte a senhas antigas em texto plano)
        let passwordMatch = false;
        
        if (userFound.password.startsWith('$')) {
          // Senha criptografada - comparar com hash
          if (window.passwordCrypto) {
            window.passwordCrypto.comparePassword(pass, userFound.password).then(match => {
              if (match) {
                loginSuccess(userFound);
              } else {
                showNotification(
                  'Senha incorreta',
                  'A senha está incorreta. Por favor, tente novamente.',
                  'error'
                );
              }
            });
            return;
          } else {
            console.warn('⚠️ Sistema de criptografia não disponível');
            passwordMatch = false;
          }
        } else {
          // Senha em texto plano (compatibilidade com dados antigos)
          passwordMatch = (pass === userFound.password);
        }
        
        if (passwordMatch) {
          loginSuccess(userFound);
        } else {
          console.log('❌ LOGIN FALHOU - Senha incorreta!');
          showNotification(
            'Senha incorreta',
            'A senha está incorreta. Por favor, tente novamente.',
            'error'
          );
        }
      }
      
      // Função para processar login bem-sucedido
      function loginSuccess(user) {
        console.log('✅ LOGIN LOCAL BEM-SUCEDIDO!');
        console.log('Usuário:', {
          name: user.name,
          email: user.email,
          role: user.role
        });
        
        localStorage.setItem('ns-session', JSON.stringify({
          email: user.email,
          name: user.name,
          role: user.role || 'student',
          user_id: user.id,           // ✅ Somente UUID, sem fallback para email
          supabase_id: user.id        // ✅ Somente UUID, sem fallback para email
        }));
        
        // Verificar se o usuário tem progresso
        const userProgressKey = `newsong-user-progress-${user.email}`;
        if(!localStorage.getItem(userProgressKey)){
          const emptyProgress = {
            completedLessons: [],
            studyTime: 0,
            lastStudyDate: null,
            studyStreak: 0,
            achievements: [],
            instrumentProgress: {},
            startDate: new Date().toISOString()
          };
          localStorage.setItem(userProgressKey, JSON.stringify(emptyProgress));
          console.log(`Progresso inicial criado para ${user.email}`);
        }
        
        console.log('🚀 REDIRECIONANDO PARA APP.HTML (localStorage)...');
        console.log('Sessão salva:', localStorage.getItem('ns-session'));
        console.log('Progresso salvo:', localStorage.getItem(userProgressKey) ? 'SIM' : 'NÃO');
        
        setTimeout(() => {
          window.location.href = '../../pages/app/app.html';
        }, 100);
      }
      
      console.log('===========================================');
    });
  }

  if(registerForm){
    registerForm.addEventListener('submit', async e=>{
      e.preventDefault();
      const name = document.getElementById('name').value.trim();
      const email = document.getElementById('email').value.toLowerCase().trim();
      const pass = document.getElementById('password').value;
      const accountType = document.querySelector('input[name="accountType"]:checked').value;
      
      console.log('=== REGISTRANDO USUÁRIO ====================');
      console.log('Nome:', name);
      console.log('Email:', email);
      console.log('Tipo:', accountType);
      
      // PRIORIDADE 1: Registrar no Supabase primeiro
      if (typeof window.supabase !== 'undefined' && window.supabase.auth) {
        try {
          console.log('🔄 Registrando no Supabase...');
          const {data, error} = await window.supabase.auth.signUp({
            email: email,
            password: pass,
            options: {
              data: {
                name: name,
                role: accountType
              }
            }
          });
          
          if (error) {
            console.warn('⚠️ Erro ao registrar no Supabase:', error.message);
            
            // Se o usuário já existe no Supabase, verificar localStorage
            if (error.message.includes('already registered') || error.message.includes('already exists')) {
              showNotification(
                'Email já cadastrado',
                'Este email já está registrado. Por favor, faça <strong>login</strong> ou use outro email.',
                'error'
              );
              return;
            }
            
            // Para outros erros, tentar salvar localmente
            console.log('Salvando localmente como fallback...');
            saveLocalUser();
          } else {
            console.log('✅ Registro no Supabase AUTH bem-sucedido!');
            console.log('User ID:', data.user?.id);
            
            // ⚠️ IMPORTANTE: Agora precisamos INSERIR NA TABELA 'users'
            console.log('🔄 Tentando inserir na tabela users customizada...');
            
            // Inserir diretamente na tabela users
            try {
              const { data: insertData, error: insertError } = await window.supabase
                .from('users')
                .insert([{
                  id: data.user.id,
                  email: email,
                  name: name,
                  role: accountType,
                  is_active: true,
                  created_at: new Date().toISOString()
                }])
                .select()
                .single();
              
              if (insertError) {
                console.error('❌ Erro ao inserir na tabela users:', insertError.message);
                console.log('⚠️ Usuário criado no AUTH mas não foi possível adicionar à tabela users');
                console.log('💡 SOLUÇÃO:');
                console.log('1. Abra o Supabase SQL Editor');
                console.log('2. Execute o arquivo: database/SETUP-AUTO-SYNC-USERS.sql');
                console.log('3. Isso criará um trigger automático para sincronizar contas');
                console.log('');
                console.log('OU sincronize manualmente via supabase-auth.syncUserToSupabase()');
                
                // Tentar sincronizar via função do supabase-auth
                if (window.SupabaseAuth && typeof window.SupabaseAuth.syncUserToSupabase === 'function') {
                  console.log('🔄 Tentando sincronizar via SupabaseAuth...');
                  const syncResult = await window.SupabaseAuth.syncUserToSupabase({
                    email: email,
                    name: name,
                    role: accountType
                  });
                  if (syncResult && syncResult.success) {
                    console.log('✅ Sincronizado com sucesso via SupabaseAuth!', syncResult.data);
                  }
                }
              } else {
                console.log('✅ Usuário inserido na tabela users com sucesso!', insertData);
                console.log('📊 Dados completos:', {
                  auth_id: data.user.id,
                  db_id: insertData.id,
                  email: insertData.email,
                  name: insertData.name,
                  role: insertData.role
                });
              }
            } catch (dbErr) {
              console.error('❌ Erro ao acessar tabela users:', dbErr);
              console.log('💡 Execute: database/SETUP-AUTO-SYNC-USERS.sql no Supabase SQL Editor');
            }
            
            // Criptografar senha antes de salvar localmente
            if (window.passwordCrypto) {
              window.passwordCrypto.hashPassword(pass).then(hashedPassword => {
                saveUser({
                  name, 
                  email, 
                  password: hashedPassword, 
                  role: accountType
                });
                
                console.log('✅ Usuário sincronizado no localStorage com senha criptografada');
                
                // Inicializar progresso
                const newUserProgressKey = `newsong-user-progress-${email}`;
                const emptyProgress = {
                  completedLessons: [],
                  studyTime: 0,
                  lastStudyDate: null,
                  studyStreak: 0,
                  achievements: [],
                  instrumentProgress: {},
                  startDate: new Date().toISOString()
                };
                localStorage.setItem(newUserProgressKey, JSON.stringify(emptyProgress));
                console.log(`Progresso inicial criado para ${email}`);
                
                showSuccessAndRedirect();
              });
            } else {
              // Fallback
              saveUser({name, email, password:pass, role:accountType});
              const newUserProgressKey = `newsong-user-progress-${email}`;
              const emptyProgress = {
                completedLessons: [],
                studyTime: 0,
                lastStudyDate: null,
                studyStreak: 0,
                achievements: [],
                instrumentProgress: {},
                startDate: new Date().toISOString()
              };
              localStorage.setItem(newUserProgressKey, JSON.stringify(emptyProgress));
              showSuccessAndRedirect();
            }
          }
        } catch (err) {
          console.warn('⚠️ Erro ao conectar com Supabase:', err);
          console.log('Salvando localmente como fallback...');
          saveLocalUser();
        }
      } else {
        console.warn('⚠️ Supabase não disponível - salvando apenas localmente');
        saveLocalUser();
      }
      
      // Função para salvar localmente
      function saveLocalUser() {
        // Verificar se o email já existe localmente
        const users = JSON.parse(localStorage.getItem('ns-users')||'[]');
        const emailExists = users.find(u => u.email.toLowerCase().trim() === email);
        
        if (emailExists) {
          showNotification(
            'Email já cadastrado',
            'Este email já está registrado localmente. Por favor, faça login ou use outro email.',
            'error'
          );
          return;
        }
        
        console.log('Salvando usuário no localStorage com senha criptografada...');
        
        // Criptografar senha antes de salvar
        if (window.passwordCrypto) {
          window.passwordCrypto.hashPassword(pass).then(hashedPassword => {
            saveUser({
              name, 
              email, 
              password: hashedPassword, 
              role: accountType
            });
            
            // Inicializar progresso vazio
            const newUserProgressKey = `newsong-user-progress-${email}`;
            const emptyProgress = {
              completedLessons: [],
              studyTime: 0,
              lastStudyDate: null,
              studyStreak: 0,
              achievements: [],
              instrumentProgress: {},
              startDate: new Date().toISOString()
            };
            localStorage.setItem(newUserProgressKey, JSON.stringify(emptyProgress));
            console.log(`Progresso inicial criado para ${email}`);
            
            showSuccessAndRedirect();
          });
        } else {
          // Fallback se crypto não disponível (manter compatibilidade)
          console.warn('⚠️ Sistema de criptografia não disponível - usando texto plano como fallback');
          saveUser({
            name, 
            email, 
            password: pass, 
            role: accountType
          });
          
          const newUserProgressKey = `newsong-user-progress-${email}`;
          const emptyProgress = {
            completedLessons: [],
            studyTime: 0,
            lastStudyDate: null,
            studyStreak: 0,
            achievements: [],
            instrumentProgress: {},
            startDate: new Date().toISOString()
          };
          localStorage.setItem(newUserProgressKey, JSON.stringify(emptyProgress));
          showSuccessAndRedirect();
        }
      }
      
      function showSuccessAndRedirect() {
        // Mensagens personalizadas por tipo de conta
        let welcomeTitle, welcomeMessage;
        
        if (accountType === 'teacher') {
          welcomeTitle = '🎓 Bem-vindo, Professor!';
          welcomeMessage = `Parabéns, ${name.split(' ')[0]}! 🎉<br><br>
            Sua conta de <strong>professor</strong> foi criada com sucesso! 🎸🎹🥁<br><br>
            Agora você pode fazer login e começar a compartilhar seu conhecimento musical com alunos do mundo todo. 
            Prepare suas aulas, grave vídeos incríveis e inspire a próxima geração de músicos! 🌟<br><br>
            <em>Você será redirecionado para a página de login em instantes...</em>`;
        } else {
          welcomeTitle = '🎉 Bem-vindo ao NewSong!';
          welcomeMessage = `Parabéns, ${name.split(' ')[0]}! 🎊<br><br>
            Sua conta foi criada com sucesso! 🎸🎹🥁<br><br>
            Agora você pode fazer login e começar sua jornada musical com os melhores instrutores. 
            Desenvolva suas habilidades, aprenda novos instrumentos e alcance seus objetivos musicais! 🚀<br><br>
            <em>Você será redirecionado para a página de login em instantes...</em>`;
        }
        
        showNotification(
          welcomeTitle,
          welcomeMessage,
          'success'
        );
        
        setTimeout(() => {
          window.location.href = '../../pages/auth/login.html';
        }, 3000);
      }
    });
  }

  // ====================================
  // COMANDOS DE CONSOLE PARA DEBUG
  // ====================================
  window.SupabaseAdmin = {
    // Ver sessão ativa
    async verSessao() {
      if (!window.supabase) {
        console.error('❌ Supabase não disponível');
        return null;
      }
      const { data: { session }, error } = await window.supabase.auth.getSession();
      if (error) {
        console.error('❌ Erro:', error);
        return null;
      }
      if (!session) {
        console.log('ℹ️ Nenhuma sessão ativa');
        return null;
      }
      console.log('✅ Sessão ativa:');
      console.table({
        Email: session.user.email,
        ID: session.user.id,
        'Último Login': new Date(session.user.last_sign_in_at).toLocaleString('pt-BR')
      });
      return session;
    },

    // Ver usuários do Supabase
    async verUsuarios() {
      if (!window.supabase) {
        console.error('❌ Supabase não disponível');
        return [];
      }
      const { data: users, error } = await window.supabase
        .from('users')
        .select('*')
        .order('created_at', { ascending: false });
      
      if (error) {
        console.error('❌ Erro:', error.message);
        return [];
      }
      
      console.log(`✅ ${users.length} usuário(s) na tabela 'users' (fizeram login):`);
      console.table(users.map(u => ({
        Nome: u.name,
        Email: u.email,
        Tipo: u.role,
        Status: u.is_active ? '✅ Ativo' : '❌ Inativo'
      })));
      return users;
    },

    // Ver contas criadas (localStorage)
    verContasCriadas() {
      const users = JSON.parse(localStorage.getItem('ns-users') || '[]');
      console.log(`📦 ${users.length} conta(s) no localStorage:`);
      console.table(users.map(u => ({
        Nome: u.name,
        Email: u.email,
        Tipo: u.role
      })));
      return users;
    },

    // Fazer logout
    async logout() {
      if (!window.supabase) {
        console.error('❌ Supabase não disponível');
        return;
      }
      const { error } = await window.supabase.auth.signOut();
      if (error) {
        console.error('❌ Erro ao fazer logout:', error);
      } else {
        console.log('✅ Logout realizado com sucesso');
        localStorage.removeItem('ns-session');
      }
    },

    // Ver info completa
    async info() {
      console.log('=== INFORMAÇÕES DO SISTEMA ===\n');
      
      console.log('📡 Supabase:', window.supabase ? '✅ Disponível' : '❌ Não disponível');
      
      const localSession = localStorage.getItem('ns-session');
      console.log('💾 Sessão Local:', localSession ? '✅ Existe' : '❌ Não existe');
      
      console.log('\n=== DIFERENÇA IMPORTANTE ===');
      console.log('🔵 Criar conta (signUp) → Cria a conta mas NÃO loga automaticamente');
      console.log('🟢 Fazer login (signIn) → Cria uma SESSÃO ativa');
      console.log('📊 Tabela "users" → Só mostra quem já fez LOGIN ao menos 1 vez\n');
      
      if (window.supabase) {
        await this.verSessao();
        console.log('\n--- Usuários que FIZERAM LOGIN ---');
        await this.verUsuarios();
      }
      
      console.log('\n--- Contas CRIADAS (localStorage) ---');
      this.verContasCriadas();
      
      console.log('\n📋 Comandos disponíveis:');
      console.log('  SupabaseAdmin.verSessao() - Ver quem está LOGADO agora');
      console.log('  SupabaseAdmin.verUsuarios() - Ver quem já fez LOGIN alguma vez');
      console.log('  SupabaseAdmin.verContasCriadas() - Ver contas criadas (local)');
      console.log('  SupabaseAdmin.logout() - Fazer logout');
      console.log('  SupabaseAdmin.info() - Ver estas informações');
    }
  };

  console.log('💡 Digite "SupabaseAdmin.info()" para ver comandos disponíveis');
})();