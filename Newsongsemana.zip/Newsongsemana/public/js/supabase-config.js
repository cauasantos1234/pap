// supabase-config.js - Configuração do Supabase
console.log('🔄 Carregando supabase-config.js...');

const SUPABASE_CONFIG = {
  url: 'https://wbzaktlcxgmctocgtifj.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndiemFrdGxjeGdtY3RvY2d0aWZqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjU3NjEzNTEsImV4cCI6MjA4MTMzNzM1MX0.i3I01z8CT1l6kBPhNwk8bgRwJP4Jq5MO3Rn2dEsoJSM'
};

let supabaseClient = null;

function initSupabase() {
  if (supabaseClient) {
    console.log('ℹ️ Supabase já está inicializado');
    return true;
  }
  
  console.log('🔍 Verificando biblioteca Supabase...');
  console.log('window.supabase existe?', typeof window.supabase !== 'undefined');
  console.log('window.supabase.createClient existe?', typeof window.supabase?.createClient === 'function');
  
  // Verificar se a biblioteca Supabase foi carregada
  if (typeof window.supabase !== 'undefined' && typeof window.supabase.createClient === 'function') {
    try {
      console.log('🔄 Criando cliente Supabase...');
      console.log('URL:', SUPABASE_CONFIG.url);
      console.log('Key (primeiros 20 chars):', SUPABASE_CONFIG.anonKey.substring(0, 20) + '...');
      
      supabaseClient = window.supabase.createClient(SUPABASE_CONFIG.url, SUPABASE_CONFIG.anonKey);
      console.log('✅ Supabase inicializado com sucesso!');
      
      // Tornar globalmente acessível
      window.supabaseClient = supabaseClient;
      
      return true;
    } catch (error) {
      console.error('❌ Erro ao inicializar Supabase:', error);
      console.error('Stack:', error.stack);
      return false;
    }
  }
  
  console.warn('⚠️ Biblioteca Supabase ainda não carregada');
  return false;
}

// Aguardar a biblioteca carregar e então inicializar
function waitAndInit(attempts = 0) {
  if (attempts > 50) {
    console.error('❌ TIMEOUT ao aguardar biblioteca Supabase (5 segundos)');
    console.error('💡 Verifique se o script CDN está carregando:');
    console.error('   <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>');
    return;
  }
  
  if (attempts === 0) {
    console.log('⏳ Aguardando biblioteca Supabase carregar...');
  }
  
  if (initSupabase()) {
    console.log('✅ Supabase pronto para uso!');
    console.log('🔗 Cliente acessível via: window.supabaseClient');
  } else {
    if (attempts % 10 === 0 && attempts > 0) {
      console.log(`⏳ Ainda aguardando... (tentativa ${attempts}/50)`);
    }
    setTimeout(() => waitAndInit(attempts + 1), 100);
  }
}

// Iniciar processo
console.log('🚀 Iniciando configuração do Supabase...');
waitAndInit();

window.SupabaseAPI = {
  getClient: function() {
    if (!supabaseClient) initSupabase();
    return supabaseClient;
  },
  getConfig: function() {
    return SUPABASE_CONFIG;
  },
  isReady: function() {
    return supabaseClient !== null;
  }
};

