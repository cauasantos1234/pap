-- ========================================
-- SINCRONIZAÇÃO AUTOMÁTICA DE USUÁRIOS
-- Execute este SQL no Supabase SQL Editor
-- ========================================

-- 1. Criar função para sincronizar usuário automaticamente
CREATE OR REPLACE FUNCTION public.handle_new_user() 
RETURNS trigger AS $$
BEGIN
  INSERT INTO public.users (id, email, name, role, is_active, created_at)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'name', split_part(NEW.email, '@', 1)),
    COALESCE(NEW.raw_user_meta_data->>'role', 'student'),
    true,
    NEW.created_at
  )
  ON CONFLICT (id) DO UPDATE
  SET 
    email = EXCLUDED.email,
    name = COALESCE(EXCLUDED.name, users.name),
    role = COALESCE(EXCLUDED.role, users.role),
    updated_at = NOW();
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- 2. Criar trigger para executar automaticamente quando criar conta
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 3. Atualizar trigger para UPDATE também (caso email/metadata mude)
DROP TRIGGER IF EXISTS on_auth_user_updated ON auth.users;
CREATE TRIGGER on_auth_user_updated
  AFTER UPDATE ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- 4. Garantir que as políticas RLS permitem inserção
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Permitir INSERT (necessário para o trigger funcionar)
DROP POLICY IF EXISTS "Allow insert users" ON public.users;
CREATE POLICY "Allow insert users" 
ON public.users FOR INSERT 
WITH CHECK (true);

-- Permitir SELECT para todos (necessário para listagem)
DROP POLICY IF EXISTS "Allow select users" ON public.users;
CREATE POLICY "Allow select users" 
ON public.users FOR SELECT 
USING (true);

-- Permitir UPDATE apenas para o próprio usuário
DROP POLICY IF EXISTS "Allow update own user" ON public.users;
CREATE POLICY "Allow update own user" 
ON public.users FOR UPDATE 
USING (auth.uid() = id);

-- Permitir DELETE apenas para o próprio usuário ou admin
DROP POLICY IF EXISTS "Allow delete own user" ON public.users;
CREATE POLICY "Allow delete own user" 
ON public.users FOR DELETE 
USING (auth.uid() = id OR EXISTS (
  SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin'
));

-- 5. Sincronizar usuários existentes do auth.users para public.users
INSERT INTO public.users (id, email, name, role, is_active, created_at)
SELECT 
  au.id,
  au.email,
  COALESCE(au.raw_user_meta_data->>'name', split_part(au.email, '@', 1)),
  COALESCE(au.raw_user_meta_data->>'role', 'student'),
  true,
  au.created_at
FROM auth.users au
WHERE au.id NOT IN (SELECT id FROM public.users)
ON CONFLICT (id) DO NOTHING;

-- 6. Criar função auxiliar para admin ver todos usuários do Auth
CREATE OR REPLACE FUNCTION get_all_auth_users()
RETURNS TABLE (
  id uuid,
  email text,
  created_at timestamptz,
  last_sign_in_at timestamptz,
  email_confirmed_at timestamptz,
  role text
) 
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY 
  SELECT 
    au.id,
    au.email,
    au.created_at,
    au.last_sign_in_at,
    au.email_confirmed_at,
    au.raw_user_meta_data->>'role' as role
  FROM auth.users au
  ORDER BY au.created_at DESC;
END;
$$ LANGUAGE plpgsql;

GRANT EXECUTE ON FUNCTION get_all_auth_users() TO anon, authenticated;

-- 7. Verificar se funcionou
SELECT 
  'auth.users' as tabela,
  COUNT(*) as total
FROM auth.users
UNION ALL
SELECT 
  'public.users' as tabela,
  COUNT(*) as total
FROM public.users;

-- Deve mostrar o mesmo número em ambas as tabelas!
