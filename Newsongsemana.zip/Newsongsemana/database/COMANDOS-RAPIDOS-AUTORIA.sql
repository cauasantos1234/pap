-- =====================================================
-- 🚀 COMANDOS RÁPIDOS - Verificação de Autoria
-- Cole estes comandos no Supabase SQL Editor
-- =====================================================

-- ========== VERIFICAÇÃO 1: Ver estrutura atual ==========
SELECT column_name, data_type, is_nullable
FROM information_schema.columns
WHERE table_name = 'videos' 
  AND column_name LIKE '%upload%' 
  OR column_name LIKE '%author%'
  OR column_name LIKE '%teacher%'
ORDER BY ordinal_position;

-- ========== VERIFICAÇÃO 2: Contar vídeos órfãos ==========
-- (Deveria retornar 0)
SELECT 
  COUNT(*) as total_orfaos,
  'PROBLEMA: Vídeos sem autor definido' as status
FROM videos
WHERE uploaded_by IS NULL 
   OR uploaded_by_email IS NULL 
   OR uploaded_by_email = '';

-- ========== VERIFICAÇÃO 3: Listar professores ==========
SELECT 
  id,
  email,
  name,
  role,
  created_at::DATE as cadastro
FROM users
WHERE role IN ('teacher', 'professor')
ORDER BY created_at;

-- ========== VERIFICAÇÃO 4: Ver últimos 10 vídeos ==========
SELECT 
  v.id,
  v.title,
  v.uploaded_by_email as email_autor,
  v.uploaded_by_name as nome_autor,
  v.instrument,
  v.module,
  v.created_at::DATE as postado_em,
  -- Status
  CASE 
    WHEN v.uploaded_by IS NULL THEN '❌ ÓRFÃO'
    WHEN v.uploaded_by_email IS NULL THEN '⚠️ SEM EMAIL'
    ELSE '✅ OK'
  END as status
FROM videos v
ORDER BY v.created_at DESC
LIMIT 10;

-- ========== VERIFICAÇÃO 5: Contagem por professor ==========
SELECT 
  COALESCE(uploaded_by_email, 'SEM EMAIL') as professor,
  COALESCE(uploaded_by_name, 'SEM NOME') as nome,
  COUNT(*) as total_videos,
  MAX(created_at)::DATE as ultimo_video
FROM videos
GROUP BY uploaded_by_email, uploaded_by_name
ORDER BY total_videos DESC;

-- ========== VERIFICAÇÃO 6: Ver vídeos com divergência ==========
-- (Email e nome não batem com o usuário real)
SELECT 
  v.id,
  v.title,
  v.uploaded_by_email as email_video,
  u.email as email_real,
  v.uploaded_by_name as nome_video,
  u.name as nome_real,
  CASE 
    WHEN v.uploaded_by_email != u.email THEN '⚠️ EMAIL DIFERENTE'
    WHEN v.uploaded_by_name != u.name THEN '⚠️ NOME DIFERENTE'
    ELSE '✅ OK'
  END as status
FROM videos v
LEFT JOIN users u ON v.uploaded_by = u.id
WHERE v.uploaded_by IS NOT NULL
  AND (v.uploaded_by_email != u.email OR v.uploaded_by_name != u.name)
ORDER BY v.created_at DESC;

-- ========== VERIFICAÇÃO 7: Autenticação Supabase ==========
-- Ver usuários no auth.users e se existem em users
SELECT 
  au.id,
  au.email,
  au.created_at::DATE as auth_criado,
  u.id IS NOT NULL as existe_em_users,
  u.role as role_usuario
FROM auth.users au
LEFT JOIN users u ON au.id = u.id
ORDER BY au.created_at DESC
LIMIT 10;

-- ========== RESUMO GERAL ==========
SELECT 
  (SELECT COUNT(*) FROM videos) as total_videos,
  (SELECT COUNT(*) FROM videos WHERE uploaded_by IS NULL) as videos_sem_uploaded_by,
  (SELECT COUNT(*) FROM videos WHERE uploaded_by_email IS NULL) as videos_sem_email,
  (SELECT COUNT(*) FROM videos WHERE teacher_email IS NULL) as videos_sem_teacher_email,
  (SELECT COUNT(*) FROM users WHERE role IN ('teacher', 'professor')) as total_professores,
  (SELECT COUNT(DISTINCT uploaded_by_email) FROM videos WHERE uploaded_by_email IS NOT NULL) as professores_com_videos;

-- =====================================================
-- 📊 INTERPRETAÇÃO DOS RESULTADOS
-- =====================================================

/*
✅ ESTÁ OK SE:
- videos_sem_uploaded_by = 0
- videos_sem_email = 0  
- todos os vídeos têm autor definido
- não há divergências entre email_video e email_real

⚠️ TEM PROBLEMA SE:
- videos_sem_uploaded_by > 0  (vídeos órfãos)
- videos_sem_email > 0         (vídeos sem email)
- há divergências de autoria   (email diferente do esperado)

🔧 AÇÕES:
1. Se há vídeos órfãos → Execute CORRIGIR-AUTORIA-VIDEOS.sql
2. Se há divergências → Identifique os IDs e corrija manualmente
3. Se tudo OK → Teste fazer novo upload

*/

-- =====================================================
-- 🔥 CORREÇÃO RÁPIDA (USE COM CUIDADO!)
-- =====================================================

-- ⚠️ DESCOMENTE APENAS SE SOUBER O QUE ESTÁ FAZENDO!
-- Substitua 'SEU-EMAIL@newsong.com' pelo email correto

/*
-- OPÇÃO 1: Associar TODOS os vídeos órfãos a você
UPDATE videos
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'SEU-EMAIL@newsong.com'),
  uploaded_by_email = 'SEU-EMAIL@newsong.com',
  teacher_email = 'SEU-EMAIL@newsong.com',
  uploaded_by_name = (SELECT name FROM users WHERE email = 'SEU-EMAIL@newsong.com')
WHERE 
  uploaded_by IS NULL 
  OR uploaded_by_email IS NULL 
  OR uploaded_by_email = '';

-- Ver resultado
SELECT COUNT(*) as videos_corrigidos
FROM videos
WHERE uploaded_by_email = 'SEU-EMAIL@newsong.com';
*/

-- =====================================================
-- 📝 APÓS CORREÇÃO, RE-EXECUTE AS VERIFICAÇÕES
-- =====================================================
