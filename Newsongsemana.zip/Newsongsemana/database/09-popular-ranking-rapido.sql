-- =====================================================
-- SOLUÇÃO RÁPIDA: Popular Ranking com Dados Ordenados
-- =====================================================

-- =====================================================
-- PASSO 1: Popular com XP ORDENADO e FUNCIONAL
-- =====================================================
-- Cria um ranking ordenado onde usuários mais antigos têm mais XP

WITH ranked_users AS (
  SELECT 
    id as user_id,
    email,
    created_at,
    ROW_NUMBER() OVER (ORDER BY created_at ASC) as position,
    COUNT(*) OVER () as total_users
  FROM auth.users
)
INSERT INTO user_xp (user_id, total_xp, level, current_streak, longest_streak, last_activity_date)
SELECT 
  user_id,
  -- XP decrescente: primeiro usuário tem mais XP
  CASE 
    WHEN position = 1 THEN 2500  -- Mestre (primeiro usuário)
    WHEN position = 2 THEN 1800  -- Mestre
    WHEN position = 3 THEN 1300  -- Expert
    WHEN position = 4 THEN 950   -- Dedicado
    WHEN position = 5 THEN 700   -- Dedicado
    WHEN position = 6 THEN 450   -- Estudante
    WHEN position = 7 THEN 280   -- Aprendiz
    WHEN position = 8 THEN 150   -- Aprendiz
    WHEN position = 9 THEN 80    -- Iniciante
    WHEN position = 10 THEN 50   -- Iniciante
    ELSE GREATEST(20, (total_users - position + 1) * 10)::INTEGER
  END as total_xp,
  1 as level, -- Será recalculado
  -- Streak decrescente também
  CASE 
    WHEN position <= 3 THEN 15 - (position - 1) * 3  -- 15, 12, 9
    WHEN position <= 6 THEN 8 - (position - 4)       -- 8, 7, 6
    WHEN position <= 10 THEN 5 - (position - 7)      -- 5, 4, 3, 2
    ELSE 1
  END as current_streak,
  -- Longest streak sempre maior ou igual ao current
  CASE 
    WHEN position <= 2 THEN 30 + (2 - position) * 10
    WHEN position <= 5 THEN 20 + (5 - position) * 3
    ELSE 10 + (10 - position)
  END as longest_streak,
  CURRENT_DATE as last_activity_date
FROM ranked_users
ON CONFLICT (user_id) 
DO UPDATE SET 
  total_xp = EXCLUDED.total_xp,
  level = EXCLUDED.level,
  current_streak = EXCLUDED.current_streak,
  longest_streak = EXCLUDED.longest_streak,
  last_activity_date = EXCLUDED.last_activity_date,
  updated_at = NOW();

-- PASSO 2: Atualizar os níveis baseado no XP
UPDATE user_xp
SET level = calculate_level(total_xp),
    updated_at = NOW();

-- PASSO 3: Registrar transações iniciais (apenas para usuários novos)
INSERT INTO xp_transactions (user_id, xp_amount, action_type, description)
SELECT 
  user_id,
  total_xp,
  'initial_setup',
  'XP inicial do sistema - distribuição ordenada'
FROM user_xp
WHERE user_id NOT IN (
  SELECT DISTINCT user_id FROM xp_transactions WHERE action_type = 'initial_setup'
);

-- PASSO 4: Verificar o ranking ordenado
SELECT '✅ Ranking atualizado e ordenado!' as status;

-- Ver estatísticas
SELECT 
  '📊 ESTATÍSTICAS DO RANKING' as info,
  COUNT(*) as total_usuarios,
  MAX(total_xp) as maior_xp,
  MIN(total_xp) as menor_xp,
  ROUND(AVG(total_xp)) as xp_medio
FROM user_xp;

-- Ver Top 10 ordenado
SELECT * FROM ranking_by_xp LIMIT 10;

-- =====================================================
-- OPÇÃO ALTERNATIVA: DEFINIR XP MANUALMENTE POR EMAIL
-- =====================================================
-- Descomente e ajuste para controlar exatamente quem tem quanto XP

/*
-- Limpar dados existentes (CUIDADO: Remove todo o ranking!)
-- DELETE FROM xp_transactions WHERE action_type = 'initial_setup';
-- DELETE FROM user_xp;

-- Definir XP específico por usuário
DO $$
DECLARE
  v_user_id UUID;
BEGIN
  -- Usuário 1 - Líder do ranking
  SELECT id INTO v_user_id FROM auth.users WHERE email = 'joao@newsong.com' LIMIT 1;
  IF v_user_id IS NOT NULL THEN
    INSERT INTO user_xp (user_id, total_xp, level, current_streak, longest_streak, last_activity_date)
    VALUES (v_user_id, 2500, 6, 15, 40, CURRENT_DATE)
    ON CONFLICT (user_id) DO UPDATE SET 
      total_xp = 2500, current_streak = 15, longest_streak = 40;
  END IF;

  -- Usuário 2
  SELECT id INTO v_user_id FROM auth.users WHERE email = 'professor@newsong.com' LIMIT 1;
  IF v_user_id IS NOT NULL THEN
    INSERT INTO user_xp (user_id, total_xp, level, current_streak, longest_streak, last_activity_date)
    VALUES (v_user_id, 1800, 6, 12, 35, CURRENT_DATE)
    ON CONFLICT (user_id) DO UPDATE SET 
      total_xp = 1800, current_streak = 12, longest_streak = 35;
  END IF;

  -- Usuário 3
  SELECT id INTO v_user_id FROM auth.users WHERE email = 'cauasantos@gmail.com' LIMIT 1;
  IF v_user_id IS NOT NULL THEN
    INSERT INTO user_xp (user_id, total_xp, level, current_streak, longest_streak, last_activity_date)
    VALUES (v_user_id, 1300, 5, 9, 28, CURRENT_DATE)
    ON CONFLICT (user_id) DO UPDATE SET 
      total_xp = 1300, current_streak = 9, longest_streak = 28;
  END IF;

  -- Continue adicionando outros usuários conforme necessário...
  
  -- Atualizar níveis
  UPDATE user_xp SET level = calculate_level(total_xp);
  
  RAISE NOTICE '✅ XP definido manualmente para usuários específicos';
END $$;
*/

-- =====================================================
-- VERIFICAÇÕES E ESTATÍSTICAS DETALHADAS
-- =====================================================

-- 1. Total de usuários no ranking
SELECT '📊 TOTAL DE USUÁRIOS:' as info;
SELECT COUNT(*) as total_usuarios_com_xp FROM user_xp;

-- 2. Distribuição por nível (quantos usuários em cada nível)
SELECT '📈 DISTRIBUIÇÃO POR NÍVEL:' as info;
SELECT 
  level as nivel,
  COUNT(*) as quantidade_usuarios,
  MIN(total_xp) as xp_minimo,
  MAX(total_xp) as xp_maximo,
  ROUND(AVG(total_xp)) as xp_medio
FROM user_xp
GROUP BY level
ORDER BY level;

-- 3. Top 10 do Ranking por XP (ORDENADO)
SELECT '🏆 TOP 10 RANKING POR XP (ORDENADO):' as info;
SELECT 
  rank as posicao,
  user_name as nome,
  total_xp as xp_total,
  level as nivel,
  current_streak as dias_consecutivos,
  longest_streak as maior_streak
FROM ranking_by_xp
LIMIT 10;

-- 4. Top 5 por Streak
SELECT '🔥 TOP 5 MAIORES STREAKS:' as info;
SELECT 
  rank as posicao,
  user_name as nome,
  current_streak as dias_consecutivos,
  longest_streak as recorde_streak,
  total_xp as xp_total,
  level as nivel
FROM ranking_by_streak
LIMIT 5;

-- 5. Ver todos os usuários ordenados por XP
SELECT '📋 RANKING COMPLETO:' as info;
SELECT 
  u.email,
  ux.total_xp,
  ux.level,
  ux.current_streak,
  ux.longest_streak,
  (SELECT COUNT(*) + 1 FROM user_xp ux2 WHERE ux2.total_xp > ux.total_xp) as posicao
FROM user_xp ux
JOIN auth.users u ON ux.user_id = u.id
ORDER BY ux.total_xp DESC;

-- 6. Verificar se há duplicatas ou inconsistências
SELECT '🔍 VERIFICAÇÃO DE INTEGRIDADE:' as info;
SELECT 
  CASE 
    WHEN COUNT(DISTINCT user_id) = COUNT(*) THEN '✅ Sem duplicatas'
    ELSE '⚠️ Há duplicatas!'
  END as verificacao_duplicatas,
  CASE 
    WHEN MIN(total_xp) >= 0 THEN '✅ XP válido'
    ELSE '⚠️ XP negativo encontrado!'
  END as verificacao_xp,
  CASE 
    WHEN MIN(level) > 0 THEN '✅ Níveis válidos'
    ELSE '⚠️ Nível inválido!'
  END as verificacao_nivel
FROM user_xp;
