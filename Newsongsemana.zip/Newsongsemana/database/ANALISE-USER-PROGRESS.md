# 📊 ANÁLISE COMPLETA: TABELA USER_PROGRESS

## 🔍 O QUE A TABELA TEM ATUALMENTE:

### Colunas Existentes (16 no total):
```
1. id (UUID) - Primary Key
2. user_id (UUID, NULLABLE) ⚠️ - Deveria ser NOT NULL
3. instrument (text) - Qual instrumento (guitar, piano, etc)
4. module (text) - Qual módulo
5. lesson_id (integer) - ID da lição
6. video_id (UUID) - ID do vídeo
7. completed (boolean) - Se completou
8. progress_percentage (integer) - % de progresso
9. last_watched_at (timestamp) - Última visualização
10. completed_lessons (integer[]) - Array de lições completas
11. study_time_minutes (integer) - Tempo total de estudo
12. study_streak (integer) - Sequência de dias estudando
13. last_study_date (timestamp) - Última data de estudo
14. achievements (text[]) - Array de conquistas
15. instrument_progress (jsonb) - Progresso detalhado por instrumento
16. created_at (timestamp) - Data de criação
```

---

## ❌ PROBLEMAS IDENTIFICADOS:

### 1. **Mistura de Conceitos**
A tabela mistura dois tipos de dados:
- ✅ Progresso INDIVIDUAL de vídeo/lição (correto)
- ❌ Dados GERAIS do usuário (estudo, streak, achievements)

**Problema:** Se o usuário assistiu 10 vídeos, vai ter `study_streak` e `achievements` repetidos 10 vezes!

### 2. **user_id pode ser NULL**
- ❌ Um progresso SEM usuário não faz sentido
- ❌ Impossível fazer JOIN confiável com `users`
- ❌ Queries precisam sempre verificar `WHERE user_id IS NOT NULL`

### 3. **Falta updated_at**
- ❌ Sem controle de sincronização
- ❌ Impossível saber qual dado é mais recente (local vs remoto)
- ❌ Problemas ao mesclar dados

### 4. **Falta user_email**
- ⚠️ Todas as queries precisam fazer JOIN com users
- ⚠️ Mais lento e complexo

### 5. **Não tem XP e Level totais**
- ❌ XP e Level estão APENAS no localStorage
- ❌ Se o usuário trocar de PC, perde tudo
- ❌ Impossível fazer ranking no servidor

---

## ✅ O QUE ESTÁ FALTANDO:

### Dados Críticos Ausentes:
1. **XP Total do Usuário** (INT)
2. **Level Geral** (INT)
3. **updated_at** (TIMESTAMP) - Para sincronização
4. **Constraint NOT NULL em user_id**
5. **Foreign Key para users(id)**
6. **Índices otimizados**

---

## 🎯 SOLUÇÃO IDEAL: SEPARAR EM 2 TABELAS

### OPÇÃO A: Separar Completamente (Recomendado)

#### 1️⃣ **users_stats** (Novo - Dados Gerais do Usuário)
```sql
CREATE TABLE users_stats (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    user_email VARCHAR(255) NOT NULL,
    
    -- XP e Progressão
    total_xp INTEGER DEFAULT 0,
    level INTEGER DEFAULT 1,
    
    -- Estudo e Streak
    streak_days INTEGER DEFAULT 0,
    last_study_date TIMESTAMP WITH TIME ZONE,
    total_study_time_minutes INTEGER DEFAULT 0,
    
    -- Conquistas
    achievements TEXT[] DEFAULT '{}',
    
    -- Controle
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Índices
CREATE INDEX idx_users_stats_user_id ON users_stats(user_id);
CREATE INDEX idx_users_stats_email ON users_stats(user_email);
CREATE INDEX idx_users_stats_xp ON users_stats(total_xp DESC);
CREATE INDEX idx_users_stats_level ON users_stats(level DESC);

-- Trigger para updated_at
CREATE TRIGGER users_stats_updated_at
    BEFORE UPDATE ON users_stats
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();
```

#### 2️⃣ **video_progress** (Renomear user_progress - Progresso por Vídeo)
```sql
-- Manter a tabela atual mas LIMPAR os campos duplicados
ALTER TABLE user_progress RENAME TO video_progress;

-- Adicionar campos faltantes
ALTER TABLE video_progress
    ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    ADD COLUMN IF NOT EXISTS user_email VARCHAR(255),
    ADD COLUMN IF NOT EXISTS watch_count INTEGER DEFAULT 0;

-- Tornar user_id obrigatório
UPDATE video_progress SET user_id = gen_random_uuid() WHERE user_id IS NULL;
ALTER TABLE video_progress ALTER COLUMN user_id SET NOT NULL;

-- Adicionar FK
ALTER TABLE video_progress
    ADD CONSTRAINT fk_video_progress_user
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

-- REMOVER campos duplicados (que estão em users_stats)
ALTER TABLE video_progress
    DROP COLUMN IF EXISTS study_streak,
    DROP COLUMN IF EXISTS last_study_date,
    DROP COLUMN IF EXISTS achievements,
    DROP COLUMN IF EXISTS study_time_minutes;

-- Adicionar constraint único (usuário não pode ter progresso duplicado no mesmo vídeo)
ALTER TABLE video_progress
    ADD CONSTRAINT unique_user_video
    UNIQUE (user_id, video_id);

-- Índices
CREATE INDEX idx_video_progress_user ON video_progress(user_id);
CREATE INDEX idx_video_progress_video ON video_progress(video_id);
CREATE INDEX idx_video_progress_completed ON video_progress(completed);
```

---

### OPÇÃO B: Corrigir Tabela Atual (Mais Simples)

Se quiser manter a estrutura atual mas corrigir problemas:

```sql
-- 1. Adicionar campos faltantes
ALTER TABLE user_progress
    ADD COLUMN IF NOT EXISTS total_xp INTEGER DEFAULT 0,
    ADD COLUMN IF NOT EXISTS level INTEGER DEFAULT 1,
    ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    ADD COLUMN IF NOT EXISTS user_email VARCHAR(255);

-- 2. Corrigir user_id NULL
UPDATE user_progress SET user_id = gen_random_uuid() WHERE user_id IS NULL;
ALTER TABLE user_progress ALTER COLUMN user_id SET NOT NULL;

-- 3. Adicionar Foreign Key
ALTER TABLE user_progress
    ADD CONSTRAINT fk_user_progress_user
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

-- 4. Preencher user_email baseado em user_id
UPDATE user_progress up
SET user_email = u.email
FROM users u
WHERE up.user_id = u.id AND up.user_email IS NULL;

-- 5. Criar índices
CREATE INDEX IF NOT EXISTS idx_user_progress_user_id ON user_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_user_progress_email ON user_progress(user_email);
CREATE INDEX IF NOT EXISTS idx_user_progress_xp ON user_progress(total_xp DESC);
```

---

## 🏆 RECOMENDAÇÃO FINAL

### ✅ **OPÇÃO A** é melhor porque:
1. ✅ Sem duplicação de dados
2. ✅ Queries mais rápidas
3. ✅ Fácil fazer ranking (users_stats)
4. ✅ Separa responsabilidades
5. ✅ Escalável

### ⚠️ **OPÇÃO B** é mais simples mas:
- ⚠️ Mantém duplicação de dados
- ⚠️ Mais difícil de manter consistência
- ⚠️ Queries mais complexas

---

## 📝 SCRIPT DE MIGRAÇÃO COMPLETO (OPÇÃO A)

### Passo 1: Criar users_stats
```sql
-- Criar nova tabela
CREATE TABLE users_stats (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL UNIQUE REFERENCES users(id) ON DELETE CASCADE,
    user_email VARCHAR(255) NOT NULL,
    total_xp INTEGER DEFAULT 0,
    level INTEGER DEFAULT 1,
    streak_days INTEGER DEFAULT 0,
    last_study_date TIMESTAMP WITH TIME ZONE,
    total_study_time_minutes INTEGER DEFAULT 0,
    achievements TEXT[] DEFAULT '{}',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Migrar dados agregados de user_progress
INSERT INTO users_stats (user_id, user_email, streak_days, last_study_date, total_study_time_minutes, achievements, created_at)
SELECT DISTINCT ON (user_id)
    user_id,
    u.email,
    COALESCE(up.study_streak, 0),
    up.last_study_date,
    COALESCE(up.study_time_minutes, 0),
    COALESCE(up.achievements, '{}'),
    up.created_at
FROM user_progress up
JOIN users u ON up.user_id = u.id
WHERE up.user_id IS NOT NULL
ORDER BY user_id, last_watched_at DESC;

-- Índices
CREATE INDEX idx_users_stats_user_id ON users_stats(user_id);
CREATE INDEX idx_users_stats_email ON users_stats(user_email);
CREATE INDEX idx_users_stats_xp ON users_stats(total_xp DESC);
```

### Passo 2: Limpar user_progress
```sql
-- Renomear
ALTER TABLE user_progress RENAME TO video_progress;

-- Remover colunas duplicadas
ALTER TABLE video_progress
    DROP COLUMN IF EXISTS study_streak,
    DROP COLUMN IF EXISTS last_study_date,
    DROP COLUMN IF EXISTS achievements,
    DROP COLUMN IF EXISTS study_time_minutes;

-- Adicionar campos necessários
ALTER TABLE video_progress
    ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    ADD COLUMN IF NOT EXISTS watch_count INTEGER DEFAULT 1;

-- Corrigir user_id NULL
DELETE FROM video_progress WHERE user_id IS NULL;
ALTER TABLE video_progress ALTER COLUMN user_id SET NOT NULL;

-- Foreign Key
ALTER TABLE video_progress
    ADD CONSTRAINT fk_video_progress_user
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

-- Constraint único
ALTER TABLE video_progress
    ADD CONSTRAINT unique_user_video
    UNIQUE (user_id, video_id);
```

---

## 🎯 QUAL OPÇÃO VOCÊ QUER?

1. **OPÇÃO A - Separar em 2 tabelas** (Recomendado) ✅
2. **OPÇÃO B - Apenas corrigir a atual** (Mais simples) ⚠️

Me diga qual você prefere e eu executo a migração! 🚀
