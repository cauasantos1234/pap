        -- ============================================
        -- SISTEMA DE NOTIFICAÇÕES COMPLETO - NewSong
        -- Separado por tipo de usuário (Professor e Aluno)
        -- Data: 2026-01-28
        -- ============================================

        -- ============================================
        -- 1. CRIAR TABELAS NECESSÁRIAS
        -- ============================================

        -- Tabela de comentários (se não existir)
        CREATE TABLE IF NOT EXISTS comments (
        id SERIAL PRIMARY KEY,
        video_id INTEGER REFERENCES videos(id) ON DELETE CASCADE,
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        user_email VARCHAR(255) NOT NULL,
        parent_id INTEGER REFERENCES comments(id) ON DELETE CASCADE,
        content TEXT NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        is_edited BOOLEAN DEFAULT false,
        likes INTEGER DEFAULT 0
        );

        CREATE INDEX IF NOT EXISTS idx_comments_video ON comments(video_id);
        CREATE INDEX IF NOT EXISTS idx_comments_user ON comments(user_id);
        CREATE INDEX IF NOT EXISTS idx_comments_parent ON comments(parent_id);
        CREATE INDEX IF NOT EXISTS idx_comments_created ON comments(created_at DESC);

        -- RLS para comentários
        ALTER TABLE comments ENABLE ROW LEVEL SECURITY;

        DROP POLICY IF EXISTS comments_select_all ON comments;
        CREATE POLICY comments_select_all ON comments
        FOR SELECT USING (true);

        DROP POLICY IF EXISTS comments_insert_own ON comments;
        CREATE POLICY comments_insert_own ON comments
        FOR INSERT WITH CHECK (auth.uid() = user_id);

        DROP POLICY IF EXISTS comments_update_own ON comments;
        CREATE POLICY comments_update_own ON comments
        FOR UPDATE USING (auth.uid() = user_id);

        DROP POLICY IF EXISTS comments_delete_own ON comments;
        CREATE POLICY comments_delete_own ON comments
        FOR DELETE USING (auth.uid() = user_id);

        -- Tabela de notificações (se não existir)
        CREATE TABLE IF NOT EXISTS notifications (
        id SERIAL PRIMARY KEY,
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        user_email VARCHAR(255) NOT NULL,
        type VARCHAR(50) NOT NULL,
        title VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        link VARCHAR(500),
        is_read BOOLEAN DEFAULT FALSE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        read_at TIMESTAMP WITH TIME ZONE,
        metadata JSONB DEFAULT '{}'::jsonb
        );

        CREATE INDEX IF NOT EXISTS idx_notifications_user ON notifications(user_email);
        CREATE INDEX IF NOT EXISTS idx_notifications_user_id ON notifications(user_id);
        CREATE INDEX IF NOT EXISTS idx_notifications_is_read ON notifications(is_read);
        CREATE INDEX IF NOT EXISTS idx_notifications_type ON notifications(type);
        CREATE INDEX IF NOT EXISTS idx_notifications_created ON notifications(created_at DESC);
        CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(user_email, is_read);

        -- RLS para notificações
        ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

        DROP POLICY IF EXISTS notifications_select_own ON notifications;
        CREATE POLICY notifications_select_own ON notifications
        FOR SELECT USING (auth.uid() = user_id OR user_email = auth.email());

        DROP POLICY IF EXISTS notifications_insert_all ON notifications;
        CREATE POLICY notifications_insert_all ON notifications
        FOR INSERT WITH CHECK (true);

        DROP POLICY IF EXISTS notifications_update_own ON notifications;
        CREATE POLICY notifications_update_own ON notifications
        FOR UPDATE USING (auth.uid() = user_id OR user_email = auth.email());

        -- Tabela de curtidas em vídeos
        CREATE TABLE IF NOT EXISTS video_likes (
        id SERIAL PRIMARY KEY,
        video_id INTEGER REFERENCES videos(id) ON DELETE CASCADE,
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        user_email VARCHAR(255) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        
        UNIQUE(video_id, user_id)
        );

        CREATE INDEX IF NOT EXISTS idx_video_likes_video ON video_likes(video_id);
        CREATE INDEX IF NOT EXISTS idx_video_likes_user ON video_likes(user_id);

        -- Tabela de curtidas em comentários
        CREATE TABLE IF NOT EXISTS comment_likes (
        id SERIAL PRIMARY KEY,
        comment_id INTEGER REFERENCES comments(id) ON DELETE CASCADE,
        user_id UUID REFERENCES users(id) ON DELETE CASCADE,
        user_email VARCHAR(255) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        
        UNIQUE(comment_id, user_id)
        );

        CREATE INDEX IF NOT EXISTS idx_comment_likes_comment ON comment_likes(comment_id);
        CREATE INDEX IF NOT EXISTS idx_comment_likes_user ON comment_likes(user_id);

        -- Tabela de seguidores (alunos seguem professores)
        CREATE TABLE IF NOT EXISTS follows (
        id SERIAL PRIMARY KEY,
        follower_id UUID REFERENCES users(id) ON DELETE CASCADE, -- Aluno que segue
        follower_email VARCHAR(255) NOT NULL,
        following_id UUID REFERENCES users(id) ON DELETE CASCADE, -- Professor seguido
        following_email VARCHAR(255) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        
        UNIQUE(follower_id, following_id)
        );

        CREATE INDEX IF NOT EXISTS idx_follows_follower ON follows(follower_id);
        CREATE INDEX IF NOT EXISTS idx_follows_following ON follows(following_id);

        -- ============================================
        -- 2. ATUALIZAR TABELA DE NOTIFICAÇÕES
        -- ============================================

        -- Adicionar novos tipos de notificação se não existirem
        DO $$ 
        BEGIN
        -- Não precisa alterar a tabela, só documentar os novos tipos:
        -- PROFESSOR:
        --   'rating_received' - Nova avaliação
        --   'feedback_received' - Feedback do aluno (resposta)
        --   'video_liked' - Curtida no vídeo
        --   'new_follower' - Novo seguidor
        --   'video_comment' - Comentário no vídeo
        --
        -- ALUNO:
        --   'new_video_following' - Vídeo novo de professor seguido
        --   'ranking_up' - Subiu no ranking
        --   'comment_liked' - Curtida no comentário
        --   'achievement' - Conquista desbloqueada
        END $$;

        -- ============================================
        -- 3. TRIGGER: Notificar professor ao receber curtida no vídeo
        -- ============================================
        CREATE OR REPLACE FUNCTION notify_teacher_on_video_like()
        RETURNS TRIGGER AS $$
        DECLARE
        v_teacher_id UUID;
        v_teacher_email VARCHAR;
        v_video_title VARCHAR;
        v_liker_name VARCHAR;
        v_total_likes INTEGER;
        BEGIN
        -- Buscar dados do vídeo e professor
        SELECT v.uploaded_by_id, v.uploaded_by_email, v.title
        INTO v_teacher_id, v_teacher_email, v_video_title
        FROM videos v
        WHERE v.id = NEW.video_id;
        
        -- Buscar nome de quem curtiu
        SELECT name INTO v_liker_name
        FROM users
        WHERE id = NEW.user_id;
        
        -- Contar total de curtidas no vídeo
        SELECT COUNT(*) INTO v_total_likes
        FROM video_likes
        WHERE video_id = NEW.video_id;
        
        -- Criar notificação para o professor
        IF v_teacher_id IS NOT NULL AND v_teacher_id != NEW.user_id THEN
            INSERT INTO notifications (
            user_id,
            user_email,
            type,
            title,
            message,
            link,
            metadata
            ) VALUES (
            v_teacher_id,
            v_teacher_email,
            'video_liked',
            '❤️ Curtida no Vídeo',
            COALESCE(v_liker_name, 'Alguém') || ' curtiu seu vídeo "' || v_video_title || '" (' || v_total_likes || ' curtidas)',
            'videos.html?id=' || NEW.video_id,
            jsonb_build_object(
                'video_id', NEW.video_id,
                'liker_id', NEW.user_id,
                'liker_email', NEW.user_email,
                'total_likes', v_total_likes
            )
            );
        END IF;
        
        RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;

        DROP TRIGGER IF EXISTS trigger_notify_teacher_on_video_like ON video_likes;
        CREATE TRIGGER trigger_notify_teacher_on_video_like
        AFTER INSERT ON video_likes
        FOR EACH ROW
        EXECUTE FUNCTION notify_teacher_on_video_like();

        -- ============================================
        -- 4. TRIGGER: Notificar professor ao receber novo seguidor
        -- ============================================
        CREATE OR REPLACE FUNCTION notify_teacher_on_new_follower()
        RETURNS TRIGGER AS $$
        DECLARE
        v_teacher_name VARCHAR;
        v_follower_name VARCHAR;
        v_total_followers INTEGER;
        BEGIN
        -- Buscar nomes
        SELECT name INTO v_teacher_name
        FROM users
        WHERE id = NEW.following_id;
        
        SELECT name INTO v_follower_name
        FROM users
        WHERE id = NEW.follower_id;
        
        -- Contar total de seguidores
        SELECT COUNT(*) INTO v_total_followers
        FROM follows
        WHERE following_id = NEW.following_id;
        
        -- Criar notificação para o professor
        INSERT INTO notifications (
            user_id,
            user_email,
            type,
            title,
            message,
            link,
            metadata
        ) VALUES (
            NEW.following_id,
            NEW.following_email,
            'new_follower',
            '👥 Novo Seguidor',
            COALESCE(v_follower_name, 'Um aluno') || ' começou a seguir você! (' || v_total_followers || ' seguidores)',
            'profile.html',
            jsonb_build_object(
            'follower_id', NEW.follower_id,
            'follower_email', NEW.follower_email,
            'total_followers', v_total_followers
            )
        );
        
        RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;

        DROP TRIGGER IF EXISTS trigger_notify_teacher_on_new_follower ON follows;
        CREATE TRIGGER trigger_notify_teacher_on_new_follower
        AFTER INSERT ON follows
        FOR EACH ROW
        EXECUTE FUNCTION notify_teacher_on_new_follower();

        -- ============================================
        -- 5. TRIGGER: Notificar professor ao receber comentário
        -- ============================================
        CREATE OR REPLACE FUNCTION notify_teacher_on_video_comment()
        RETURNS TRIGGER AS $$
        DECLARE
        v_teacher_id UUID;
        v_teacher_email VARCHAR;
        v_video_title VARCHAR;
        v_commenter_name VARCHAR;
        BEGIN
        -- Buscar dados do vídeo e professor
        SELECT v.uploaded_by_id, v.uploaded_by_email, v.title
        INTO v_teacher_id, v_teacher_email, v_video_title
        FROM videos v
        WHERE v.id = NEW.video_id;
        
        -- Buscar nome de quem comentou
        SELECT name INTO v_commenter_name
        FROM users
        WHERE id = NEW.user_id;
        
        -- Criar notificação para o professor (se não for ele mesmo comentando)
        IF v_teacher_id IS NOT NULL AND v_teacher_id != NEW.user_id THEN
            INSERT INTO notifications (
            user_id,
            user_email,
            type,
            title,
            message,
            link,
            metadata
            ) VALUES (
            v_teacher_id,
            v_teacher_email,
            'video_comment',
            '💬 Novo Comentário',
            COALESCE(v_commenter_name, 'Alguém') || ' comentou em "' || v_video_title || '"',
            'videos.html?id=' || NEW.video_id,
            jsonb_build_object(
                'video_id', NEW.video_id,
                'comment_id', NEW.id,
                'commenter_id', NEW.user_id
            )
            );
        END IF;
        
        RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;

        DROP TRIGGER IF EXISTS trigger_notify_teacher_on_video_comment ON comments;
        CREATE TRIGGER trigger_notify_teacher_on_video_comment
        AFTER INSERT ON comments
        FOR EACH ROW
        EXECUTE FUNCTION notify_teacher_on_video_comment();

        -- ============================================
        -- 6. TRIGGER: Notificar aluno sobre vídeo novo de professor seguido
        -- ============================================
        CREATE OR REPLACE FUNCTION notify_followers_on_new_video()
        RETURNS TRIGGER AS $$
        DECLARE
        v_follower RECORD;
        BEGIN
        -- Notificar apenas seguidores do professor
        FOR v_follower IN 
            SELECT f.follower_id, f.follower_email, u.name as follower_name
            FROM follows f
            JOIN users u ON u.id = f.follower_id
            WHERE f.following_id = NEW.uploaded_by_id
            AND u.is_active = TRUE
        LOOP
            INSERT INTO notifications (
            user_id,
            user_email,
            type,
            title,
            message,
            link,
            metadata
            ) VALUES (
            v_follower.follower_id,
            v_follower.follower_email,
            'new_video_following',
            '🎥 Novo Vídeo do Professor',
            NEW.uploaded_by_name || ' postou: "' || NEW.title || '"',
            'videos.html?id=' || NEW.id,
            jsonb_build_object(
                'video_id', NEW.id,
                'teacher_id', NEW.uploaded_by_id,
                'teacher_name', NEW.uploaded_by_name,
                'instrument', NEW.instrument
            )
            );
        END LOOP;
        
        RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;

        DROP TRIGGER IF EXISTS trigger_notify_followers_on_new_video ON videos;
        CREATE TRIGGER trigger_notify_followers_on_new_video
        AFTER INSERT ON videos
        FOR EACH ROW
        EXECUTE FUNCTION notify_followers_on_new_video();

        -- ============================================
        -- 7. TRIGGER: Notificar aluno sobre curtida no comentário
        -- ============================================
        CREATE OR REPLACE FUNCTION notify_user_on_comment_like()
        RETURNS TRIGGER AS $$
        DECLARE
        v_comment_author_id UUID;
        v_comment_author_email VARCHAR;
        v_liker_name VARCHAR;
        v_video_title VARCHAR;
        BEGIN
        -- Buscar autor do comentário
        SELECT c.user_id, u.email
        INTO v_comment_author_id, v_comment_author_email
        FROM comments c
        JOIN users u ON u.id = c.user_id
        WHERE c.id = NEW.comment_id;
        
        -- Buscar nome de quem curtiu
        SELECT name INTO v_liker_name
        FROM users
        WHERE id = NEW.user_id;
        
        -- Buscar título do vídeo
        SELECT v.title INTO v_video_title
        FROM videos v
        JOIN comments c ON c.video_id = v.id
        WHERE c.id = NEW.comment_id;
        
        -- Criar notificação (se não for o próprio autor curtindo)
        IF v_comment_author_id IS NOT NULL AND v_comment_author_id != NEW.user_id THEN
            INSERT INTO notifications (
            user_id,
            user_email,
            type,
            title,
            message,
            link,
            metadata
            ) VALUES (
            v_comment_author_id,
            v_comment_author_email,
            'comment_liked',
            '👍 Curtida no Comentário',
            COALESCE(v_liker_name, 'Alguém') || ' curtiu seu comentário em "' || v_video_title || '"',
            'videos.html?id=' || (SELECT video_id FROM comments WHERE id = NEW.comment_id),
            jsonb_build_object(
                'comment_id', NEW.comment_id,
                'liker_id', NEW.user_id,
                'liker_email', NEW.user_email
            )
            );
        END IF;
        
        RETURN NEW;
        END;
        $$ LANGUAGE plpgsql;

        DROP TRIGGER IF EXISTS trigger_notify_user_on_comment_like ON comment_likes;
        CREATE TRIGGER trigger_notify_user_on_comment_like
        AFTER INSERT ON comment_likes
        FOR EACH ROW
        EXECUTE FUNCTION notify_user_on_comment_like();

        -- ============================================
        -- 8. FUNÇÃO: Notificar mudanças no ranking (executar manualmente)
        -- ============================================
        CREATE OR REPLACE FUNCTION notify_ranking_changes()
        RETURNS void AS $$
        DECLARE
        v_user RECORD;
        v_old_position INTEGER;
        v_new_position INTEGER;
        v_ranking_type VARCHAR;
        BEGIN
        -- Esta função deve ser chamada após recalcular o ranking
        -- Por exemplo, em um job agendado ou após inserir XP
        
        -- Exemplo para ranking de streak semanal
        -- (Você precisará adaptar conforme sua lógica de ranking)
        
        FOR v_user IN 
            SELECT DISTINCT user_email FROM user_xp WHERE is_active = TRUE
        LOOP
            -- Aqui você compara a posição antiga com a nova
            -- Este é um placeholder - você precisa implementar a lógica real
            -- baseado em como seu ranking funciona
            
            NULL; -- Implementar lógica de comparação de posições
        END LOOP;
        END;
        $$ LANGUAGE plpgsql;

        -- ============================================
        -- 9. FUNÇÃO AUXILIAR: Criar notificação de ranking manualmente
        -- ============================================
        CREATE OR REPLACE FUNCTION create_ranking_notification(
        p_user_email VARCHAR,
        p_ranking_type VARCHAR, -- 'xp', 'streak', 'level'
        p_old_position INTEGER,
        p_new_position INTEGER
        )
        RETURNS void AS $$
        DECLARE
        v_user_id UUID;
        v_positions_gained INTEGER;
        BEGIN
        -- Buscar user_id
        SELECT id INTO v_user_id FROM users WHERE email = p_user_email;
        
        v_positions_gained := p_old_position - p_new_position;
        
        -- Só notificar se subiu
        IF v_positions_gained > 0 THEN
            INSERT INTO notifications (
            user_id,
            user_email,
            type,
            title,
            message,
            link,
            metadata
            ) VALUES (
            v_user_id,
            p_user_email,
            'ranking_up',
            '🏆 Você Subiu no Ranking!',
            'Parabéns! Você subiu ' || v_positions_gained || ' posição(ões) no ranking de ' || 
                CASE p_ranking_type
                WHEN 'xp' THEN 'XP'
                WHEN 'streak' THEN 'Streak Semanal'
                WHEN 'level' THEN 'Nível'
                ELSE 'Geral'
                END,
            'ranking.html',
            jsonb_build_object(
                'ranking_type', p_ranking_type,
                'old_position', p_old_position,
                'new_position', p_new_position,
                'positions_gained', v_positions_gained
            )
            );
        END IF;
        END;
        $$ LANGUAGE plpgsql;

        -- ============================================
        -- 10. RLS POLICIES PARA NOVAS TABELAS
        -- ============================================

        -- Video Likes
        ALTER TABLE video_likes ENABLE ROW LEVEL SECURITY;

        DROP POLICY IF EXISTS video_likes_select_all ON video_likes;
        CREATE POLICY video_likes_select_all ON video_likes
        FOR SELECT USING (true);

        DROP POLICY IF EXISTS video_likes_insert_own ON video_likes;
        CREATE POLICY video_likes_insert_own ON video_likes
        FOR INSERT WITH CHECK (auth.uid() = user_id);

        DROP POLICY IF EXISTS video_likes_delete_own ON video_likes;
        CREATE POLICY video_likes_delete_own ON video_likes
        FOR DELETE USING (auth.uid() = user_id);

        -- Comment Likes
        ALTER TABLE comment_likes ENABLE ROW LEVEL SECURITY;

        DROP POLICY IF EXISTS comment_likes_select_all ON comment_likes;
        CREATE POLICY comment_likes_select_all ON comment_likes
        FOR SELECT USING (true);

        DROP POLICY IF EXISTS comment_likes_insert_own ON comment_likes;
        CREATE POLICY comment_likes_insert_own ON comment_likes
        FOR INSERT WITH CHECK (auth.uid() = user_id);

        DROP POLICY IF EXISTS comment_likes_delete_own ON comment_likes;
        CREATE POLICY comment_likes_delete_own ON comment_likes
        FOR DELETE USING (auth.uid() = user_id);

        -- Follows
        ALTER TABLE follows ENABLE ROW LEVEL SECURITY;

        DROP POLICY IF EXISTS follows_select_all ON follows;
        CREATE POLICY follows_select_all ON follows
        FOR SELECT USING (true);

        DROP POLICY IF EXISTS follows_insert_own ON follows;
        CREATE POLICY follows_insert_own ON follows
        FOR INSERT WITH CHECK (auth.uid() = follower_id);

        DROP POLICY IF EXISTS follows_delete_own ON follows;
        CREATE POLICY follows_delete_own ON follows
        FOR DELETE USING (auth.uid() = follower_id);

        -- ============================================
        -- 11. ATUALIZAR TRIGGERS ANTIGOS
        -- ============================================

        -- Remover trigger antigo de notificação para todos os alunos
        DROP TRIGGER IF EXISTS trigger_notify_students_on_new_video ON videos;
        DROP FUNCTION IF EXISTS notify_students_on_new_video();

        -- Agora só notifica seguidores (já criado acima)

        -- ============================================
        -- 12. FUNÇÕES AUXILIARES
        -- ============================================

        -- Contar notificações não lidas por tipo
        CREATE OR REPLACE FUNCTION count_unread_by_type(p_user_email VARCHAR)
        RETURNS TABLE(type VARCHAR, count BIGINT) AS $$
        BEGIN
        RETURN QUERY
        SELECT n.type, COUNT(*)::BIGINT
        FROM notifications n
        WHERE n.user_email = p_user_email
            AND n.is_read = FALSE
        GROUP BY n.type;
        END;
        $$ LANGUAGE plpgsql;

        -- ============================================
        -- ✅ CONCLUÍDO!
        -- ============================================

        -- RESUMO DO SISTEMA:
        -- 
        -- NOTIFICAÇÕES PARA PROFESSORES:
        -- 1. ⭐ rating_received - Nova avaliação
        -- 2. 💬 feedback_received - Feedback de resposta
        -- 3. ❤️ video_liked - Curtida no vídeo
        -- 4. 👥 new_follower - Novo seguidor
        -- 5. 💬 video_comment - Comentário no vídeo
        --
        -- NOTIFICAÇÕES PARA ALUNOS:
        -- 1. 🎥 new_video_following - Vídeo de professor seguido
        -- 2. 🏆 ranking_up - Subiu no ranking
        -- 3. 👍 comment_liked - Curtida no comentário
        -- 4. 🎯 achievement - Conquista (criar trigger separado)
        --
        -- AÇÕES NECESSÁRIAS DO USUÁRIO:
        -- 1. Executar este SQL no Supabase
        -- 2. Implementar função JavaScript para curtir vídeos (video_likes)
        -- 3. Implementar função JavaScript para curtir comentários (comment_likes)
        -- 4. Implementar função JavaScript para seguir professores (follows)
        -- 5. Criar job/cron para chamar notify_ranking_changes() periodicamente
        -- 6. Atualizar notification-bell.js com os novos tipos de notificação
