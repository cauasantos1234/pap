-- ============================================
-- FUNÇÕES AUXILIARES PARA CURTIDAS
-- Incrementar/decrementar contador de curtidas em comentários
-- ============================================

-- Incrementar curtidas do comentário
CREATE OR REPLACE FUNCTION increment_comment_likes(comment_id INTEGER)
RETURNS void AS $$
BEGIN
  UPDATE comments
  SET likes = likes + 1
  WHERE id = comment_id;
END;
$$ LANGUAGE plpgsql;

-- Decrementar curtidas do comentário
CREATE OR REPLACE FUNCTION decrement_comment_likes(comment_id INTEGER)
RETURNS void AS $$
BEGIN
  UPDATE comments
  SET likes = GREATEST(likes - 1, 0)
  WHERE id = comment_id;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- EXECUTAR ANTES DO 18-sistema-notificacoes-completo.sql
-- ============================================
