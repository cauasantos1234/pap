-- ============================================
-- SISTEMA DE NOTIFICAÇÕES - NewSong
-- Tabela para gerenciar notificações de usuários
-- Data: 2026-01-28
-- ============================================

-- Criar tabela de notificações
CREATE TABLE IF NOT EXISTS notifications (
  id SERIAL PRIMARY KEY,
  user_id UUID REFERENCES users(id) ON DELETE CASCADE,
  user_email VARCHAR(255) NOT NULL,
  type VARCHAR(50) NOT NULL, -- 'new_video', 'rating_received', 'comment', 'achievement', 'feedback_received'
  title VARCHAR(255) NOT NULL,
  message TEXT NOT NULL,
  link VARCHAR(500), -- Link para a página/vídeo relacionado
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  read_at TIMESTAMP WITH TIME ZONE,
  
  -- Dados extras (JSON)
  metadata JSONB DEFAULT '{}'::jsonb
);

-- Índices para melhorar performance
CREATE INDEX idx_notifications_user ON notifications(user_email);
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);
CREATE INDEX idx_notifications_type ON notifications(type);
CREATE INDEX idx_notifications_created ON notifications(created_at DESC);
CREATE INDEX idx_notifications_user_read ON notifications(user_email, is_read);

-- ============================================
-- FUNÇÃO: Criar notificação
-- ============================================
CREATE OR REPLACE FUNCTION create_notification(
  p_user_email VARCHAR,
  p_type VARCHAR,
  p_title VARCHAR,
  p_message TEXT,
  p_link VARCHAR DEFAULT NULL,
  p_metadata JSONB DEFAULT '{}'::jsonb
)
RETURNS INTEGER AS $$
DECLARE
  v_user_id UUID;
  v_notification_id INTEGER;
BEGIN
  -- Buscar user_id
  SELECT id INTO v_user_id
  FROM users
  WHERE email = p_user_email
  LIMIT 1;
  
  -- Inserir notificação
  INSERT INTO notifications (
    user_id,
    user_email,
    type,
    title,
    message,
    link,
    metadata
  ) VALUES (
    v_user_id,
    p_user_email,
    p_type,
    p_title,
    p_message,
    p_link,
    p_metadata
  )
  RETURNING id INTO v_notification_id;
  
  RETURN v_notification_id;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- FUNÇÃO: Marcar notificação como lida
-- ============================================
CREATE OR REPLACE FUNCTION mark_notification_read(p_notification_id INTEGER)
RETURNS BOOLEAN AS $$
BEGIN
  UPDATE notifications
  SET 
    is_read = TRUE,
    read_at = NOW()
  WHERE id = p_notification_id;
  
  RETURN FOUND;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- FUNÇÃO: Marcar todas notificações como lidas
-- ============================================
CREATE OR REPLACE FUNCTION mark_all_notifications_read(p_user_email VARCHAR)
RETURNS INTEGER AS $$
DECLARE
  v_count INTEGER;
BEGIN
  UPDATE notifications
  SET 
    is_read = TRUE,
    read_at = NOW()
  WHERE 
    user_email = p_user_email AND
    is_read = FALSE;
  
  GET DIAGNOSTICS v_count = ROW_COUNT;
  RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- FUNÇÃO: Contar notificações não lidas
-- ============================================
CREATE OR REPLACE FUNCTION count_unread_notifications(p_user_email VARCHAR)
RETURNS INTEGER AS $$
DECLARE
  v_count INTEGER;
BEGIN
  SELECT COUNT(*)
  INTO v_count
  FROM notifications
  WHERE 
    user_email = p_user_email AND
    is_read = FALSE;
  
  RETURN v_count;
END;
$$ LANGUAGE plpgsql;

-- ============================================
-- TRIGGER: Notificar professor quando recebe avaliação
-- ============================================
CREATE OR REPLACE FUNCTION notify_teacher_on_rating()
RETURNS TRIGGER AS $$
DECLARE
  v_teacher_email VARCHAR;
  v_teacher_user_id UUID;
  v_student_name VARCHAR;
BEGIN
  -- Buscar email do professor
  SELECT email, id INTO v_teacher_email, v_teacher_user_id
  FROM users
  WHERE name = NEW.teacher_name
  LIMIT 1;
  
  -- Buscar nome do aluno
  SELECT name INTO v_student_name
  FROM users
  WHERE email = NEW.user_email
  LIMIT 1;
  
  -- Se professor encontrado, criar notificação
  IF v_teacher_email IS NOT NULL THEN
    INSERT INTO notifications (
      user_id,
      user_email,
      type,
      title,
      message,
      link,
      metadata
    ) VALUES (
      v_teacher_user_id,
      v_teacher_email,
      'rating_received',
      '⭐ Nova Avaliação Recebida',
      COALESCE(v_student_name, 'Um aluno') || ' avaliou sua aula com ' || NEW.rating || ' estrelas',
      'feedbacks.html',
      jsonb_build_object(
        'rating', NEW.rating,
        'student_email', NEW.user_email,
        'student_name', v_student_name,
        'lesson_id', NEW.lesson_id
      )
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_notify_teacher_on_rating
AFTER INSERT ON teacher_ratings
FOR EACH ROW
EXECUTE FUNCTION notify_teacher_on_rating();

-- ============================================
-- TRIGGER: Notificar aluno quando recebe feedback do professor
-- ============================================
CREATE OR REPLACE FUNCTION notify_student_on_feedback()
RETURNS TRIGGER AS $$
DECLARE
  v_student_email VARCHAR;
  v_student_id UUID;
  v_teacher_name VARCHAR;
BEGIN
  -- Se o comentário acabou de ser adicionado (era NULL e agora não é)
  IF OLD.comment IS NULL AND NEW.comment IS NOT NULL THEN
    -- Buscar dados do aluno
    SELECT id INTO v_student_id
    FROM users
    WHERE email = NEW.user_email
    LIMIT 1;
    
    -- Criar notificação para o aluno
    INSERT INTO notifications (
      user_id,
      user_email,
      type,
      title,
      message,
      link,
      metadata
    ) VALUES (
      v_student_id,
      NEW.user_email,
      'feedback_received',
      '💬 Feedback do Professor',
      NEW.teacher_name || ' respondeu sua avaliação',
      'profile.html#feedbacks',
      jsonb_build_object(
        'teacher_name', NEW.teacher_name,
        'rating_id', NEW.id,
        'lesson_id', NEW.lesson_id
      )
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_notify_student_on_feedback
AFTER UPDATE ON teacher_ratings
FOR EACH ROW
EXECUTE FUNCTION notify_student_on_feedback();

-- ============================================
-- TRIGGER: Notificar alunos sobre novos vídeos
-- ============================================
CREATE OR REPLACE FUNCTION notify_students_on_new_video()
RETURNS TRIGGER AS $$
DECLARE
  v_student RECORD;
BEGIN
  -- Notificar todos os alunos ativos
  FOR v_student IN 
    SELECT id, email, name
    FROM users
    WHERE role IN ('student', 'aluno') AND is_active = TRUE
  LOOP
    INSERT INTO notifications (
      user_id,
      user_email,
      type,
      title,
      message,
      link,
      metadata
    ) VALUES (
      v_student.id,
      v_student.email,
      'new_video',
      '🎥 Novo Vídeo Disponível',
      'Nova aula de ' || NEW.instrument || ' - ' || NEW.title,
      'videos.html?instrument=' || NEW.instrument || '&module=' || NEW.module,
      jsonb_build_object(
        'video_id', NEW.id,
        'instrument', NEW.instrument,
        'module', NEW.module,
        'teacher', NEW.uploaded_by_name
      )
    );
  END LOOP;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_notify_students_on_new_video
AFTER INSERT ON videos
FOR EACH ROW
EXECUTE FUNCTION notify_students_on_new_video();

-- ============================================
-- VIEW: Notificações recentes (últimas 50)
-- ============================================
CREATE OR REPLACE VIEW recent_notifications AS
SELECT 
  n.id,
  n.user_email,
  n.type,
  n.title,
  n.message,
  n.link,
  n.is_read,
  n.created_at,
  n.read_at,
  n.metadata,
  u.name as user_name,
  u.avatar_url as user_avatar
FROM notifications n
LEFT JOIN users u ON n.user_id = u.id
ORDER BY n.created_at DESC
LIMIT 50;

-- ============================================
-- POLÍTICAS RLS (Row Level Security)
-- ============================================

-- Ativar RLS
ALTER TABLE notifications ENABLE ROW LEVEL SECURITY;

-- Usuários podem ver apenas suas próprias notificações
CREATE POLICY notifications_select_own ON notifications
FOR SELECT
USING (
  user_email = current_setting('request.jwt.claims', true)::json->>'email'
  OR EXISTS (
    SELECT 1 FROM users 
    WHERE users.id::text = current_setting('request.jwt.claims', true)::json->>'sub'
    AND users.role IN ('admin', 'teacher', 'professor')
  )
);

-- Permitir inserção de notificações
CREATE POLICY notifications_insert_all ON notifications
FOR INSERT
WITH CHECK (true);

-- Usuários podem atualizar apenas suas próprias notificações
CREATE POLICY notifications_update_own ON notifications
FOR UPDATE
USING (
  user_email = current_setting('request.jwt.claims', true)::json->>'email'
);

-- ============================================
-- CONSULTAS ÚTEIS
-- ============================================

-- Ver notificações não lidas de um usuário
-- SELECT * FROM notifications WHERE user_email = 'aluno@newsong.com' AND is_read = FALSE ORDER BY created_at DESC;

-- Contar notificações não lidas
-- SELECT count_unread_notifications('aluno@newsong.com');

-- Marcar notificação como lida
-- SELECT mark_notification_read(1);

-- Marcar todas como lidas
-- SELECT mark_all_notifications_read('aluno@newsong.com');

-- Ver estatísticas de notificações
-- SELECT 
--   type,
--   COUNT(*) as total,
--   COUNT(*) FILTER (WHERE is_read = TRUE) as lidas,
--   COUNT(*) FILTER (WHERE is_read = FALSE) as nao_lidas
-- FROM notifications
-- GROUP BY type
-- ORDER BY total DESC;

-- Limpar notificações antigas (mais de 30 dias)
-- DELETE FROM notifications WHERE created_at < NOW() - INTERVAL '30 days';

COMMENT ON TABLE notifications IS 'Armazena notificações de usuários (novos vídeos, avaliações, feedbacks)';
COMMENT ON COLUMN notifications.type IS 'Tipo: new_video, rating_received, feedback_received, comment, achievement';
COMMENT ON COLUMN notifications.metadata IS 'Dados extras em formato JSON';
COMMENT ON FUNCTION create_notification IS 'Cria uma nova notificação para um usuário';
COMMENT ON FUNCTION mark_notification_read IS 'Marca uma notificação como lida';
COMMENT ON FUNCTION mark_all_notifications_read IS 'Marca todas notificações de um usuário como lidas';
COMMENT ON FUNCTION count_unread_notifications IS 'Conta notificações não lidas de um usuário';
