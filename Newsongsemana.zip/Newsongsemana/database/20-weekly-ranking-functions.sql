-- =====================================================
-- FUNÇÕES PARA RANKING SEMANAL
-- =====================================================
-- Funções para suportar o ranking de melhores alunos da semana

-- =====================================================
-- FUNÇÃO: get_weekly_ranking
-- Retorna os top usuários com mais XP
-- =====================================================
CREATE OR REPLACE FUNCTION get_weekly_ranking(limit_count INTEGER DEFAULT 10)
RETURNS TABLE (
  user_id UUID,
  full_name TEXT,
  email TEXT,
  total_xp INTEGER,
  current_streak INTEGER,
  level INTEGER,
  rank INTEGER
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    ux.user_id,
    COALESCE(u.raw_user_meta_data->>'full_name', 'Usuário') as full_name,
    u.email,
    ux.total_xp,
    ux.current_streak,
    ux.level,
    ROW_NUMBER() OVER (ORDER BY ux.total_xp DESC, ux.current_streak DESC)::INTEGER as rank
  FROM user_xp ux
  INNER JOIN auth.users u ON u.id = ux.user_id
  WHERE ux.total_xp > 0
  ORDER BY ux.total_xp DESC, ux.current_streak DESC
  LIMIT limit_count;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================
-- FUNÇÃO: get_user_rank
-- Retorna a posição de um usuário específico no ranking
-- =====================================================
CREATE OR REPLACE FUNCTION get_user_rank(p_user_id UUID)
RETURNS INTEGER AS $$
DECLARE
  user_rank INTEGER;
BEGIN
  SELECT rank INTO user_rank
  FROM (
    SELECT 
      user_id,
      ROW_NUMBER() OVER (ORDER BY total_xp DESC, current_streak DESC) as rank
    FROM user_xp
    WHERE total_xp > 0
  ) ranked
  WHERE user_id = p_user_id;
  
  RETURN COALESCE(user_rank, 0);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================
-- FUNÇÃO: get_top_3_users
-- Retorna os 3 melhores usuários (pódio)
-- =====================================================
CREATE OR REPLACE FUNCTION get_top_3_users()
RETURNS TABLE (
  user_id UUID,
  full_name TEXT,
  email TEXT,
  total_xp INTEGER,
  current_streak INTEGER,
  level INTEGER,
  rank INTEGER
) AS $$
BEGIN
  RETURN QUERY
  SELECT 
    ux.user_id,
    COALESCE(u.raw_user_meta_data->>'full_name', 'Usuário ' || ROW_NUMBER() OVER (ORDER BY ux.total_xp DESC)) as full_name,
    u.email,
    ux.total_xp,
    ux.current_streak,
    ux.level,
    ROW_NUMBER() OVER (ORDER BY ux.total_xp DESC, ux.current_streak DESC)::INTEGER as rank
  FROM user_xp ux
  INNER JOIN auth.users u ON u.id = ux.user_id
  WHERE ux.total_xp > 0
  ORDER BY ux.total_xp DESC, ux.current_streak DESC
  LIMIT 3;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- =====================================================
-- PERMISSÕES
-- =====================================================
-- Permitir que usuários autenticados executem essas funções
GRANT EXECUTE ON FUNCTION get_weekly_ranking TO authenticated;
GRANT EXECUTE ON FUNCTION get_user_rank TO authenticated;
GRANT EXECUTE ON FUNCTION get_top_3_users TO authenticated;

-- Permitir acesso anônimo também (para visualização pública do ranking)
GRANT EXECUTE ON FUNCTION get_weekly_ranking TO anon;
GRANT EXECUTE ON FUNCTION get_top_3_users TO anon;

COMMENT ON FUNCTION get_weekly_ranking IS 'Retorna o ranking dos melhores usuários por XP';
COMMENT ON FUNCTION get_user_rank IS 'Retorna a posição de um usuário específico no ranking';
COMMENT ON FUNCTION get_top_3_users IS 'Retorna os top 3 usuários para o pódio';
