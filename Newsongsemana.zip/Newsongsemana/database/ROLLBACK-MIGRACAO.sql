-- ============================================
-- ROLLBACK: DESFAZER MIGRAÇÃO
-- Use apenas se algo der errado!
-- ============================================

-- 1. Renomear video_progress de volta para user_progress
ALTER TABLE IF EXISTS video_progress RENAME TO user_progress;

-- 2. Recriar colunas removidas (com dados zerados)
ALTER TABLE user_progress
    ADD COLUMN IF NOT EXISTS study_streak INTEGER DEFAULT 0,
    ADD COLUMN IF NOT EXISTS study_time_minutes INTEGER DEFAULT 0,
    ADD COLUMN IF NOT EXISTS achievements TEXT[] DEFAULT '{}';

-- 3. Renomear coluna de volta
ALTER TABLE user_progress
    RENAME COLUMN last_watched_date TO last_study_date;

-- 4. Remover colunas adicionadas
ALTER TABLE user_progress
    DROP COLUMN IF EXISTS watch_count;

-- 5. Permitir user_id NULL novamente (se necessário)
ALTER TABLE user_progress
    ALTER COLUMN user_id DROP NOT NULL;

-- 6. Remover constraints
ALTER TABLE user_progress
    DROP CONSTRAINT IF EXISTS unique_user_video,
    DROP CONSTRAINT IF EXISTS fk_video_progress_user,
    DROP CONSTRAINT IF EXISTS fk_video_progress_video;

-- 7. Dropar tabela users_stats
DROP TABLE IF EXISTS users_stats CASCADE;

-- 8. Dropar função de trigger
DROP FUNCTION IF EXISTS update_updated_at_column() CASCADE;

-- ✅ Rollback concluído - sistema voltou ao estado anterior
