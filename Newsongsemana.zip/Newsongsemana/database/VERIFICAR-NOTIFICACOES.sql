-- ============================================
-- VERIFICAR SISTEMA DE NOTIFICAÇÕES
-- Execute no SQL Editor do Supabase
-- ============================================

-- 1. Verificar se a tabela de notificações existe
SELECT 
  'Tabela notifications existe' as check_type,
  COUNT(*) as total_notificacoes,
  COUNT(*) FILTER (WHERE is_read = false) as nao_lidas,
  COUNT(DISTINCT user_email) as usuarios_com_notificacoes
FROM notifications;

-- 2. Ver últimas 20 notificações criadas
SELECT 
  id,
  user_email,
  type,
  title,
  message,
  is_read,
  created_at,
  metadata
FROM notifications
ORDER BY created_at DESC
LIMIT 20;

-- 3. Verificar notificações por tipo
SELECT 
  type,
  COUNT(*) as quantidade,
  COUNT(*) FILTER (WHERE is_read = false) as nao_lidas
FROM notifications
GROUP BY type
ORDER BY quantidade DESC;

-- 4. Verificar notificações de um professor específico
-- SUBSTITUA 'email-do-professor' pelo email real
SELECT 
  type,
  title,
  message,
  is_read,
  created_at
FROM notifications
WHERE user_email = 'email-do-professor@exemplo.com'
ORDER BY created_at DESC
LIMIT 10;

-- 5. Verificar se os triggers existem
SELECT 
  trigger_name,
  event_manipulation,
  event_object_table,
  action_statement
FROM information_schema.triggers
WHERE trigger_name LIKE '%notif%'
   OR trigger_name LIKE '%notify%';

-- 6. Verificar funções relacionadas a notificações
SELECT 
  routine_name,
  routine_type
FROM information_schema.routines
WHERE routine_name LIKE '%notif%'
   OR routine_name LIKE '%notify%'
ORDER BY routine_name;

-- 7. Testar criação manual de notificação
-- SUBSTITUA os valores pelos reais
INSERT INTO notifications (
  user_email,
  type,
  title,
  message,
  link,
  metadata
) VALUES (
  'email-do-professor@exemplo.com',
  'video_comment',
  '💬 Teste de Notificação',
  'Esta é uma notificação de teste criada manualmente',
  'videos.html?id=1',
  '{"test": true}'::jsonb
)
RETURNING *;

-- 8. Verificar políticas RLS da tabela notifications
SELECT 
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual,
  with_check
FROM pg_policies
WHERE tablename = 'notifications';
