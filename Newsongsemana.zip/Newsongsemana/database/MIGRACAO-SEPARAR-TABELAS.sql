-- ============================================
-- MIGRAÇÃO: SEPARAR user_progress EM 2 TABELAS
-- Data: 2026-01-31
-- Objetivo: Criar users_stats e video_progress
-- ============================================

-- ============================================
-- PASSO 1: CRIAR TABELA users_stats
-- ============================================

-- Tabela para dados gerais do usuário (XP, level, streak, etc)
CREATE TABLE IF NOT EXISTS users_stats (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL UNIQUE,
    user_email VARCHAR(255) NOT NULL,
    
    -- XP e Progressão
    total_xp INTEGER DEFAULT 0,
    level INTEGER DEFAULT 1,
    
    -- Estudo e Streak
    streak_days INTEGER DEFAULT 0,
    last_study_date TIMESTAMP WITH TIME ZONE,
    total_study_time_minutes INTEGER DEFAULT 0,
    
    -- Conquistas
    achievements TEXT[] DEFAULT '{}',
    
    -- Controle
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Foreign Key
    CONSTRAINT fk_users_stats_user FOREIGN KEY (user_id) 
        REFERENCES users(id) ON DELETE CASCADE
);

-- Comentários
COMMENT ON TABLE users_stats IS 'Estatísticas gerais e progresso global de cada usuário';
COMMENT ON COLUMN users_stats.total_xp IS 'XP total acumulado do usuário';
COMMENT ON COLUMN users_stats.level IS 'Nível atual do usuário';
COMMENT ON COLUMN users_stats.streak_days IS 'Dias consecutivos de estudo';
COMMENT ON COLUMN users_stats.total_study_time_minutes IS 'Tempo total de estudo em minutos';

-- ============================================
-- PASSO 2: MIGRAR DADOS DE user_progress PARA users_stats
-- ============================================

-- Inserir dados agregados (pega o registro mais recente de cada usuário)
INSERT INTO users_stats (
    user_id, 
    user_email, 
    streak_days, 
    last_study_date, 
    total_study_time_minutes, 
    achievements, 
    created_at
)
SELECT DISTINCT ON (up.user_id)
    up.user_id,
    u.email,
    COALESCE(up.study_streak, 0),
    up.last_study_date,
    COALESCE(up.study_time_minutes, 0),
    COALESCE(up.achievements, '{}'),
    up.created_at
FROM user_progress up
INNER JOIN users u ON up.user_id = u.id
WHERE up.user_id IS NOT NULL
ORDER BY up.user_id, up.last_watched_at DESC NULLS LAST
ON CONFLICT (user_id) DO NOTHING;

-- Verificar quantos registros foram criados
SELECT COUNT(*) as total_users_stats FROM users_stats;

-- ============================================
-- PASSO 3: CRIAR ÍNDICES EM users_stats
-- ============================================

CREATE INDEX IF NOT EXISTS idx_users_stats_user_id ON users_stats(user_id);
CREATE INDEX IF NOT EXISTS idx_users_stats_email ON users_stats(user_email);
CREATE INDEX IF NOT EXISTS idx_users_stats_xp ON users_stats(total_xp DESC);
CREATE INDEX IF NOT EXISTS idx_users_stats_level ON users_stats(level DESC);
CREATE INDEX IF NOT EXISTS idx_users_stats_streak ON users_stats(streak_days DESC);
CREATE INDEX IF NOT EXISTS idx_users_stats_last_study ON users_stats(last_study_date DESC NULLS LAST);

-- ============================================
-- PASSO 4: CRIAR FUNÇÃO DE UPDATE para updated_at
-- ============================================

-- Função genérica para atualizar updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger para users_stats
DROP TRIGGER IF EXISTS users_stats_updated_at ON users_stats;
CREATE TRIGGER users_stats_updated_at
    BEFORE UPDATE ON users_stats
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- PASSO 5: CRIAR TABELA video_progress (RENOMEAR user_progress)
-- ============================================

-- Renomear tabela
ALTER TABLE IF EXISTS user_progress RENAME TO video_progress;

-- ============================================
-- PASSO 6: LIMPAR video_progress (REMOVER COLUNAS DUPLICADAS)
-- ============================================

-- Adicionar campos novos ANTES de remover os antigos
ALTER TABLE video_progress
    ADD COLUMN IF NOT EXISTS updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    ADD COLUMN IF NOT EXISTS watch_count INTEGER DEFAULT 1;

-- REMOVER colunas que agora estão em users_stats
ALTER TABLE video_progress
    DROP COLUMN IF EXISTS study_streak,
    DROP COLUMN IF EXISTS study_time_minutes,
    DROP COLUMN IF EXISTS achievements;

-- NÃO remover last_study_date ainda (é útil saber quando assistiu cada vídeo)
-- Renomear para deixar claro que é do vídeo, não geral
ALTER TABLE video_progress
    RENAME COLUMN last_study_date TO last_watched_date;

-- ============================================
-- PASSO 7: CORRIGIR user_id NULL em video_progress
-- ============================================

-- Ver quantos registros têm user_id NULL
SELECT COUNT(*) as registros_sem_user FROM video_progress WHERE user_id IS NULL;

-- DELETAR registros sem user_id (são inválidos)
DELETE FROM video_progress WHERE user_id IS NULL;

-- Tornar user_id obrigatório
ALTER TABLE video_progress 
    ALTER COLUMN user_id SET NOT NULL;

-- ============================================
-- PASSO 8: ADICIONAR CONSTRAINTS E FK em video_progress
-- ============================================

-- Foreign Key para users
ALTER TABLE video_progress
    DROP CONSTRAINT IF EXISTS fk_video_progress_user;

ALTER TABLE video_progress
    ADD CONSTRAINT fk_video_progress_user
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE;

-- NOTA: Não é possível criar FK para videos porque:
-- - video_progress.video_id é UUID
-- - videos.id é INTEGER
-- Tipos incompatíveis! Precisaria migrar videos.id para UUID no futuro.

-- Constraint único: um usuário não pode ter múltiplos progressos do mesmo vídeo
ALTER TABLE video_progress
    DROP CONSTRAINT IF EXISTS unique_user_video;

ALTER TABLE video_progress
    ADD CONSTRAINT unique_user_video
    UNIQUE (user_id, video_id);

-- ============================================
-- PASSO 9: CRIAR ÍNDICES EM video_progress
-- ============================================

CREATE INDEX IF NOT EXISTS idx_video_progress_user_id ON video_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_video_progress_video_id ON video_progress(video_id);
CREATE INDEX IF NOT EXISTS idx_video_progress_completed ON video_progress(completed);
CREATE INDEX IF NOT EXISTS idx_video_progress_last_watched ON video_progress(last_watched_at DESC NULLS LAST);
CREATE INDEX IF NOT EXISTS idx_video_progress_instrument ON video_progress(instrument);
CREATE INDEX IF NOT EXISTS idx_video_progress_module ON video_progress(module);

-- Índice composto para queries comuns
CREATE INDEX IF NOT EXISTS idx_video_progress_user_completed 
    ON video_progress(user_id, completed);

CREATE INDEX IF NOT EXISTS idx_video_progress_user_instrument 
    ON video_progress(user_id, instrument);

-- ============================================
-- PASSO 10: TRIGGER para updated_at em video_progress
-- ============================================

DROP TRIGGER IF EXISTS video_progress_updated_at ON video_progress;
CREATE TRIGGER video_progress_updated_at
    BEFORE UPDATE ON video_progress
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================
-- PASSO 11: COMENTÁRIOS E DOCUMENTAÇÃO
-- ============================================

COMMENT ON TABLE video_progress IS 'Progresso individual de cada vídeo/lição por usuário';
COMMENT ON COLUMN video_progress.progress_percentage IS 'Porcentagem de progresso no vídeo (0-100)';
COMMENT ON COLUMN video_progress.completed IS 'Se o usuário completou este vídeo/lição';
COMMENT ON COLUMN video_progress.watch_count IS 'Quantas vezes o usuário assistiu este vídeo';
COMMENT ON COLUMN video_progress.last_watched_at IS 'Última vez que assistiu este vídeo';
COMMENT ON COLUMN video_progress.last_watched_date IS 'Data da última vez que estudou (qualquer conteúdo)';

-- ============================================
-- PASSO 12: VERIFICAÇÕES FINAIS
-- ============================================

-- Verificar estrutura de users_stats
SELECT 
    column_name,
    data_type,
    is_nullable
FROM information_schema.columns
WHERE table_name = 'users_stats'
ORDER BY ordinal_position;

-- Verificar estrutura de video_progress
SELECT 
    column_name,
    data_type,
    is_nullable
FROM information_schema.columns
WHERE table_name = 'video_progress'
ORDER BY ordinal_position;

-- Contar registros
SELECT 
    (SELECT COUNT(*) FROM users_stats) as total_users_stats,
    (SELECT COUNT(*) FROM video_progress) as total_video_progress,
    (SELECT COUNT(*) FROM users) as total_users;

-- Verificar se todos os usuários têm stats
SELECT 
    u.email,
    u.name,
    CASE 
        WHEN us.id IS NOT NULL THEN '✅ Tem stats'
        ELSE '❌ Sem stats'
    END as status
FROM users u
LEFT JOIN users_stats us ON u.id = us.user_id
ORDER BY status, u.created_at DESC;

-- Verificar video_progress sem user_id NULL
SELECT COUNT(*) as problemas 
FROM video_progress 
WHERE user_id IS NULL;

-- Se retornar 0 = sucesso!

-- ============================================
-- 🎉 MIGRAÇÃO CONCLUÍDA!
-- ============================================

/*
RESUMO DAS MUDANÇAS:

✅ CRIADO: users_stats
   - Armazena XP, level, streak, achievements por usuário
   - 1 registro por usuário
   - 8 índices criados

✅ RENOMEADO: user_progress → video_progress
   - Removidas colunas duplicadas (study_streak, study_time_minutes, achievements)
   - Adicionado: updated_at, watch_count
   - Corrigido: user_id agora é NOT NULL
   - 8 índices criados
   - Foreign Keys para users e videos
   - Constraint UNIQUE (user_id, video_id)

✅ CRIADO: Triggers para updated_at em ambas tabelas

PRÓXIMOS PASSOS:
1. Atualizar código JavaScript para usar users_stats
2. Atualizar queries de notificações
3. Testar sincronização localStorage ↔ Supabase
*/
