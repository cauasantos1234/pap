// ========================================
// DIAGNÓSTICO DE ROLE - Verificar sessão
// ========================================
console.log('====================================');
console.log('🔍 DIAGNÓSTICO DE ROLE DO USUÁRIO');
console.log('====================================\n');

// 1. Verificar sessão atual
const session = JSON.parse(localStorage.getItem('ns-session') || '{}');
console.log('📋 Sessão atual:');
console.log('  Email:', session.email);
console.log('  Nome:', session.name);
console.log('  Role:', session.role);
console.log('  User ID:', session.user_id);
console.log('');

// 2. Verificar usuários no localStorage
const users = JSON.parse(localStorage.getItem('ns-users') || '[]');
console.log('👥 Usuários no localStorage:', users.length);
users.forEach((user, index) => {
  console.log(`  ${index + 1}. ${user.email} - Role: ${user.role || 'NÃO DEFINIDO'}`);
});
console.log('');

// 3. Verificar no Supabase
if (typeof window.supabase !== 'undefined' && window.supabase.auth) {
  console.log('🔄 Verificando role no Supabase...');
  
  window.supabase.auth.getUser().then(({ data, error }) => {
    if (error || !data.user) {
      console.log('❌ Erro ao buscar usuário:', error?.message || 'Usuário não encontrado');
      return;
    }
    
    console.log('✅ Usuário autenticado no Supabase:');
    console.log('  ID:', data.user.id);
    console.log('  Email:', data.user.email);
    console.log('  Metadata:', data.user.user_metadata);
    console.log('');
    
    // Buscar role na tabela users
    window.supabase
      .from('users')
      .select('role, name, email')
      .eq('email', data.user.email.toLowerCase())
      .maybeSingle()
      .then(({ data: userData, error: userError }) => {
        if (userError) {
          console.error('❌ Erro ao buscar na tabela users:', userError.message);
          return;
        }
        
        if (userData) {
          console.log('📊 Dados na tabela users:');
          console.log('  Email:', userData.email);
          console.log('  Nome:', userData.name);
          console.log('  Role:', userData.role);
          console.log('');
          
          // Comparar com sessão local
          if (userData.role !== session.role) {
            console.log('⚠️ INCONSISTÊNCIA DETECTADA!');
            console.log(`  Role no banco: ${userData.role}`);
            console.log(`  Role na sessão: ${session.role}`);
            console.log('');
            console.log('💡 SOLUÇÃO: Execute o comando abaixo para corrigir:');
            console.log('');
            console.log(`localStorage.setItem('ns-session', JSON.stringify({
  email: '${session.email}',
  name: '${userData.name}',
  role: '${userData.role}',
  user_id: '${session.user_id}',
  supabase_id: '${session.supabase_id}'
}));`);
            console.log('');
            console.log('Depois atualize a página (F5)');
          } else {
            console.log('✅ Role consistente entre banco e sessão!');
          }
        } else {
          console.log('❌ Usuário não encontrado na tabela users');
          console.log('💡 Pode ser necessário sincronizar a conta');
        }
      });
  });
} else {
  console.log('⚠️ Supabase não disponível');
}

console.log('');
console.log('====================================');
console.log('FIM DO DIAGNÓSTICO');
console.log('====================================');
