# 🚀 SETUP RÁPIDO - Sincronização Automática de Usuários

## ❗ PROBLEMA
Quando você cria uma conta, ela vai para o `auth.users` do Supabase, mas não aparece automaticamente na tabela `users` que o sistema usa.

## ✅ SOLUÇÃO

### **Passo 1: Executar SQL**
1. Acesse o [Supabase Dashboard](https://supabase.com/dashboard)
2. Selecione seu projeto NewSong
3. Vá em **SQL Editor** (ícone de banco de dados na lateral)
4. Clique em **New Query**
5. Cole TODO o conteúdo do arquivo: `database/SETUP-AUTO-SYNC-USERS.sql`
6. Clique em **Run** (ou pressione Ctrl+Enter)

### **Passo 2: Verificar**
Você deve ver uma mensagem:
```
Query executed successfully
```

E uma tabela mostrando:
```
tabela        | total
--------------+-------
auth.users    | X
public.users  | X
```

Se os números forem iguais = **FUNCIONOU!** ✅

### **Passo 3: Testar**
1. Vá para `criar-conta-rapido.html`
2. Crie uma nova conta de teste
3. Abra `supabase-admin.html`
4. A conta deve aparecer automaticamente! 🎉

## 🔧 O Que Este SQL Faz?

1. **Cria um TRIGGER automático** que:
   - Quando alguém se registra no Supabase Auth
   - Automaticamente copia os dados para a tabela `users`
   - Funciona para INSERT e UPDATE

2. **Configura políticas RLS corretas** para:
   - Permitir INSERT (necessário para registro)
   - Permitir SELECT (necessário para listar usuários)
   - Permitir UPDATE apenas do próprio perfil

3. **Sincroniza usuários existentes**:
   - Pega todas as contas que já existem no Auth
   - Copia para a tabela `users`

4. **Cria funções auxiliares**:
   - `get_all_auth_users()` - Ver todos usuários do Auth
   - `handle_new_user()` - Função do trigger

## 📊 Como Verificar Se Está Funcionando

### No Console do Navegador (F12):
```javascript
// Criar conta de teste
// Você deve ver nos logs:
✅ Registro no Supabase AUTH bem-sucedido!
✅ Usuário inserido na tabela users com sucesso!
```

### No supabase-admin.html:
1. Clique em "🔄 Atualizar Lista"
2. A nova conta deve aparecer imediatamente
3. Clique em "👥 Ver Todos os Usuários"
4. Você verá a lista completa

### No Supabase Dashboard:
1. Vá em **Table Editor** → `users`
2. Você verá todas as contas listadas
3. Vá em **Authentication** → **Users**
4. Deve ter o mesmo número de usuários

## 🆘 Se Não Funcionar

### Erro: "permission denied for table users"
**Solução:** Execute novamente o SQL, especialmente a parte das políticas RLS

### Erro: "relation 'users' does not exist"
**Solução:** 
1. Execute primeiro: `database/01-complete-schema.sql`
2. Depois execute: `database/SETUP-AUTO-SYNC-USERS.sql`

### Contas não aparecem no admin
**Solução:**
1. Abra o Console (F12) ao criar conta
2. Veja se há erros em vermelho
3. Copie o erro e me mostre
4. OU clique em "🔄 Sincronizar Auth→Users" no admin

### Trigger não executa automaticamente
**Solução:** 
Verifique se o trigger foi criado:
```sql
SELECT * FROM information_schema.triggers 
WHERE trigger_name LIKE '%auth_user%';
```

Deve retornar 2 linhas:
- `on_auth_user_created`
- `on_auth_user_updated`

## 🎯 Resumo do Fluxo

```
1. Usuário preenche formulário de registro
   ↓
2. Sistema chama supabase.auth.signUp()
   ↓
3. Supabase cria conta em auth.users
   ↓
4. TRIGGER executa automaticamente
   ↓
5. Função handle_new_user() é chamada
   ↓
6. Dados são copiados para public.users
   ↓
7. Conta aparece em supabase-admin.html
   ↓
8. Usuário pode fazer login normalmente
```

## ✨ Benefícios

- ✅ **Automático** - Não precisa código adicional
- ✅ **Confiável** - Funciona mesmo se JavaScript falhar
- ✅ **Rápido** - Executa no servidor, não depende da rede
- ✅ **Seguro** - Usa SECURITY DEFINER (privilégios do sistema)
- ✅ **Consistente** - Sempre mantém auth.users e public.users sincronizados

## 📝 Arquivo SQL

O arquivo completo está em:
```
database/SETUP-AUTO-SYNC-USERS.sql
```

Tem apenas **~120 linhas**, é rápido de executar (menos de 1 segundo).

---

**Depois de executar este SQL, todas as contas criadas irão aparecer automaticamente no supabase-admin!** 🎉
