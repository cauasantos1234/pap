# 📚 Documentação Ativa - NewSong

Documentos principais mantidos na raiz do projeto.

## 🎯 Guias de Funcionalidades

### Sistema de XP e Ranking
- `GUIA_ATIVACAO_XP.md` - Como ativar o sistema de XP
- `GUIA_SETUP_RANKING.md` - Setup do ranking
- `SISTEMA_XP_RANKING_README.md` - Documentação completa

### Painel Administrativo
- `GUIA_PAINEL_ADMIN.md` - Guia do painel admin
- `SETUP_RAPIDO_ADMIN.md` - Setup rápido

### Sistemas de Usuário
- `SISTEMA_AUTENTICACAO.md` - Sistema de autenticação
- `SISTEMA_PROGRESSO_README.md` - Sistema de progresso
- `SISTEMA_PROGRESSO_INDIVIDUAL.md` - Progresso individual
- `SISTEMA_SALVOS_POR_USUARIO.md` - Vídeos salvos

### Sistema de Notificações
- `SISTEMA_NOTIFICACOES_COMPLETO.md` - Sistema completo
- `SISTEMA_NOTIFICACOES_README.md` - Documentação
- `SETUP_NOTIFICACOES.md` - Como configurar
- `RESUMO_SISTEMA_NOTIFICACOES.md` - Resumo

### Perfil e Vídeos
- `SISTEMA_PERFIL_PROFESSOR.md` - Perfil de professores
- `SISTEMA_PERFIL_VIDEOS_README.md` - Sistema de vídeos
- `SISTEMA_VISUALIZACOES.md` - Sistema de visualizações

### Avaliações e Interações
- `SISTEMA_AVALIACOES_README.md` - Sistema de avaliações
- `SISTEMA_INTERACOES_ALUNO.md` - Interações do aluno
- `TOOLTIPS_EMBLEMAS_README.md` - Emblemas e tooltips

### Metas
- `SISTEMA_METAS_README.md` - Sistema de metas
- `METAS_COMPLETAS.md` - Metas completas

## 🔧 Guias de Setup

### Integração
- `INTEGRACAO_SUPABASE_COMPLETA.md` - Integração Supabase
- `INDEX_INTEGRACAO.md` - Índice de integração
- `RESUMO_EXECUTIVO_INTEGRACAO.md` - Resumo executivo
- `RESUMO_INTEGRACAO.md` - Resumo geral

### Supabase
- `SUPABASE_SETUP.md` - Setup do Supabase
- `QUICK_START_SUPABASE.md` - Início rápido

### Sincronização
- `GUIA_SYNC_AUTOMATICO.md` - Sincronização automática
- `PROGRESSO_SINCRONIZADO_GUIA.md` - Progresso sincronizado
- `VIDEOS_SINCRONIZADOS_GUIA.md` - Vídeos sincronizados

### Outros
- `GUIA_VER_TODOS_USUARIOS.md` - Ver todos os usuários
- `FUNCIONA_EM_QUALQUER_PC.md` - Compatibilidade
- `SISTEMA_SEGURANCA_README.md` - Segurança

## 📖 Como Usar Esta Documentação

1. **Novo no projeto?** Comece pelo `README.md`
2. **Configurar funcionalidade?** Veja os guias de setup específicos
3. **Entender um sistema?** Consulte os arquivos SISTEMA_*_README.md
4. **Problema específico?** Veja LIMPEZA_SITE.md para histórico

## 🗂️ Organização

### Raiz do Projeto
Documentos de alto nível e guias principais

### `/database`
Scripts SQL de produção e setup

### `/_ARQUIVOS_ANTIGOS`
Diagnósticos e correções antigas (referência)

---

**Última atualização**: 28/01/2026
**Mantido em**: Raiz do projeto
