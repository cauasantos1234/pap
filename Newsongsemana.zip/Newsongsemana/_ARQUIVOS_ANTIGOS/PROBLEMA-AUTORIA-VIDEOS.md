# 🔍 PROBLEMA: Vídeos aparecem com autoria incorreta

## 📋 Descrição do Problema

Você postou um vídeo em uma conta de professor, mas quando visualiza os vídeos, aparece como se outra pessoa tivesse postado.

## 🎯 Causas Possíveis

### 1. **Múltiplas colunas de autoria na tabela `videos`**
A tabela pode ter várias colunas que armazenam informações do autor:
- `author_id` - Referência ao usuário (UUID)
- `uploaded_by` - ID de quem fez upload (UUID)
- `uploaded_by_email` - Email de quem fez upload
- `teacher_email` - Email do professor
- `uploaded_by_name` - Nome de quem fez upload

**Problema**: Se essas colunas tiverem valores diferentes ou inconsistentes, a interface pode mostrar o autor errado.

### 2. **Vídeos órfãos (sem autor definido)**
Alguns vídeos podem ter essas colunas vazias (`NULL` ou string vazia), fazendo com que apareçam sem autor ou com autor padrão.

### 3. **Dados desatualizados**
O vídeo pode ter sido postado com informações de uma conta, mas depois os dados foram alterados manualmente no banco ou através de outro processo.

### 4. **Políticas RLS (Row Level Security)**
As políticas de segurança podem estar filtrando ou modificando os dados exibidos baseado no usuário logado.

### 5. **Cache no frontend**
O frontend pode estar mostrando dados em cache que não foram atualizados.

## 🔧 Como Diagnosticar

### Execute o script de diagnóstico:

1. Abra o **Supabase SQL Editor**
2. Execute o arquivo: `database/DIAGNOSTICO-VIDEOS-PROFESSORES.sql`
3. Analise os resultados de cada seção:

```sql
-- Seção 1: Estrutura da tabela
-- Mostra quais colunas existem na tabela videos

-- Seção 2: Vídeos com associações
-- Mostra todos os vídeos e suas colunas de autoria

-- Seção 3: Lista de professores
-- Mostra todos os professores cadastrados

-- Seção 4: Contagem por professor
-- Quantos vídeos cada professor tem

-- Seção 5: Vídeos órfãos
-- Vídeos sem professor associado

-- Seção 6: Divergências de autoria
-- Compara dados do vídeo com dados do usuário

-- Seção 7: Autenticação Supabase
-- Verifica auth.users vs users

-- Seção 8: Políticas RLS
-- Lista políticas que podem afetar visualização
```

## 🎯 Soluções

### **Solução 1: Corrigir vídeos órfãos**

Se o diagnóstico mostrou vídeos sem `uploaded_by`, associe-os ao professor correto:

```sql
-- Substitua 'professor@email.com' pelo email correto do professor
UPDATE videos
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'professor@email.com' LIMIT 1),
  uploaded_by_email = 'professor@email.com',
  teacher_email = 'professor@email.com',
  uploaded_by_name = (SELECT name FROM users WHERE email = 'professor@email.com' LIMIT 1)
WHERE uploaded_by IS NULL OR uploaded_by::TEXT = '';
```

### **Solução 2: Corrigir vídeos específicos com autoria errada**

Se vídeos específicos estão associados ao professor errado:

```sql
-- Encontre os IDs dos vídeos com problema primeiro:
SELECT id, title, uploaded_by_email, uploaded_by_name
FROM videos
WHERE uploaded_by_email != 'email_que_voce_esperava@newsong.com';

-- Depois corrija:
UPDATE videos
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'email_correto@newsong.com'),
  uploaded_by_email = 'email_correto@newsong.com',
  teacher_email = 'email_correto@newsong.com',
  uploaded_by_name = (SELECT name FROM users WHERE email = 'email_correto@newsong.com')
WHERE id IN (1, 2, 3); -- Coloque os IDs dos vídeos
```

### **Solução 3: Padronizar estrutura (se necessário)**

Se a tabela não tem `author_id` mas deveria ter:

```sql
-- Adicionar coluna author_id
ALTER TABLE videos ADD COLUMN IF NOT EXISTS author_id UUID REFERENCES users(id);
CREATE INDEX IF NOT EXISTS idx_videos_author_id ON videos(author_id);

-- Sincronizar author_id com uploaded_by
UPDATE videos 
SET author_id = uploaded_by 
WHERE uploaded_by IS NOT NULL AND author_id IS NULL;
```

### **Solução 4: Verificar código do frontend**

No arquivo JavaScript/React onde você faz upload de vídeos, verifique se está passando corretamente:

```javascript
// ✅ CORRETO - Pegar informações do usuário autenticado
const { data: { user } } = await supabase.auth.getUser();

const videoData = {
  title: 'Meu Vídeo',
  // ... outros campos
  uploaded_by: user.id,           // UUID do auth.users
  uploaded_by_email: user.email,  // Email do usuário
  teacher_email: user.email,      // Mesmo email
  uploaded_by_name: userName,     // Nome do perfil
};

// ❌ ERRADO - Usar dados hardcoded ou de outra conta
const videoData = {
  uploaded_by: 'outro-id-qualquer',  // ERRADO!
  // ...
};
```

### **Solução 5: Limpar cache do frontend**

```javascript
// No seu código React/JavaScript
// Após fazer correções no banco, force atualização:
await supabase.from('videos').select('*');  // Refetch
// OU
window.location.reload();  // Recarregar página
```

## 📝 Checklist de Verificação

- [ ] Execute o diagnóstico completo
- [ ] Identifique quantos vídeos têm problema
- [ ] Verifique qual conta deveria ser a autora
- [ ] Confirme que essa conta existe na tabela `users`
- [ ] Execute UPDATE para corrigir os vídeos
- [ ] Verifique o código de upload no frontend
- [ ] Teste fazer novo upload
- [ ] Confirme que novo vídeo aparece com autor correto
- [ ] Limpe cache/recarregue a página

## 🚨 Atenção

**SEMPRE faça backup antes de executar UPDATE em produção!**

```sql
-- Criar tabela de backup
CREATE TABLE videos_backup AS SELECT * FROM videos;

-- Depois execute os UPDATEs
-- Se der erro, pode restaurar:
-- DELETE FROM videos;
-- INSERT INTO videos SELECT * FROM videos_backup;
```

## 📞 Próximos Passos

1. **Execute o diagnóstico**: `DIAGNOSTICO-VIDEOS-PROFESSORES.sql`
2. **Analise os resultados**: Veja quais vídeos têm problema
3. **Escolha a solução adequada**: Baseado no diagnóstico
4. **Teste**: Faça upload de um novo vídeo para confirmar
5. **Corrija em lote**: Se houver muitos vídeos com problema

## 💡 Dica

Se você quer evitar esse problema no futuro, adicione validação no código de upload:

```javascript
// Antes de inserir no banco:
if (!user || !user.id || !user.email) {
  throw new Error('Usuário não autenticado corretamente');
}

console.log('Fazendo upload como:', user.email);
```
