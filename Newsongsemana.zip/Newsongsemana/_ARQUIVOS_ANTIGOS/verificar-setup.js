// ========================================
// VERIFICAR SE O TRIGGER FOI CRIADO
// Cole isto no Console (F12) do supabase-admin.html
// ========================================

async function verificarSetup() {
    console.log('🔍 VERIFICANDO SETUP AUTOMÁTICO...\n');
    
    if (!window.supabase) {
        console.error('❌ Supabase não está carregado!');
        return;
    }
    
    try {
        // 1. Verificar se a função handle_new_user existe
        console.log('1️⃣ Verificando função handle_new_user()...');
        const { data: funcData, error: funcError } = await window.supabase.rpc('handle_new_user');
        
        if (funcError) {
            if (funcError.message.includes('function') || funcError.message.includes('does not exist')) {
                console.log('❌ Função handle_new_user NÃO existe');
                console.log('   → Você NÃO executou o SETUP-AUTO-SYNC-USERS.sql\n');
            } else {
                console.log('⚠️ Erro ao verificar função:', funcError.message, '\n');
            }
        } else {
            console.log('✅ Função handle_new_user existe!\n');
        }
        
        // 2. Verificar se a função get_all_auth_users existe
        console.log('2️⃣ Verificando função get_all_auth_users()...');
        const { data: authFunc, error: authError } = await window.supabase.rpc('get_all_auth_users');
        
        if (authError) {
            if (authError.message.includes('function') || authError.message.includes('does not exist')) {
                console.log('❌ Função get_all_auth_users NÃO existe');
                console.log('   → Você NÃO executou o SETUP-AUTO-SYNC-USERS.sql\n');
            }
        } else {
            console.log('✅ Função get_all_auth_users existe!');
            console.log(`   → ${authFunc.length} usuário(s) encontrado(s) no Auth\n`);
        }
        
        // 3. Comparar quantidade de usuários
        console.log('3️⃣ Comparando tabelas auth.users vs public.users...');
        const { count: usersCount } = await window.supabase
            .from('users')
            .select('*', { count: 'exact', head: true });
        
        console.log(`   public.users: ${usersCount || 0} usuário(s)`);
        
        if (authFunc && !authError) {
            console.log(`   auth.users: ${authFunc.length} usuário(s)`);
            
            if (usersCount === authFunc.length) {
                console.log('   ✅ SINCRONIZADOS! Mesmo número em ambas\n');
            } else {
                console.log('   ⚠️ DESSINCRONIZADOS! Números diferentes\n');
            }
        }
        
        // 4. CONCLUSÃO
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        console.log('📊 RESULTADO:');
        
        if (!funcError && !authError && usersCount === authFunc.length) {
            console.log('');
            console.log('🎉 TUDO CONFIGURADO CORRETAMENTE!');
            console.log('');
            console.log('✅ O trigger automático está ATIVO');
            console.log('✅ Novas contas serão sincronizadas automaticamente');
            console.log('✅ O sistema está pronto para o PAP!');
        } else {
            console.log('');
            console.log('⚠️ SETUP AUTOMÁTICO NÃO FOI EXECUTADO');
            console.log('');
            console.log('📝 Para ativar:');
            console.log('1. Abra: https://supabase.com/dashboard');
            console.log('2. Vá em SQL Editor → New Query');
            console.log('3. Cole todo o conteúdo de: database/SETUP-AUTO-SYNC-USERS.sql');
            console.log('4. Clique em RUN');
            console.log('');
            console.log('Ou abra: public/setup-automatico.html para instruções');
        }
        console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
        
    } catch (error) {
        console.error('❌ Erro durante verificação:', error);
    }
}

// Executar
verificarSetup();
