// ============================================
// EXEMPLOS DE USO - SISTEMA DE NOTIFICAÇÕES
// Cole no Console do navegador (F12) para testar
// ============================================

// ============================================
// 1. VERIFICAR SE ESTÁ FUNCIONANDO
// ============================================

// Verificar se módulos carregaram
console.log('✅ Verificando módulos...');
console.log('NotificationsAPI:', !!window.NotificationsAPI);
console.log('NotificationBell:', !!window.NotificationBell);
console.log('Supabase:', !!window.SupabaseAPI);

// Ver sessão atual
const session = JSON.parse(localStorage.getItem('ns-session'));
console.log('Usuário logado:', session?.email);
console.log('Role:', session?.role);

// ============================================
// 2. CRIAR NOTIFICAÇÕES
// ============================================

// Criar notificação simples
await window.NotificationsAPI.createNotification({
  userEmail: 'seu-email@newsong.com', // TROCAR
  type: 'new_video',
  title: '🎥 Teste de Notificação',
  message: 'Sistema funcionando perfeitamente!',
  link: 'app.html'
});

// Criar notificação de avaliação
await window.NotificationsAPI.createNotification({
  userEmail: 'professor@newsong.com', // TROCAR
  type: 'rating_received',
  title: '⭐ Nova Avaliação',
  message: 'João avaliou sua aula com 5 estrelas',
  link: 'feedbacks.html',
  metadata: {
    rating: 5,
    student: 'João',
    lesson_id: 1
  }
});

// Criar notificação de feedback
await window.NotificationsAPI.createNotification({
  userEmail: 'aluno@newsong.com', // TROCAR
  type: 'feedback_received',
  title: '💬 Resposta do Professor',
  message: 'Professor Igor respondeu sua avaliação',
  link: 'profile.html',
  metadata: {
    teacher: 'Igor',
    rating_id: 1
  }
});

// Criar notificação de conquista
await window.NotificationsAPI.createNotification({
  userEmail: 'aluno@newsong.com', // TROCAR
  type: 'achievement',
  title: '🏆 Nova Conquista',
  message: 'Você completou 10 aulas!',
  link: 'profile.html',
  metadata: {
    achievement: 'lessons_10',
    xp_earned: 100
  }
});

// ============================================
// 3. CONSULTAR NOTIFICAÇÕES
// ============================================

// Ver todas notificações (últimas 10)
const allNotifications = await window.NotificationsAPI.getAllNotifications(
  session.email, 
  10
);
console.log('Todas notificações:', allNotifications);

// Ver apenas não lidas
const unreadNotifications = await window.NotificationsAPI.getUnreadNotifications(
  session.email
);
console.log('Não lidas:', unreadNotifications);

// Contar não lidas
const count = await window.NotificationsAPI.countUnread(session.email);
console.log('Total não lidas:', count.count);

// ============================================
// 4. MARCAR COMO LIDA
// ============================================

// Marcar uma específica
await window.NotificationsAPI.markAsRead(1); // ID da notificação

// Marcar todas como lidas
await window.NotificationsAPI.markAllAsRead(session.email);

// ============================================
// 5. ATUALIZAR BADGE
// ============================================

// Atualizar manualmente
await window.NotificationBell.updateBadge();

// Recarregar lista
await window.NotificationBell.loadNotifications();

// ============================================
// 6. TESTAR NOTIFICAÇÕES EM TEMPO REAL
// ============================================

// Inscrever para receber notificações
const subscription = window.NotificationsAPI.subscribeToNotifications(
  session.email,
  (newNotification) => {
    console.log('🔔 NOVA NOTIFICAÇÃO RECEBIDA:', newNotification);
    alert(`Nova notificação: ${newNotification.title}`);
  }
);

// Para desinscrever depois:
// window.NotificationsAPI.unsubscribeFromNotifications(subscription);

// ============================================
// 7. CRIAR MÚLTIPLAS NOTIFICAÇÕES (TESTE)
// ============================================

// Criar 5 notificações de teste
for (let i = 1; i <= 5; i++) {
  await window.NotificationsAPI.createNotification({
    userEmail: session.email,
    type: 'new_video',
    title: `🎥 Vídeo ${i}`,
    message: `Esta é a notificação de teste número ${i}`,
    link: 'videos.html'
  });
  
  // Aguardar 500ms entre cada
  await new Promise(resolve => setTimeout(resolve, 500));
}

console.log('✅ 5 notificações criadas!');

// ============================================
// 8. DELETAR NOTIFICAÇÃO
// ============================================

// Deletar uma notificação específica
await window.NotificationsAPI.deleteNotification(1); // ID

// ============================================
// 9. FORMATAÇÃO DE TEMPO
// ============================================

// Testar formato de tempo
const now = new Date();
const oneHourAgo = new Date(now - 60 * 60 * 1000);
const oneDayAgo = new Date(now - 24 * 60 * 60 * 1000);
const oneWeekAgo = new Date(now - 7 * 24 * 60 * 60 * 1000);

console.log('Agora:', window.NotificationsAPI.formatTimeAgo(now));
console.log('1h atrás:', window.NotificationsAPI.formatTimeAgo(oneHourAgo));
console.log('1 dia atrás:', window.NotificationsAPI.formatTimeAgo(oneDayAgo));
console.log('1 semana atrás:', window.NotificationsAPI.formatTimeAgo(oneWeekAgo));

// ============================================
// 10. ESTILOS DE NOTIFICAÇÃO
// ============================================

// Ver ícone e cor de cada tipo
const types = ['new_video', 'rating_received', 'feedback_received', 'achievement', 'comment'];

types.forEach(type => {
  const style = window.NotificationsAPI.getNotificationStyle(type);
  console.log(`${type}:`, style.icon, style.color);
});

// ============================================
// 11. CRIAR NOTIFICAÇÕES PARA TODOS OS ALUNOS
// ============================================

// (Execute apenas se tiver certeza - cria para todos!)
async function notifyAllStudents() {
  const supabase = window.SupabaseAPI.getClient();
  
  const { data: students } = await supabase
    .from('users')
    .select('email')
    .eq('role', 'student');
  
  for (const student of students) {
    await window.NotificationsAPI.createNotification({
      userEmail: student.email,
      type: 'new_video',
      title: '🎥 Novo Vídeo Disponível',
      message: 'Confira a nova aula que acabamos de publicar!',
      link: 'videos.html'
    });
  }
  
  console.log(`✅ Notificação enviada para ${students.length} alunos`);
}

// Descomente para executar:
// await notifyAllStudents();

// ============================================
// 12. VERIFICAR TABELA NO BANCO
// ============================================

// Ver últimas notificações diretamente do banco
const supabase = window.SupabaseAPI.getClient();

const { data, error } = await supabase
  .from('notifications')
  .select('*')
  .order('created_at', { ascending: false })
  .limit(10);

console.log('Últimas 10 notificações do banco:', data);

// ============================================
// 13. ESTATÍSTICAS
// ============================================

// Ver estatísticas de notificações
async function getNotificationStats() {
  const supabase = window.SupabaseAPI.getClient();
  
  // Total
  const { count: total } = await supabase
    .from('notifications')
    .select('*', { count: 'exact', head: true });
  
  // Não lidas
  const { count: unread } = await supabase
    .from('notifications')
    .select('*', { count: 'exact', head: true })
    .eq('is_read', false);
  
  // Por tipo
  const { data: byType } = await supabase
    .from('notifications')
    .select('type')
    .then(result => {
      const counts = {};
      result.data.forEach(n => {
        counts[n.type] = (counts[n.type] || 0) + 1;
      });
      return { data: counts };
    });
  
  console.log('📊 Estatísticas:');
  console.log('Total:', total);
  console.log('Não lidas:', unread);
  console.log('Por tipo:', byType);
}

await getNotificationStats();

// ============================================
// 14. TESTE DE PERFORMANCE
// ============================================

// Medir tempo de carregamento
console.time('Carregar notificações');
const notifications = await window.NotificationsAPI.getAllNotifications(session.email, 50);
console.timeEnd('Carregar notificações');
console.log('Notificações carregadas:', notifications.data?.length);

// ============================================
// 15. LIMPAR TODAS NOTIFICAÇÕES (CUIDADO!)
// ============================================

// Apagar todas notificações do usuário atual
async function clearAllMyNotifications() {
  const supabase = window.SupabaseAPI.getClient();
  
  const { error } = await supabase
    .from('notifications')
    .delete()
    .eq('user_email', session.email);
  
  if (error) {
    console.error('Erro:', error);
  } else {
    console.log('✅ Todas notificações apagadas');
    await window.NotificationBell.updateBadge();
  }
}

// Descomente para executar:
// await clearAllMyNotifications();

// ============================================
// 16. SIMULAR AVALIAÇÃO DE ALUNO
// ============================================

// Simular um aluno avaliando um professor
async function simulateRating() {
  const supabase = window.SupabaseAPI.getClient();
  
  // Inserir avaliação (isso vai disparar o trigger de notificação)
  const { error } = await supabase
    .from('teacher_ratings')
    .insert([{
      user_email: 'aluno.teste@newsong.com',
      teacher_name: 'Professor Igor',
      lesson_id: 1,
      rating: 5,
      comment: 'Excelente aula!'
    }]);
  
  if (error) {
    console.error('Erro:', error);
  } else {
    console.log('✅ Avaliação criada - Notificação automática enviada ao professor!');
  }
}

// Descomente para executar:
// await simulateRating();

// ============================================
// 17. TESTAR NOTIFICAÇÕES NATIVAS DO NAVEGADOR
// ============================================

// Solicitar permissão
if ('Notification' in window) {
  console.log('Permissão atual:', Notification.permission);
  
  if (Notification.permission === 'default') {
    await Notification.requestPermission();
  }
  
  // Criar notificação de teste
  if (Notification.permission === 'granted') {
    new Notification('🔔 Teste NewSong', {
      body: 'Notificações nativas funcionando!',
      icon: '/icon-192x192.png'
    });
  }
}

// ============================================
// 18. HELPER FUNCTIONS
// ============================================

// Função útil: Criar e mostrar notificação
async function quickNotify(title, message, type = 'new_video') {
  await window.NotificationsAPI.createNotification({
    userEmail: session.email,
    type: type,
    title: title,
    message: message,
    link: 'app.html'
  });
  
  await window.NotificationBell.updateBadge();
  console.log('✅ Notificação criada:', title);
}

// Usar assim:
// await quickNotify('🎉 Teste', 'Isso é um teste rápido');

// Função útil: Ver minhas últimas N notificações
async function myNotifications(limit = 5) {
  const result = await window.NotificationsAPI.getAllNotifications(session.email, limit);
  
  if (result.success) {
    console.table(result.data.map(n => ({
      id: n.id,
      tipo: n.type,
      título: n.title,
      lida: n.is_read ? '✓' : '✗',
      quando: window.NotificationsAPI.formatTimeAgo(n.created_at)
    })));
  }
}

// Usar assim:
// await myNotifications(10);

// ============================================
// ✅ PRONTO PARA USAR!
// ============================================

console.log(`
╔══════════════════════════════════════╗
║  SISTEMA DE NOTIFICAÇÕES PRONTO! 🔔  ║
╚══════════════════════════════════════╝

Exemplos úteis:

1. Criar notificação:
   await quickNotify('🎉 Teste', 'Mensagem')

2. Ver minhas notificações:
   await myNotifications()

3. Marcar todas como lidas:
   await window.NotificationsAPI.markAllAsRead('${session?.email}')

4. Atualizar badge:
   await window.NotificationBell.updateBadge()

Divirta-se! 🚀
`);
