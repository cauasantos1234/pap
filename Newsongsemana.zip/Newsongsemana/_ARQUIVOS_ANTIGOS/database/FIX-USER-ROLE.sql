-- ========================================
-- CORRIGIR ROLE DE USUÁRIOS
-- Execute este SQL no Supabase SQL Editor
-- ========================================

-- 1. Ver todos os usuários e seus roles atuais
SELECT 
  id,
  email,
  name,
  role,
  created_at
FROM public.users
ORDER BY created_at DESC;

-- 2. CORRIGIR: Atualizar role de um usuário específico
-- Substitua 'SEU_EMAIL_AQUI' pelo email da conta que está errada

UPDATE public.users
SET role = 'teacher'
WHERE email = 'professor@newsong.com';

-- OU se for outro email:
-- UPDATE public.users
-- SET role = 'teacher'
-- WHERE email = 'seu_email@gmail.com';

-- 3. Verificar se funcionou
SELECT 
  email,
  name,
  role,
  'Atualizado!' as status
FROM public.users
WHERE role = 'teacher';

-- 4. (OPCIONAL) Corrigir TODOS os usuários que deveriam ser professores
-- Descomente as linhas abaixo se necessário

-- UPDATE public.users
-- SET role = 'teacher'
-- WHERE email IN (
--   'professor@newsong.com',
--   'professor@gmail.com',
--   'outro_professor@gmail.com'
-- );

-- 5. Atualizar também no auth.users metadata
-- Isso garante consistência total

UPDATE auth.users
SET raw_user_meta_data = jsonb_set(
  COALESCE(raw_user_meta_data, '{}'::jsonb),
  '{role}',
  '"teacher"'
)
WHERE email = 'professor@newsong.com';

-- 6. Verificação final
SELECT 
  'public.users' as tabela,
  email,
  role
FROM public.users
WHERE email = 'professor@newsong.com'
UNION ALL
SELECT 
  'auth.users' as tabela,
  email,
  raw_user_meta_data->>'role' as role
FROM auth.users
WHERE email = 'professor@newsong.com';

-- Deve mostrar 'teacher' em ambas as linhas!