-- =====================================================
-- VERIFICAÇÃO RÁPIDA: Dados atuais do ranking
-- =====================================================

-- Ver ranking completo com detalhes
SELECT 
  ROW_NUMBER() OVER (ORDER BY ux.total_xp DESC) as posicao_atual,
  u.email,
  ux.total_xp as xp_atual,
  ux.level as nivel,
  ux.current_streak as streak,
  ux.created_at as quando_criou_xp,
  u.created_at as quando_criou_conta,
  -- Ver se foi do script de popular ou real
  CASE 
    WHEN EXISTS (SELECT 1 FROM xp_transactions WHERE user_id = u.id AND action_type = 'initial_setup') 
    THEN '📝 Do script popular'
    ELSE '✅ XP real ganho'
  END as origem_xp
FROM user_xp ux
JOIN auth.users u ON ux.user_id = u.id
ORDER BY ux.total_xp DESC;

-- Verificar se o script de popular foi executado corretamente
SELECT 
  '⚠️ VERIFICAÇÃO:' as info,
  CASE 
    WHEN MAX(total_xp) < 1000 THEN '❌ Script de popular NÃO foi executado (XP máximo muito baixo)'
    WHEN MAX(total_xp) >= 2000 THEN '✅ Script de popular FOI executado corretamente'
    ELSE '⚠️ Dados parciais - script pode ter falhado'
  END as status_popular,
  MAX(total_xp) as xp_maximo_encontrado,
  COUNT(*) as total_usuarios
FROM user_xp;

-- Ver últimas transações para entender origem do XP
SELECT 
  u.email,
  t.action_type,
  t.xp_amount,
  t.description,
  t.created_at
FROM xp_transactions t
JOIN auth.users u ON t.user_id = u.id
ORDER BY t.created_at DESC
LIMIT 20;
