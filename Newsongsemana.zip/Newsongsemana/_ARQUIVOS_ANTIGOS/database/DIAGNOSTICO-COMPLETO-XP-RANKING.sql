-- =====================================================
-- DIAGNÓSTICO COMPLETO: XP E RANKING
-- Execute este script para verificar se tudo está funcionando
-- =====================================================

-- =====================================================
-- 1. VERIFICAR TABELAS EXISTEM
-- =====================================================
SELECT '🔍 VERIFICANDO ESTRUTURA DO BANCO...' as etapa;

SELECT 
  table_name as tabela,
  CASE 
    WHEN table_name IN ('user_xp', 'xp_transactions') THEN '✅ Existe'
    ELSE '❌ Não existe'
  END as status
FROM information_schema.tables 
WHERE table_schema = 'public' 
  AND table_name IN ('user_xp', 'xp_transactions')
ORDER BY table_name;

-- =====================================================
-- 2. VERIFICAR VIEWS DE RANKING
-- =====================================================
SELECT '🔍 VERIFICANDO VIEWS...' as etapa;

SELECT 
  viewname as view_name,
  CASE 
    WHEN viewname IN ('ranking_by_xp', 'ranking_by_streak') THEN '✅ Existe'
    ELSE '❌ Não existe'
  END as status
FROM pg_views 
WHERE schemaname = 'public' 
  AND viewname IN ('ranking_by_xp', 'ranking_by_streak')
ORDER BY viewname;

-- =====================================================
-- 3. VERIFICAR FUNÇÕES SQL
-- =====================================================
SELECT '🔍 VERIFICANDO FUNÇÕES...' as etapa;

SELECT 
  routine_name as funcao,
  '✅ Existe' as status
FROM information_schema.routines
WHERE routine_schema = 'public' 
  AND routine_name IN ('calculate_level', 'add_xp_to_user', 'get_user_ranking', 'update_user_streak')
ORDER BY routine_name;

-- =====================================================
-- 4. VERIFICAR DADOS NA TABELA user_xp
-- =====================================================
SELECT '📊 DADOS NA TABELA user_xp:' as etapa;

SELECT 
  COUNT(*) as total_usuarios,
  COALESCE(MAX(total_xp), 0) as xp_maximo,
  COALESCE(MIN(total_xp), 0) as xp_minimo,
  COALESCE(ROUND(AVG(total_xp)), 0) as xp_medio,
  COALESCE(MAX(level), 0) as nivel_maximo,
  COALESCE(MAX(current_streak), 0) as streak_maximo
FROM user_xp;

-- =====================================================
-- 5. VERIFICAR DADOS NA TABELA xp_transactions
-- =====================================================
SELECT '📝 TRANSAÇÕES DE XP:' as etapa;

SELECT 
  COUNT(*) as total_transacoes,
  COUNT(DISTINCT user_id) as usuarios_com_transacoes,
  COALESCE(SUM(xp_amount), 0) as xp_total_distribuido,
  MAX(created_at) as ultima_transacao
FROM xp_transactions;

-- =====================================================
-- 6. TESTAR VIEW ranking_by_xp (DADOS REAIS)
-- =====================================================
SELECT '🏆 RANKING POR XP (Top 10):' as etapa;

SELECT 
  rank as posicao,
  user_name as usuario,
  user_email as email,
  total_xp as xp,
  level as nivel,
  current_streak as streak,
  longest_streak as melhor_streak
FROM ranking_by_xp
LIMIT 10;

-- =====================================================
-- 7. TESTAR VIEW ranking_by_streak
-- =====================================================
SELECT '🔥 RANKING POR STREAK (Top 5):' as etapa;

SELECT 
  rank as posicao,
  user_name as usuario,
  user_email as email,
  current_streak as dias_consecutivos,
  total_xp as xp,
  level as nivel
FROM ranking_by_streak
LIMIT 5;

-- =====================================================
-- 8. VERIFICAR USUÁRIOS SEM XP
-- =====================================================
SELECT '⚠️ USUÁRIOS SEM XP:' as etapa;

SELECT 
  COUNT(*) as usuarios_sem_xp,
  STRING_AGG(u.email, ', ') as emails
FROM auth.users u
LEFT JOIN user_xp ux ON u.id = ux.user_id
WHERE ux.user_id IS NULL;

-- =====================================================
-- 9. VERIFICAR INTEGRIDADE DOS DADOS
-- =====================================================
SELECT '🔍 VERIFICAÇÃO DE INTEGRIDADE:' as etapa;

SELECT 
  -- Verificar se todos têm nível válido
  CASE 
    WHEN COUNT(*) = COUNT(CASE WHEN level > 0 THEN 1 END) 
    THEN '✅ Todos os níveis são válidos'
    ELSE '❌ Há níveis inválidos'
  END as check_niveis,
  
  -- Verificar se XP é consistente com nível
  CASE 
    WHEN COUNT(*) = COUNT(CASE WHEN calculate_level(total_xp) = level THEN 1 END)
    THEN '✅ XP consistente com nível'
    ELSE '⚠️ Há inconsistências entre XP e nível'
  END as check_consistencia,
  
  -- Verificar se longest_streak >= current_streak
  CASE 
    WHEN COUNT(*) = COUNT(CASE WHEN longest_streak >= current_streak THEN 1 END)
    THEN '✅ Streaks válidos'
    ELSE '❌ Longest streak menor que current streak'
  END as check_streaks,
  
  -- Verificar duplicatas
  CASE 
    WHEN COUNT(*) = COUNT(DISTINCT user_id)
    THEN '✅ Sem duplicatas'
    ELSE '❌ Há usuários duplicados'
  END as check_duplicatas
FROM user_xp;

-- =====================================================
-- 10. TESTAR FUNÇÃO get_user_ranking
-- =====================================================
SELECT '🎯 TESTANDO FUNÇÃO get_user_ranking:' as etapa;

-- Pegar primeiro usuário com XP e testar
DO $$
DECLARE
  v_test_user_id UUID;
  v_ranking_result JSON;
BEGIN
  -- Pegar primeiro usuário com XP
  SELECT user_id INTO v_test_user_id FROM user_xp LIMIT 1;
  
  IF v_test_user_id IS NOT NULL THEN
    -- Testar função
    SELECT get_user_ranking(v_test_user_id) INTO v_ranking_result;
    
    RAISE NOTICE '✅ Função get_user_ranking funciona';
    RAISE NOTICE 'Resultado: %', v_ranking_result;
  ELSE
    RAISE NOTICE '⚠️ Nenhum usuário com XP para testar';
  END IF;
END $$;

-- =====================================================
-- 11. VERIFICAR POLÍTICAS RLS (Row Level Security)
-- =====================================================
SELECT '🔒 POLÍTICAS RLS (Row Level Security):' as etapa;

SELECT 
  schemaname as schema,
  tablename as tabela,
  policyname as politica,
  permissive as permissivo,
  roles as roles,
  cmd as comando,
  qual as condicao
FROM pg_policies
WHERE tablename IN ('user_xp', 'xp_transactions')
ORDER BY tablename, policyname;

-- =====================================================
-- 12. VERIFICAR PERMISSÕES NAS VIEWS
-- =====================================================
SELECT '🔐 PERMISSÕES NAS VIEWS:' as etapa;

SELECT 
  table_name as view_name,
  grantee as usuario,
  privilege_type as permissao
FROM information_schema.role_table_grants
WHERE table_schema = 'public' 
  AND table_name IN ('ranking_by_xp', 'ranking_by_streak')
  AND grantee IN ('anon', 'authenticated', 'service_role')
ORDER BY table_name, grantee;

-- =====================================================
-- 13. DETALHES COMPLETOS DE CADA USUÁRIO
-- =====================================================
SELECT '👥 DETALHES COMPLETOS DE TODOS OS USUÁRIOS:' as etapa;

SELECT 
  ROW_NUMBER() OVER (ORDER BY ux.total_xp DESC) as posicao_ranking,
  u.email,
  u.created_at as conta_criada_em,
  ux.total_xp as xp_total,
  ux.level as nivel,
  ux.current_streak as streak_atual,
  ux.longest_streak as melhor_streak,
  ux.last_activity_date as ultima_atividade,
  ux.created_at as xp_criado_em,
  ux.updated_at as xp_atualizado_em,
  -- Contar transações
  (SELECT COUNT(*) FROM xp_transactions WHERE user_id = u.id) as total_transacoes,
  -- Soma de XP das transações
  (SELECT COALESCE(SUM(xp_amount), 0) FROM xp_transactions WHERE user_id = u.id) as xp_por_transacoes
FROM auth.users u
LEFT JOIN user_xp ux ON u.id = ux.user_id
ORDER BY ux.total_xp DESC NULLS LAST;

-- =====================================================
-- 14. ÚLTIMAS 10 TRANSAÇÕES DE XP
-- =====================================================
SELECT '📜 ÚLTIMAS 10 TRANSAÇÕES DE XP:' as etapa;

SELECT 
  u.email as usuario,
  t.xp_amount as xp_ganho,
  t.action_type as tipo_acao,
  t.description as descricao,
  t.created_at as data_hora
FROM xp_transactions t
JOIN auth.users u ON t.user_id = u.id
ORDER BY t.created_at DESC
LIMIT 10;

-- =====================================================
-- 15. RESUMO FINAL
-- =====================================================
SELECT '📋 RESUMO FINAL:' as etapa;

WITH stats AS (
  SELECT 
    (SELECT COUNT(*) FROM auth.users) as total_usuarios_auth,
    (SELECT COUNT(*) FROM user_xp) as total_usuarios_xp,
    (SELECT COUNT(*) FROM xp_transactions) as total_transacoes,
    (SELECT COUNT(*) FROM ranking_by_xp) as ranking_xp_count,
    (SELECT COUNT(*) FROM ranking_by_streak WHERE current_streak > 0) as ranking_streak_count,
    (SELECT COUNT(*) FROM information_schema.routines 
     WHERE routine_schema = 'public' 
     AND routine_name IN ('calculate_level', 'add_xp_to_user', 'get_user_ranking')) as funcoes_count
)
SELECT 
  '✅ Sistema de XP e Ranking' as sistema,
  CASE 
    WHEN total_usuarios_xp > 0 AND funcoes_count >= 3 AND ranking_xp_count > 0
    THEN '✅ FUNCIONANDO CORRETAMENTE'
    ELSE '⚠️ PROBLEMAS DETECTADOS'
  END as status_geral,
  total_usuarios_auth as usuarios_cadastrados,
  total_usuarios_xp as usuarios_com_xp,
  total_transacoes as transacoes_xp,
  ranking_xp_count as usuarios_no_ranking,
  ranking_streak_count as usuarios_com_streak,
  funcoes_count as funcoes_sql_criadas
FROM stats;

-- =====================================================
-- MENSAGEM FINAL
-- =====================================================
DO $$
BEGIN
  RAISE NOTICE '';
  RAISE NOTICE '═══════════════════════════════════════════════════════';
  RAISE NOTICE '✅ DIAGNÓSTICO COMPLETO CONCLUÍDO';
  RAISE NOTICE '═══════════════════════════════════════════════════════';
  RAISE NOTICE '';
  RAISE NOTICE '📊 Revise os resultados acima para identificar problemas';
  RAISE NOTICE '';
  RAISE NOTICE '⚠️  SE HOUVER PROBLEMAS:';
  RAISE NOTICE '   1. Execute: database/setup-ranking-completo.sql';
  RAISE NOTICE '   2. Execute: database/09-popular-ranking-rapido.sql';
  RAISE NOTICE '   3. Verifique políticas RLS no Supabase Dashboard';
  RAISE NOTICE '';
END $$;
