-- =====================================================
-- SOLUÇÃO RÁPIDA: DELETAR VÍDEOS ÓRFÃOS E RECOMEÇAR
-- =====================================================

-- 🔍 PASSO 1: Ver vídeos órfãos que serão deletados
SELECT 
  id,
  "Titulo",
  uploaded_by,
  teacher_email,
  created_at
FROM videos
WHERE uploaded_by IS NULL OR teacher_email IS NULL;

-- ⚠️ PASSO 2: DELETAR TODOS OS VÍDEOS ÓRFÃOS
-- CUIDADO: Isso apagará os vídeos listados acima!
-- Descomente para executar:
/*
DELETE FROM videos
WHERE uploaded_by IS NULL OR teacher_email IS NULL;
*/

-- 🔍 PASSO 3: Verificar se foi deletado
SELECT COUNT(*) as videos_restantes FROM videos;

-- ✅ PASSO 4: AGORA OS PROFESSORES PODEM POSTAR NOVAMENTE
-- Os novos vídeos serão salvos corretamente com:
-- - uploaded_by preenchido
-- - teacher_email preenchido
-- - uploaded_by_email preenchido
-- - uploaded_by_name preenchido

-- =====================================================
-- IMPORTANTE: CORRIGIR O CÓDIGO JAVASCRIPT
-- =====================================================
-- 
-- Certifique-se de que ao salvar vídeos, o código preenche:
-- 
-- const user = await supabase.auth.getUser();
-- const videoData = {
--   Titulo: titulo,
--   URL: url,
--   uploaded_by: user.data.user.id,           // ✅ OBRIGATÓRIO
--   uploaded_by_email: user.data.user.email,  // ✅ OBRIGATÓRIO
--   teacher_email: user.data.user.email,      // ✅ OBRIGATÓRIO
--   uploaded_by_name: user.data.user.email.split('@')[0], // ✅ OBRIGATÓRIO
--   is_published: true,
--   // ... outros campos
-- };
--
-- =====================================================
