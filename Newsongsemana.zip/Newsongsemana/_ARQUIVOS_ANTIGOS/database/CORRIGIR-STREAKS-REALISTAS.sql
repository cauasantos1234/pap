-- =====================================================
-- CORREÇÃO: Ajustar Streaks para Valores REALISTAS
-- =====================================================

-- =====================================================
-- 1. ZERAR STREAKS DE CONTAS NOVAS (criadas hoje ou ontem)
-- =====================================================
UPDATE user_xp
SET 
  current_streak = 0,
  longest_streak = 0,
  updated_at = NOW()
WHERE user_id IN (
  SELECT id FROM auth.users 
  WHERE created_at > NOW() - INTERVAL '2 days'
);

-- =====================================================
-- 2. AJUSTAR STREAKS BASEADO NA ANTIGUIDADE DA CONTA
-- =====================================================
-- Contas mais antigas podem ter streaks maiores (mas realistas)

UPDATE user_xp ux
SET 
  current_streak = CASE 
    -- Conta criada há mais de 30 dias: máximo 7 dias de streak atual
    WHEN u.created_at < NOW() - INTERVAL '30 days' THEN LEAST(7, FLOOR(RANDOM() * 8)::INTEGER)
    -- Conta criada há 14-30 dias: máximo 5 dias
    WHEN u.created_at < NOW() - INTERVAL '14 days' THEN LEAST(5, FLOOR(RANDOM() * 6)::INTEGER)
    -- Conta criada há 7-14 dias: máximo 3 dias
    WHEN u.created_at < NOW() - INTERVAL '7 days' THEN LEAST(3, FLOOR(RANDOM() * 4)::INTEGER)
    -- Conta criada há 3-7 dias: máximo 2 dias
    WHEN u.created_at < NOW() - INTERVAL '3 days' THEN LEAST(2, FLOOR(RANDOM() * 3)::INTEGER)
    -- Conta nova (menos de 3 dias): 0-1 dia
    ELSE FLOOR(RANDOM() * 2)::INTEGER
  END,
  
  longest_streak = CASE 
    -- Longest streak deve ser realista também
    WHEN u.created_at < NOW() - INTERVAL '60 days' THEN LEAST(20, FLOOR(RANDOM() * 21 + 5)::INTEGER)
    WHEN u.created_at < NOW() - INTERVAL '30 days' THEN LEAST(15, FLOOR(RANDOM() * 16 + 3)::INTEGER)
    WHEN u.created_at < NOW() - INTERVAL '14 days' THEN LEAST(10, FLOOR(RANDOM() * 11 + 2)::INTEGER)
    WHEN u.created_at < NOW() - INTERVAL '7 days' THEN LEAST(5, FLOOR(RANDOM() * 6 + 1)::INTEGER)
    WHEN u.created_at < NOW() - INTERVAL '3 days' THEN LEAST(3, FLOOR(RANDOM() * 4)::INTEGER)
    ELSE FLOOR(RANDOM() * 2)::INTEGER
  END,
  
  updated_at = NOW()
FROM auth.users u
WHERE ux.user_id = u.id;

-- =====================================================
-- 3. GARANTIR QUE longest_streak >= current_streak
-- =====================================================
UPDATE user_xp
SET longest_streak = GREATEST(longest_streak, current_streak)
WHERE longest_streak < current_streak;

-- =====================================================
-- 4. AJUSTAR last_activity_date PARA SER REALISTA
-- =====================================================
UPDATE user_xp ux
SET last_activity_date = CASE 
  -- Se tem streak ativo, última atividade foi hoje ou ontem
  WHEN current_streak > 0 THEN CURRENT_DATE
  -- Se não tem streak, última atividade pode ser há alguns dias
  ELSE GREATEST(
    (SELECT created_at::DATE FROM auth.users WHERE id = ux.user_id),
    CURRENT_DATE - (FLOOR(RANDOM() * 7)::INTEGER || ' days')::INTERVAL
  )
END
WHERE user_id IN (SELECT id FROM auth.users);

-- =====================================================
-- 5. VERIFICAR RESULTADOS
-- =====================================================
SELECT '✅ Streaks corrigidos!' as status;

-- Ver usuários com seus streaks corrigidos
SELECT 
  u.email,
  u.created_at as conta_criada,
  EXTRACT(DAY FROM (NOW() - u.created_at)) as dias_desde_criacao,
  ux.current_streak as streak_atual,
  ux.longest_streak as melhor_streak,
  ux.last_activity_date as ultima_atividade,
  CASE 
    WHEN ux.current_streak > EXTRACT(DAY FROM (NOW() - u.created_at))
    THEN '❌ IMPOSSÍVEL (streak maior que idade da conta)'
    WHEN ux.longest_streak > EXTRACT(DAY FROM (NOW() - u.created_at))
    THEN '⚠️ SUSPEITO (longest streak maior que idade)'
    ELSE '✅ REALISTA'
  END as validacao
FROM auth.users u
JOIN user_xp ux ON u.id = ux.user_id
ORDER BY ux.total_xp DESC;

-- Estatísticas finais
SELECT 
  '📊 ESTATÍSTICAS PÓS-CORREÇÃO' as info,
  COUNT(*) as total_usuarios,
  MAX(current_streak) as maior_streak_atual,
  MAX(longest_streak) as maior_streak_historico,
  ROUND(AVG(current_streak), 1) as media_streak_atual,
  COUNT(CASE WHEN current_streak = 0 THEN 1 END) as usuarios_sem_streak
FROM user_xp;

-- Ver ranking atualizado
SELECT '🏆 RANKING ATUALIZADO (Top 10):' as info;
SELECT 
  rank as posicao,
  user_name as usuario,
  total_xp as xp,
  level as nivel,
  current_streak as streak_atual,
  longest_streak as melhor_streak
FROM ranking_by_xp
LIMIT 10;
