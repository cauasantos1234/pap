-- ============================================
-- VERIFICAR E CORRIGIR VÍDEOS NO SUPABASE
-- ============================================

-- 1. Ver TODOS os vídeos (sem filtro)
SELECT 
  id, 
  title, 
  instrument,
  module,
  is_published,
  LENGTH(thumbnail_url) as thumbnail_size,
  created_at
FROM videos
ORDER BY created_at DESC;

-- 2. Ver quantos vídeos estão NÃO publicados
SELECT 
  COUNT(*) as total_nao_publicados
FROM videos
WHERE is_published = false OR is_published IS NULL;

-- 3. PUBLICAR TODOS os vídeos
UPDATE videos 
SET is_published = true
WHERE is_published = false OR is_published IS NULL;

-- 4. Verificar distribuição por instrumento e módulo
SELECT 
  instrument,
  module,
  COUNT(*) as quantidade,
  SUM(CASE WHEN thumbnail_url IS NOT NULL THEN 1 ELSE 0 END) as com_thumbnail
FROM videos
WHERE is_published = true
GROUP BY instrument, module
ORDER BY instrument, module;

-- 5. Ver os últimos 5 vídeos com detalhes
SELECT 
  id,
  title,
  instrument,
  module,
  CASE 
    WHEN thumbnail_url IS NULL THEN 'SEM THUMBNAIL'
    WHEN LENGTH(thumbnail_url) < 100 THEN 'THUMBNAIL URL: ' || thumbnail_url
    ELSE 'THUMBNAIL BASE64 (tamanho: ' || LENGTH(thumbnail_url) || ' chars)'
  END as thumbnail_info,
  is_published,
  created_at
FROM videos
ORDER BY created_at DESC
LIMIT 5;
