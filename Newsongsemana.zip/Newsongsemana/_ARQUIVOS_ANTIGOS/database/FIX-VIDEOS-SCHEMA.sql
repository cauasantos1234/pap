-- ============================================
-- FIX: ATUALIZAR SCHEMA DA TABELA VIDEOS
-- ============================================
-- Execute este script no Supabase SQL Editor para adicionar as colunas que faltam

-- Adicionar colunas que podem estar faltando
ALTER TABLE videos ADD COLUMN IF NOT EXISTS description TEXT;
ALTER TABLE videos ADD COLUMN IF NOT EXISTS url TEXT;
ALTER TABLE videos ADD COLUMN IF NOT EXISTS thumbnail_url TEXT;
ALTER TABLE videos ADD COLUMN IF NOT EXISTS module VARCHAR(50);
ALTER TABLE videos ADD COLUMN IF NOT EXISTS lesson VARCHAR(100);
ALTER TABLE videos ADD COLUMN IF NOT EXISTS uploaded_by UUID REFERENCES auth.users(id) ON DELETE SET NULL;
ALTER TABLE videos ADD COLUMN IF NOT EXISTS uploaded_by_name VARCHAR(255);
ALTER TABLE videos ADD COLUMN IF NOT EXISTS teacher_email VARCHAR(255);
ALTER TABLE videos ADD COLUMN IF NOT EXISTS upload_type VARCHAR(20) DEFAULT 'youtube';

-- Criar índices para melhor performance
CREATE INDEX IF NOT EXISTS idx_videos_uploaded_by ON videos(uploaded_by);
CREATE INDEX IF NOT EXISTS idx_videos_teacher_email ON videos(teacher_email);
CREATE INDEX IF NOT EXISTS idx_videos_upload_type ON videos(upload_type);

-- Verificar estrutura final
SELECT 
  column_name, 
  data_type, 
  is_nullable
FROM information_schema.columns 
WHERE table_name = 'videos'
ORDER BY ordinal_position;
