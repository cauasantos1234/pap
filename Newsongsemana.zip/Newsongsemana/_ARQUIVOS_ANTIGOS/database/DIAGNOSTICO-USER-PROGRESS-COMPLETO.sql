-- =====================================================
-- DIAGNÓSTICO: PROGRESSO DOS USUÁRIOS
-- =====================================================

-- 🔍 PASSO 1: Verificar estrutura da tabela user_progress
SELECT 
    column_name,
    data_type,
    is_nullable,
    column_default
FROM information_schema.columns
WHERE table_name = 'user_progress'
ORDER BY ordinal_position;

-- 🔍 PASSO 2: Verificar Foreign Keys da tabela user_progress
SELECT
    tc.constraint_name,
    tc.table_name,
    kcu.column_name,
    ccu.table_name AS foreign_table_name,
    ccu.column_name AS foreign_column_name
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage AS ccu
    ON ccu.constraint_name = tc.constraint_name
WHERE tc.table_name = 'user_progress' 
    AND tc.constraint_type = 'FOREIGN KEY';

-- 🔍 PASSO 3: Contar total de registros de progresso
SELECT 
    COUNT(*) as total_registros_progresso,
    COUNT(DISTINCT user_id) as usuarios_com_progresso,
    COUNT(DISTINCT video_id) as videos_com_progresso,
    MIN(created_at) as primeiro_registro,
    MAX(created_at) as ultimo_registro
FROM user_progress;

-- 🔍 PASSO 4: Ver progresso por usuário
SELECT 
    u.id,
    u.email,
    u.role,
    COUNT(up.id) as total_videos_assistidos,
    COUNT(CASE WHEN up.completed THEN 1 END) as videos_completos,
    ROUND(AVG(up.progress_percentage), 2) as progresso_medio,
    MAX(up.created_at) as ultima_atividade
FROM users u
LEFT JOIN user_progress up ON up.user_id = u.id
GROUP BY u.id, u.email, u.role
ORDER BY total_videos_assistidos DESC;

-- 🔍 PASSO 5: Verificar progressos ÓRFÃOS (sem usuário ou vídeo válido)
SELECT 
    up.id,
    up.user_id,
    up.video_id,
    up.progress_percentage,
    up.completed,
    CASE 
        WHEN u.id IS NULL THEN '❌ Usuário não existe'
        ELSE '✅ Usuário OK'
    END as status_usuario,
    CASE 
        WHEN v.id IS NULL THEN '❌ Vídeo não existe'
        ELSE '✅ Vídeo OK'
    END as status_video
FROM user_progress up
LEFT JOIN users u ON up.user_id = u.id
LEFT JOIN videos v ON up.video_id = v.id
WHERE u.id IS NULL OR v.id IS NULL;

-- 🔍 PASSO 6: Contar registros órfãos
SELECT 
    COUNT(*) as total_progressos,
    COUNT(CASE WHEN u.id IS NOT NULL AND v.id IS NOT NULL THEN 1 END) as progressos_validos,
    COUNT(CASE WHEN u.id IS NULL THEN 1 END) as progressos_usuario_invalido,
    COUNT(CASE WHEN v.id IS NULL THEN 1 END) as progressos_video_invalido
FROM user_progress up
LEFT JOIN users u ON up.user_id = u.id
LEFT JOIN videos v ON up.video_id = v.id;

-- 🔍 PASSO 7: Ver últimos 20 registros de progresso
SELECT 
    up.id,
    u.email as usuario,
    v."Titulo" as video,
    up.progress_percentage,
    up.completed,
    up.created_at
FROM user_progress up
LEFT JOIN users u ON up.user_id = u.id
LEFT JOIN videos v ON up.video_id = v.id
ORDER BY up.created_at DESC
LIMIT 20;

-- 🔍 PASSO 8: Verificar duplicatas (usuário + vídeo)
SELECT 
    user_id,
    video_id,
    COUNT(*) as registros_duplicados,
    STRING_AGG(id::text, ', ') as ids_duplicados
FROM user_progress
GROUP BY user_id, video_id
HAVING COUNT(*) > 1
ORDER BY registros_duplicados DESC;

-- 🔍 PASSO 9: Verificar políticas RLS
SELECT 
    schemaname,
    tablename,
    policyname,
    permissive,
    roles,
    cmd,
    qual,
    with_check
FROM pg_policies
WHERE tablename = 'user_progress'
ORDER BY cmd, policyname;

-- 🔍 PASSO 10: Verificar se RLS está ativo
SELECT 
    schemaname,
    tablename,
    rowsecurity as rls_ativo
FROM pg_tables
WHERE tablename = 'user_progress';

-- 🔍 PASSO 11: Ver vídeos mais assistidos
SELECT 
    v.id,
    v."Titulo",
    COUNT(up.id) as total_visualizacoes,
    COUNT(CASE WHEN up.completed THEN 1 END) as visualizacoes_completas,
    ROUND(AVG(up.progress_percentage), 2) as progresso_medio
FROM videos v
LEFT JOIN user_progress up ON up.video_id = v.id
GROUP BY v.id, v."Titulo"
ORDER BY total_visualizacoes DESC
LIMIT 20;

-- 🔍 PASSO 12: Verificar constraints da tabela
SELECT
    con.conname AS constraint_name,
    con.contype AS constraint_type,
    CASE con.contype
        WHEN 'p' THEN 'PRIMARY KEY'
        WHEN 'f' THEN 'FOREIGN KEY'
        WHEN 'u' THEN 'UNIQUE'
        WHEN 'c' THEN 'CHECK'
        ELSE con.contype::text
    END AS constraint_type_desc
FROM pg_constraint con
JOIN pg_class rel ON rel.oid = con.conrelid
WHERE rel.relname = 'user_progress';

-- 🔍 PASSO 13: Verificar índices da tabela
SELECT
    indexname,
    indexdef
FROM pg_indexes
WHERE tablename = 'user_progress'
ORDER BY indexname;

-- =====================================================
-- ANÁLISE DOS RESULTADOS:
-- =====================================================
-- 
-- ✅ SISTEMA SAUDÁVEL:
-- - PASSO 3: Deve haver registros de progresso
-- - PASSO 4: Usuários aparecem com seus progressos
-- - PASSO 5: Nenhum resultado (sem órfãos)
-- - PASSO 6: progressos_validos = total_progressos
-- - PASSO 8: Nenhum resultado (sem duplicatas)
-- - PASSO 10: rls_ativo = true
--
-- ❌ PROBLEMAS A CORRIGIR:
-- - PASSO 3: Se total_registros_progresso = 0, nada está sendo salvo
-- - PASSO 5/6: Se há órfãos, há problemas de integridade
-- - PASSO 8: Se há duplicatas, falta constraint UNIQUE
-- - PASSO 9: Políticas RLS muito restritivas impedem salvar
-- - PASSO 2: Se não há FK, pode haver dados inconsistentes
--
-- 🔧 SOLUÇÕES RÁPIDAS:
-- Se não há registros: verificar se o frontend está chamando a API
-- Se há órfãos: executar DELETE para limpar dados inválidos
-- Se há duplicatas: criar UNIQUE constraint em (user_id, video_id)
-- Se RLS bloqueia: ajustar políticas para permitir INSERT/UPDATE
--
-- =====================================================
