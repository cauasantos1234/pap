-- ============================================
-- FIX: POLÍTICAS RLS DA TABELA VIDEOS
-- ============================================
-- As políticas atuais estão muito restritivas e bloqueiam a leitura dos vídeos

-- 1. Remover todas as políticas antigas
DROP POLICY IF EXISTS "Todos podem ver vídeos publicados" ON videos;
DROP POLICY IF EXISTS "Professores podem inserir vídeos" ON videos;
DROP POLICY IF EXISTS "Professores podem atualizar seus vídeos" ON videos;
DROP POLICY IF EXISTS "Professores podem deletar seus vídeos" ON videos;

-- 2. Criar política PERMISSIVA para leitura
-- Permitir que TODOS (autenticados ou não) vejam vídeos publicados
CREATE POLICY "videos_select_public"
  ON videos FOR SELECT
  USING (true); -- Permite leitura para todos

-- 3. Professores autenticados podem inserir
CREATE POLICY "videos_insert_authenticated"
  ON videos FOR INSERT
  TO authenticated
  WITH CHECK (true); -- Qualquer usuário autenticado pode inserir

-- 4. Professores podem atualizar seus próprios vídeos
CREATE POLICY "videos_update_own"
  ON videos FOR UPDATE
  TO authenticated
  USING (auth.uid() = uploaded_by)
  WITH CHECK (auth.uid() = uploaded_by);

-- 5. Professores podem deletar seus próprios vídeos
CREATE POLICY "videos_delete_own"
  ON videos FOR DELETE
  TO authenticated
  USING (auth.uid() = uploaded_by);

-- 6. Verificar políticas aplicadas
SELECT 
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual,
  with_check
FROM pg_policies 
WHERE tablename = 'videos';

-- Pronto! Agora todos podem VER os vídeos, mas só professores podem criar/editar/deletar
