-- =====================================================
-- DIAGNÓSTICO COMPLETO: VÍDEOS <-> PROFESSORES
-- Identificar problemas de autoria dos vídeos
-- =====================================================

-- 🔍 PASSO 1: Ver estrutura da tabela videos
SELECT 
  column_name, 
  data_type,
  is_nullable,
  column_default
FROM information_schema.columns
WHERE table_name = 'videos'
ORDER BY ordinal_position;

-- =====================================================
-- 🔍 PASSO 2: Ver TODOS os vídeos com suas associações
-- =====================================================
SELECT 
  v.id,
  v.title,
  v.instrument,
  v.module,
  v.uploaded_by,
  v.teacher_email,
  v.uploaded_by_name,
  v.created_at
FROM videos v
ORDER BY v.created_at DESC
LIMIT 20;

-- =====================================================
-- 🔍 PASSO 3: Ver TODOS os professores disponíveis
-- =====================================================
SELECT 
  u.id,
  u.email,
  u.name,
  u.role,
  u.created_at
FROM users u
WHERE 
  u.role = 'teacher' OR 
  u.role = 'professor'
ORDER BY u.created_at;

-- =====================================================
-- 🔍 PASSO 4: Contar vídeos por professor
-- =====================================================
-- Contar usando uploaded_by
SELECT 
  u.email,
  u.name,
  COUNT(v.id) as total_videos
FROM users u
LEFT JOIN videos v ON v.uploaded_by = u.id
WHERE u.role IN ('teacher', 'professor')
GROUP BY u.id, u.email, u.name
ORDER BY total_videos DESC;

-- =====================================================
-- 🔍 PASSO 5: Identificar vídeos ÓRFÃOS (sem professor)
-- =====================================================
SELECT 
  v.id,
  v.title,
  v.instrument,
  v.module,
  v.uploaded_by,
  v.teacher_email,
  v.uploaded_by_name,
  v.created_at,
  'VÍDEO ÓRFÃO - SEM PROFESSOR ASSOCIADO' as status
FROM videos v
WHERE 
  (v.uploaded_by IS NULL OR v.uploaded_by::TEXT = '') AND
  (v.teacher_email IS NULL OR v.teacher_email = '');

-- =====================================================
-- 🔍 PASSO 6: Ver quem postou cada vídeo vs. quem aparece
-- =====================================================
SELECT 
  v.id,
  v.title,
  
  -- Quem está associado no banco
  v.uploaded_by as db_uploaded_by_id,
  v.teacher_email as db_teacher_email,
  v.uploaded_by_name as db_name,
  
  -- Informações do usuário real
  u.id as user_real_id,
  u.email as user_real_email,
  u.name as user_real_name,
  
  -- Verificar se há divergência
  CASE 
    WHEN v.uploaded_by IS NOT NULL AND v.uploaded_by != u.id 
    THEN '⚠️ DIVERGÊNCIA: ID no vídeo diferente do usuário'
    WHEN v.teacher_email IS NOT NULL AND v.teacher_email != u.email
    THEN '⚠️ DIVERGÊNCIA: Email no vídeo diferente do usuário'
    WHEN v.uploaded_by IS NULL OR v.uploaded_by::TEXT = ''
    THEN '❌ PROBLEMA: Vídeo sem autor definido'
    ELSE '✅ OK'
  END as status_autoria
  
FROM videos v
LEFT JOIN users u ON v.uploaded_by = u.id
ORDER BY v.created_at DESC;

-- =====================================================
-- 🔍 PASSO 7: Ver autenticação Supabase (auth.users)
-- =====================================================
SELECT 
  au.id,
  au.email,
  au.created_at,
  au.confirmed_at,
  au.last_sign_in_at,
  -- Ver se tem correspondente em users
  CASE 
    WHEN EXISTS (SELECT 1 FROM users WHERE users.id = au.id) THEN '✅ TEM'
    ELSE '❌ NÃO TEM'
  END as tem_em_users
FROM auth.users au
ORDER BY au.created_at DESC
LIMIT 20;

-- =====================================================
-- 🔍 PASSO 8: Políticas RLS que podem afetar visualização
-- =====================================================
SELECT 
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual,
  with_check
FROM pg_policies
WHERE tablename = 'videos'
ORDER BY policyname;

-- =====================================================
-- 📊 RESUMO DO DIAGNÓSTICO
-- =====================================================
SELECT 
  'Total de vídeos' as metrica,
  COUNT(*)::TEXT as valor
FROM videos
UNION ALL
SELECT 
  'Vídeos com uploaded_by preenchido',
  COUNT(*)::TEXT
FROM videos
WHERE uploaded_by IS NOT NULL AND uploaded_by::TEXT != ''
UNION ALL
SELECT 
  'Vídeos ÓRFÃOS (sem uploaded_by)',
  COUNT(*)::TEXT
FROM videos
WHERE uploaded_by IS NULL OR uploaded_by::TEXT = ''
UNION ALL
SELECT 
  'Total de professores',
  COUNT(*)::TEXT
FROM users
WHERE role IN ('teacher', 'professor')
UNION ALL
SELECT 
  'Professores na auth.users',
  COUNT(*)::TEXT
FROM auth.users au
WHERE EXISTS (SELECT 1 FROM users u WHERE u.id = au.id AND u.role IN ('teacher', 'professor'));

-- =====================================================
-- 🔧 POSSÍVEIS SOLUÇÕES
-- =====================================================

-- Solução 1: Associar vídeos órfãos a um professor específico
-- DESCOMENTE e ajuste o email do professor correto:
/*
UPDATE videos
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'professor@email.com' LIMIT 1),
  teacher_email = 'professor@email.com',
  uploaded_by_name = (SELECT name FROM users WHERE email = 'professor@email.com' LIMIT 1)
WHERE uploaded_by IS NULL OR uploaded_by::TEXT = '';
*/

-- Solução 2: Corrigir vídeos que aparecem com autor errado
-- DESCOMENTE e ajuste:
/*
UPDATE videos
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'email_correto@newsong.com'),
  teacher_email = 'email_correto@newsong.com',
  uploaded_by_name = (SELECT name FROM users WHERE email = 'email_correto@newsong.com')
WHERE id IN (1, 2, 3); -- IDs dos vídeos com problema
*/

-- Solução 3: Adicionar coluna author_id se não existir
/*
ALTER TABLE videos ADD COLUMN IF NOT EXISTS author_id UUID REFERENCES users(id);
CREATE INDEX IF NOT EXISTS idx_videos_author_id ON videos(author_id);
*/
