-- =====================================================
-- DELETAR REGISTROS ÓRFÃOS (video_id NULL)
-- =====================================================

-- 🗑️ Deletar todos os registros sem video_id
DELETE FROM user_progress
WHERE video_id IS NULL;

-- ✅ Verificar se foi limpo
SELECT 
    COUNT(*) as total_progressos,
    COUNT(CASE WHEN video_id IS NULL THEN 1 END) as com_video_null,
    COUNT(CASE WHEN video_id IS NOT NULL THEN 1 END) as com_video_valido
FROM user_progress;
