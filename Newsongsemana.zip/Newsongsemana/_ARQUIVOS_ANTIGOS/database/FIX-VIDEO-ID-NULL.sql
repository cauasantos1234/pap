-- =====================================================
-- CORREÇÃO: video_id NULL em user_progress
-- =====================================================
-- PROBLEMA: Registros de progresso sendo salvos sem video_id
-- CAUSA: Frontend não está enviando video_id ao salvar progresso
-- =====================================================

-- 🔍 PASSO 1: Ver os registros órfãos em detalhes
SELECT 
    up.id,
    up.user_id,
    u.email as usuario_email,
    up.video_id,
    up.instrument,
    up.module,
    up.lesson_id,
    up.progress_percentage,
    up.completed,
    up.created_at
FROM user_progress up
LEFT JOIN users u ON up.user_id = u.id
WHERE up.video_id IS NULL
ORDER BY up.created_at DESC;

-- =====================================================
-- OPÇÃO 1: LIMPAR REGISTROS ÓRFÃOS (RECOMENDADO)
-- =====================================================
-- Se não houver como identificar a qual vídeo pertencem,
-- é melhor deletar e deixar o usuário recomeçar

-- ⚠️ PREVIEW: Ver quantos registros serão deletados
SELECT COUNT(*) as registros_que_serao_deletados
FROM user_progress
WHERE video_id IS NULL;

-- 🗑️ EXECUTAR LIMPEZA (descomente para executar)
-- DELETE FROM user_progress
-- WHERE video_id IS NULL;

-- =====================================================
-- OPÇÃO 2: TENTAR RECUPERAR video_id (SE POSSÍVEL)
-- =====================================================
-- Se houver instrument, module e lesson_id, podemos tentar
-- encontrar o vídeo correspondente

-- 🔍 Ver se é possível identificar os vídeos pelos metadados
SELECT 
    up.id as progress_id,
    up.instrument,
    up.module,
    up.lesson_id,
    v.id as possivel_video_id,
    v."Titulo" as video_titulo,
    COUNT(*) OVER (PARTITION BY up.id) as videos_encontrados
FROM user_progress up
LEFT JOIN videos v ON (
    v."Instrumento" = up.instrument AND
    v."Modulo" = up.module
)
WHERE up.video_id IS NULL
ORDER BY up.id, v.created_at;

-- =====================================================
-- PREVENÇÃO: Adicionar constraint NOT NULL
-- =====================================================
-- Após limpar os registros órfãos, adicionar constraint
-- para garantir que video_id seja sempre obrigatório

-- ⚠️ Só execute isso APÓS limpar os registros órfãos!
-- ALTER TABLE user_progress
-- ALTER COLUMN video_id SET NOT NULL;

-- =====================================================
-- VERIFICAÇÃO PÓS-CORREÇÃO
-- =====================================================
-- Executar após a correção para confirmar que não há mais órfãos

SELECT 
    COUNT(*) as total_progressos,
    COUNT(CASE WHEN video_id IS NULL THEN 1 END) as com_video_null,
    COUNT(CASE WHEN video_id IS NOT NULL THEN 1 END) as com_video_valido
FROM user_progress;

-- =====================================================
-- 📝 PRÓXIMOS PASSOS NO CÓDIGO FRONTEND:
-- =====================================================
-- 
-- 1. VERIFICAR onde o progresso é salvo no código
-- 2. GARANTIR que video_id está sendo enviado
-- 3. EXEMPLO de chamada correta:
--
-- const { error } = await supabase
--   .from('user_progress')
--   .upsert({
--     user_id: user.id,
--     video_id: currentVideo.id,  // ← OBRIGATÓRIO!
--     instrument: currentVideo.Instrumento,
--     module: currentVideo.Modulo,
--     lesson_id: currentVideo.lesson_id,
--     progress_percentage: Math.floor(percentage),
--     completed: percentage >= 90
--   });
--
-- =====================================================
