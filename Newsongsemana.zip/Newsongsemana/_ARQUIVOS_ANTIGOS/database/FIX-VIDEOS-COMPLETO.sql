-- ============================================
-- FIX COMPLETO: RECRIAR TABELA VIDEOS
-- ============================================
-- ATENÇÃO: Este script vai APAGAR a tabela videos existente e criar uma nova
-- Se você tem vídeos importantes, faça backup primeiro!

-- 1. Verificar se a tabela existe
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' AND table_name = 'videos';

-- 2. DROPAR tabela antiga (CUIDADO: isso apaga todos os vídeos!)
DROP TABLE IF EXISTS videos CASCADE;

-- 3. Criar tabela nova com estrutura correta
CREATE TABLE videos (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255) NOT NULL,
  description TEXT,
  url TEXT,
  thumbnail_url TEXT,
  instrument VARCHAR(50),
  module VARCHAR(50),
  lesson VARCHAR(100),
  duration VARCHAR(20) DEFAULT '0:00',
  uploaded_by UUID REFERENCES auth.users(id) ON DELETE SET NULL,
  uploaded_by_name VARCHAR(255),
  teacher_email VARCHAR(255),
  views INTEGER DEFAULT 0,
  likes INTEGER DEFAULT 0,
  is_published BOOLEAN DEFAULT true,
  upload_type VARCHAR(20) DEFAULT 'youtube',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- 4. Criar índices
CREATE INDEX idx_videos_uploaded_by ON videos(uploaded_by);
CREATE INDEX idx_videos_teacher_email ON videos(teacher_email);
CREATE INDEX idx_videos_instrument ON videos(instrument);
CREATE INDEX idx_videos_module ON videos(module);
CREATE INDEX idx_videos_created ON videos(created_at DESC);

-- 5. Habilitar RLS (Row Level Security)
ALTER TABLE videos ENABLE ROW LEVEL SECURITY;

-- 6. Políticas de segurança
-- Todos podem ler vídeos publicados
CREATE POLICY "Todos podem ver vídeos publicados"
  ON videos FOR SELECT
  USING (is_published = true);

-- Professores autenticados podem inserir vídeos
CREATE POLICY "Professores podem inserir vídeos"
  ON videos FOR INSERT
  WITH CHECK (auth.uid() = uploaded_by);

-- Professores podem atualizar seus próprios vídeos
CREATE POLICY "Professores podem atualizar seus vídeos"
  ON videos FOR UPDATE
  USING (auth.uid() = uploaded_by);

-- Professores podem deletar seus próprios vídeos
CREATE POLICY "Professores podem deletar seus vídeos"
  ON videos FOR DELETE
  USING (auth.uid() = uploaded_by);

-- 7. Verificar estrutura final
SELECT 
  column_name, 
  data_type, 
  character_maximum_length,
  is_nullable,
  column_default
FROM information_schema.columns 
WHERE table_name = 'videos'
ORDER BY ordinal_position;

-- Pronto! Agora você pode fazer upload de vídeos com thumbnail
