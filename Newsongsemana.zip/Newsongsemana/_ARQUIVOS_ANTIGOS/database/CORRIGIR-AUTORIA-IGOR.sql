-- =====================================================
-- 🔧 CORREÇÃO: Transferir vídeos para Igor
-- =====================================================
-- Problema: Vídeos aparecem como a101442@epinfante.com
-- Solução: Transferir para igorguedes@gmail.com
-- =====================================================

-- 1️⃣ Ver vídeos ANTES da correção
SELECT 
  id,
  title,
  teacher_email as email_atual,
  uploaded_by_name as nome_atual,
  created_at
FROM videos
WHERE teacher_email = 'a101442@epinfante.com'
ORDER BY created_at DESC;

-- 2️⃣ EXECUTAR CORREÇÃO
UPDATE videos
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'igorguedes@gmail.com'),
  teacher_email = 'igorguedes@gmail.com',
  uploaded_by_name = 'igorguedes'
WHERE teacher_email = 'a101442@epinfante.com';

-- 3️⃣ Ver vídeos DEPOIS da correção
SELECT 
  id,
  title,
  teacher_email as email_corrigido,
  uploaded_by_name as nome_corrigido,
  created_at
FROM videos
WHERE teacher_email = 'igorguedes@gmail.com'
ORDER BY created_at DESC;

-- 4️⃣ Verificar quantos foram corrigidos
SELECT 
  COUNT(*) as total_videos_igor
FROM videos
WHERE teacher_email = 'igorguedes@gmail.com';

-- =====================================================
-- ✅ RESULTADO ESPERADO: 4 vídeos transferidos
-- =====================================================
