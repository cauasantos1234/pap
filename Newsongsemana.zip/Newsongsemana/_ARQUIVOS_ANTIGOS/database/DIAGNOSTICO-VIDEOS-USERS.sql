-- =====================================================
-- DIAGNÓSTICO: CONEXÃO VÍDEOS <-> USUÁRIOS
-- =====================================================

-- 🔍 PASSO 1: Verificar se há Foreign Key entre videos e users
SELECT
    tc.constraint_name,
    tc.table_name,
    kcu.column_name,
    ccu.table_name AS foreign_table_name,
    ccu.column_name AS foreign_column_name
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage AS ccu
    ON ccu.constraint_name = tc.constraint_name
WHERE tc.table_name = 'videos' 
    AND tc.constraint_type = 'FOREIGN KEY';

-- 🔍 PASSO 2: Ver todos os vídeos atuais e suas associações
SELECT 
  v.id,
  v."Titulo",
  v.uploaded_by,
  v.uploaded_by_email,
  v.teacher_email,
  v.uploaded_by_name,
  u.id as user_exists_id,
  u.email as user_exists_email,
  u.role as user_role,
  CASE 
    WHEN v.uploaded_by IS NULL THEN '❌ SEM uploaded_by'
    WHEN u.id IS NULL THEN '❌ uploaded_by INVÁLIDO (usuário não existe)'
    ELSE '✅ OK - usuário existe'
  END as status_conexao
FROM videos v
LEFT JOIN users u ON v.uploaded_by = u.id
ORDER BY v.created_at DESC;

-- 🔍 PASSO 3: Contar vídeos por status de conexão
SELECT 
  COUNT(*) as total_videos,
  COUNT(CASE WHEN v.uploaded_by IS NOT NULL AND u.id IS NOT NULL THEN 1 END) as videos_conectados,
  COUNT(CASE WHEN v.uploaded_by IS NULL THEN 1 END) as videos_sem_uploaded_by,
  COUNT(CASE WHEN v.uploaded_by IS NOT NULL AND u.id IS NULL THEN 1 END) as videos_usuario_invalido
FROM videos v
LEFT JOIN users u ON v.uploaded_by = u.id;

-- 🔍 PASSO 4: Ver vídeos ÓRFÃOS (sem usuário válido)
SELECT 
  v.id,
  v."Titulo",
  v.uploaded_by,
  v.uploaded_by_email,
  v.teacher_email,
  v.created_at
FROM videos v
LEFT JOIN users u ON v.uploaded_by = u.id
WHERE v.uploaded_by IS NULL OR u.id IS NULL;

-- 🔍 PASSO 5: Ver usuários professores e quantos vídeos cada um tem
SELECT 
  u.id,
  u.email,
  u.role,
  COUNT(v.id) as total_videos_postados
FROM users u
LEFT JOIN videos v ON v.uploaded_by = u.id
WHERE u.role = 'professor'
GROUP BY u.id, u.email, u.role
ORDER BY total_videos_postados DESC;

-- 🔍 PASSO 6: Verificar políticas RLS da tabela videos
SELECT 
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual,
  with_check
FROM pg_policies
WHERE tablename = 'videos'
ORDER BY cmd, policyname;

-- 🔍 PASSO 7: Testar se RLS está ativo
SELECT 
  schemaname,
  tablename,
  rowsecurity as rls_ativo
FROM pg_tables
WHERE tablename = 'videos';

-- =====================================================
-- ANÁLISE DOS RESULTADOS:
-- =====================================================
-- 
-- ✅ CONEXÃO SAUDÁVEL:
-- - PASSO 2: Todos os vídeos mostram "✅ OK - usuário existe"
-- - PASSO 3: videos_conectados = total_videos
-- - PASSO 4: Nenhum resultado (sem órfãos)
-- - PASSO 5: Professores aparecem com seus vídeos
--
-- ❌ PROBLEMAS A CORRIGIR:
-- - PASSO 1: Se não houver FK, vídeos podem ficar órfãos
-- - PASSO 2/4: Vídeos com status "❌" precisam ser corrigidos
-- - PASSO 3: Se videos_sem_uploaded_by > 0, há vídeos órfãos
-- - PASSO 6: Políticas RLS muito restritivas podem esconder vídeos
--
-- =====================================================
