-- =====================================================
-- CORREÇÃO RÁPIDA: Associar vídeos ao professor correto
-- =====================================================

-- 📋 INSTRUÇÕES:
-- 1. Primeiro, veja quais professores existem
-- 2. Encontre o email do professor CORRETO
-- 3. Descomente e execute o UPDATE correspondente

-- =====================================================
-- 🔍 PASSO 1: Ver todos os professores disponíveis
-- =====================================================
SELECT 
  id,
  email,
  name,
  role,
  created_at
FROM users
WHERE role IN ('teacher', 'professor')
ORDER BY created_at;

-- =====================================================
-- 🔍 PASSO 2: Ver vídeos que precisam de correção
-- =====================================================
SELECT 
  v.id,
  v.title,
  v.instrument,
  v.module,
  v.uploaded_by_email as autor_atual,
  v.uploaded_by_name as nome_atual,
  v.created_at
FROM videos v
ORDER BY v.created_at DESC;

-- =====================================================
-- 🔧 CORREÇÃO: Escolha UMA das opções abaixo
-- =====================================================

-- ❌ IMPORTANTE: DESCOMENTE APENAS UMA OPÇÃO POR VEZ

-- =====================================================
-- OPÇÃO 1: Corrigir TODOS os vídeos órfãos (sem autor)
-- =====================================================
/*
UPDATE videos
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'SEU-EMAIL-AQUI@newsong.com' LIMIT 1),
  uploaded_by_email = 'SEU-EMAIL-AQUI@newsong.com',
  teacher_email = 'SEU-EMAIL-AQUI@newsong.com',
  uploaded_by_name = (SELECT name FROM users WHERE email = 'SEU-EMAIL-AQUI@newsong.com' LIMIT 1)
WHERE 
  uploaded_by IS NULL 
  OR uploaded_by::TEXT = ''
  OR uploaded_by_email IS NULL
  OR uploaded_by_email = '';

-- Verificar quantos foram atualizados
SELECT COUNT(*) as videos_corrigidos 
FROM videos 
WHERE uploaded_by_email = 'SEU-EMAIL-AQUI@newsong.com';
*/

-- =====================================================
-- OPÇÃO 2: Corrigir vídeos ESPECÍFICOS por ID
-- =====================================================
/*
-- Substitua os IDs e o email:
UPDATE videos
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'SEU-EMAIL-AQUI@newsong.com'),
  uploaded_by_email = 'SEU-EMAIL-AQUI@newsong.com',
  teacher_email = 'SEU-EMAIL-AQUI@newsong.com',
  uploaded_by_name = (SELECT name FROM users WHERE email = 'SEU-EMAIL-AQUI@newsong.com')
WHERE id IN (1, 2, 3, 4, 5); -- Coloque os IDs dos vídeos aqui

-- Ver resultado
SELECT id, title, uploaded_by_email, uploaded_by_name
FROM videos
WHERE id IN (1, 2, 3, 4, 5);
*/

-- =====================================================
-- OPÇÃO 3: Mudar autor de vídeos que estão com autor ERRADO
-- =====================================================
/*
-- Trocar vídeos que estão como "ProfessorErrado" para "ProfessorCorreto"
UPDATE videos
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'professor-correto@newsong.com'),
  uploaded_by_email = 'professor-correto@newsong.com',
  teacher_email = 'professor-correto@newsong.com',
  uploaded_by_name = (SELECT name FROM users WHERE email = 'professor-correto@newsong.com')
WHERE 
  uploaded_by_email = 'professor-errado@newsong.com';

-- Ver quantos mudaram
SELECT COUNT(*) as videos_alterados
FROM videos
WHERE uploaded_by_email = 'professor-correto@newsong.com';
*/

-- =====================================================
-- OPÇÃO 4: Corrigir por instrumento ou módulo
-- =====================================================
/*
-- Exemplo: Todos os vídeos de guitarra são do Professor X
UPDATE videos
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'professor-guitarra@newsong.com'),
  uploaded_by_email = 'professor-guitarra@newsong.com',
  teacher_email = 'professor-guitarra@newsong.com',
  uploaded_by_name = (SELECT name FROM users WHERE email = 'professor-guitarra@newsong.com')
WHERE 
  instrument = 'guitar'
  AND (uploaded_by IS NULL OR uploaded_by_email IS NULL);
*/

-- =====================================================
-- OPÇÃO 5: Corrigir por data de criação
-- =====================================================
/*
-- Exemplo: Vídeos postados hoje são meus
UPDATE videos
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'MEU-EMAIL@newsong.com'),
  uploaded_by_email = 'MEU-EMAIL@newsong.com',
  teacher_email = 'MEU-EMAIL@newsong.com',
  uploaded_by_name = (SELECT name FROM users WHERE email = 'MEU-EMAIL@newsong.com')
WHERE 
  DATE(created_at) = CURRENT_DATE;
*/

-- =====================================================
-- 🔍 PASSO 3: Verificar resultado final
-- =====================================================
SELECT 
  v.id,
  v.title,
  v.instrument,
  v.uploaded_by_email as professor_email,
  v.uploaded_by_name as professor_nome,
  v.created_at
FROM videos v
ORDER BY v.created_at DESC
LIMIT 10;

-- =====================================================
-- 📊 ESTATÍSTICAS FINAIS
-- =====================================================
-- Quantos vídeos cada professor tem agora
SELECT 
  uploaded_by_email as professor,
  uploaded_by_name as nome,
  COUNT(*) as total_videos
FROM videos
WHERE uploaded_by_email IS NOT NULL
GROUP BY uploaded_by_email, uploaded_by_name
ORDER BY total_videos DESC;

-- Vídeos ainda órfãos (deveria ser zero)
SELECT COUNT(*) as videos_sem_autor
FROM videos
WHERE uploaded_by IS NULL OR uploaded_by_email IS NULL;
