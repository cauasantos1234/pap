-- =====================================================
-- SOLUÇÃO: VÍDEOS QUE SUMIRAM
-- Os vídeos não foram deletados, apenas não estão publicados
-- =====================================================

-- 🔍 PASSO 0: Verificar estrutura da tabela videos
SELECT column_name, data_type, is_nullable, column_default
FROM information_schema.columns
WHERE table_name = 'videos'
ORDER BY ordinal_position;

-- 🔍 PASSO 1: Ver vídeos e seus criadores
SELECT 
  id,
  "Titulo",
  uploaded_by,
  uploaded_by_name,
  uploaded_by_email,
  teacher_email,
  is_published,
  created_at
FROM videos
ORDER BY created_at DESC;

-- 🔍 PASSO 1B: Contar vídeos por professor
SELECT 
  COALESCE(uploaded_by_email, teacher_email, 'SEM EMAIL') as email_professor,
  uploaded_by_name as nome_professor,
  COUNT(*) as total_videos
FROM videos
GROUP BY uploaded_by_email, teacher_email, uploaded_by_name
ORDER BY total_videos DESC;

-- ✅ PASSO 2: VERIFICAR USUÁRIOS PROFESSORES DISPONÍVEIS
-- Primeiro ver estrutura da tabela users
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_name = 'users'
ORDER BY ordinal_position;

-- Ver professores (ajustar conforme colunas disponíveis)
SELECT *
FROM users
WHERE role = 'professor'
ORDER BY created_at;

-- ✅ PASSO 3: ASSOCIAR VÍDEOS A UM PROFESSOR
-- OPÇÃO A: Associar TODOS os vídeos órfãos ao primeiro professor encontrado
-- (Substitua 'professor@email.com' pelo email do professor correto)
/*
UPDATE videos
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'professor@email.com' LIMIT 1),
  uploaded_by_email = 'professor@email.com',
  teacher_email = 'professor@email.com',
  uploaded_by_name = (SELECT full_name FROM users WHERE email = 'professor@email.com' LIMIT 1)
WHERE uploaded_by IS NULL OR teacher_email IS NULL;
*/

-- OPÇÃO B: Associar cada vídeo manualmente (mais preciso)
-- Descomente e ajuste os IDs e emails conforme necessário
/*
UPDATE videos 
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'professor1@email.com'),
  uploaded_by_email = 'professor1@email.com',
  teacher_email = 'professor1@email.com',
  uploaded_by_name = (SELECT full_name FROM users WHERE email = 'professor1@email.com')
WHERE id = '534c3d2f-1a97-48cb-a6db-963a643d57bb'; -- Aula de Guitarra

UPDATE videos 
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'professor2@email.com'),
  uploaded_by_email = 'professor2@email.com',
  teacher_email = 'professor2@email.com',
  uploaded_by_name = (SELECT full_name FROM users WHERE email = 'professor2@email.com')
WHERE id = 'e93e0dfb-632a-4df7-9b41-6ab138f2380e'; -- Acordes Maiores
*/

-- 🔍 PASSO 4: Verificar se funcionou
SELECT 
  id,
  "Titulo",
  uploaded_by_email,
  teacher_email,
  uploaded_by_name,
  is_published
FROM videos
ORDER BY created_at DESC;

-- 📝 RESULTADO ESPERADO:
-- total_videos = X
-- videos_publicados = X
-- videos_nao_publicados = 0

-- =====================================================
-- EXPLICAÇÃO DO PROBLEMA:
-- =====================================================
-- 
-- ❌ PROBLEMA ENCONTRADO:
-- Todos os vídeos foram salvos com uploaded_by, uploaded_by_email,
-- teacher_email e uploaded_by_name = NULL
--
-- Isso faz com que o frontend não consiga associar os vídeos a nenhum
-- professor, então eles ficam "órfãos" e não aparecem para ninguém.
--
-- ✅ SOLUÇÃO:
-- Associar os vídeos aos professores corretos preenchendo:
-- - uploaded_by (UUID do usuário)
-- - uploaded_by_email (email do professor)
-- - teacher_email (email do professor)
-- - uploaded_by_name (nome do professor)
--
-- =====================================================
-- PASSOS PARA CORRIGIR:
-- =====================================================
--
-- 1. Execute o PASSO 2 para ver os professores disponíveis
-- 2. Escolha qual professor deve "possuir" cada vídeo
-- 3. Use a OPÇÃO A (associar todos a um professor) ou
--    OPÇÃO B (associar cada vídeo individualmente)
-- 4. Descomente e execute o UPDATE escolhido
-- 5. Execute o PASSO 4 para verificar se funcionou
--
-- =====================================================
-- =====================================================
-- SOLUÇÃO PERMANENTE (PREVENIR FUTURAS OCORRÊNCIAS):
-- =====================================================

-- Tornar campos obrigatórios na aplicação (não no banco)
-- O código JavaScript deve sempre preencher:
-- - uploaded_by (pegar do auth.user().id)
-- - uploaded_by_email (pegar do auth.user().email)
-- - teacher_email (pegar do auth.user().email)
-- - uploaded_by_name (pegar do perfil ou email)

-- Caso queira tornar obrigatório no banco (cuidado, pode quebrar inserts):
-- ALTER TABLE videos ALTER COLUMN uploaded_by SET NOT NULL;
-- ALTER TABLE videos ALTER COLUMN teacher_email SET NOT NULL;
