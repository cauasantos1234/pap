// Script para limpar console.logs desnecessários
// Mantém apenas console.error para erros críticos

const fs = require('fs');
const path = require('path');

const arquivos = [
  'public/js/xp-system.js',
  'public/js/ranking-system.js',
  'public/js/videos.js'
];

function limparLogs(arquivo) {
  const caminhoCompleto = path.join(__dirname, arquivo);
  let conteudo = fs.readFileSync(caminhoCompleto, 'utf8');
  
  // Contar logs antes
  const logsBefore = (conteudo.match(/console\.(log|info|debug)/g) || []).length;
  
  // Remover console.log, console.info, console.debug
  // Manter console.error e console.warn
  conteudo = conteudo.replace(/\s*console\.(log|info|debug)\([^)]*\);?\n?/g, '');
  
  // Contar logs depois
  const logsAfter = (conteudo.match(/console\.(log|info|debug)/g) || []).length;
  
  fs.writeFileSync(caminhoCompleto, conteudo, 'utf8');
  
  console.log(`✅ ${arquivo}: ${logsBefore} logs removidos (${logsAfter} restantes)`);
}

console.log('🧹 Iniciando limpeza de console.logs...\n');

arquivos.forEach(arquivo => {
  try {
    limparLogs(arquivo);
  } catch (error) {
    console.error(`❌ Erro ao processar ${arquivo}:`, error.message);
  }
});

console.log('\n✅ Limpeza concluída!');
