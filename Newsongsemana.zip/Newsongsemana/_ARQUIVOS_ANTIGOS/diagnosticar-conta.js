// ========================================
// DIAGNÓSTICO: Por que a conta não aparece?
// Cole isto no Console (F12) do supabase-admin.html
// ========================================

async function diagnosticarConta() {
    console.log('🔍 DIAGNÓSTICO DE CONTA INVISÍVEL\n');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');
    
    // Perguntar qual email
    const email = prompt('📧 Digite o EMAIL da conta que não aparece:');
    if (!email) {
        console.log('❌ Cancelado');
        return;
    }
    
    console.log(`Procurando: ${email}\n`);
    
    // 1. Verificar localStorage
    console.log('1️⃣ Verificando localStorage (ns-users)...');
    const localUsers = JSON.parse(localStorage.getItem('ns-users') || '[]');
    const localUser = localUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
    
    if (localUser) {
        console.log('✅ ENCONTRADO no localStorage!');
        console.log('   Dados:', {
            name: localUser.name,
            email: localUser.email,
            role: localUser.role,
            password: localUser.password ? '(tem senha)' : '(sem senha)'
        });
    } else {
        console.log('❌ NÃO encontrado no localStorage');
    }
    console.log('');
    
    // 2. Verificar Supabase Auth
    console.log('2️⃣ Verificando Supabase Auth (auth.users)...');
    if (!window.supabase) {
        console.log('❌ Supabase não está carregado!');
        return;
    }
    
    try {
        const { data: authUsers, error: authError } = await window.supabase.rpc('get_all_auth_users');
        
        if (authError) {
            console.log('⚠️ Não foi possível verificar Auth (função não existe)');
            console.log('   Use o Supabase Dashboard → Authentication → Users');
        } else {
            const authUser = authUsers.find(u => u.email.toLowerCase() === email.toLowerCase());
            if (authUser) {
                console.log('✅ ENCONTRADO no Auth!');
                console.log('   Dados:', {
                    id: authUser.id,
                    email: authUser.email,
                    role: authUser.role,
                    criado_em: authUser.created_at,
                    ultimo_login: authUser.last_sign_in_at || 'Nunca logou'
                });
            } else {
                console.log('❌ NÃO encontrado no Supabase Auth');
            }
        }
    } catch (e) {
        console.log('⚠️ Erro ao verificar Auth:', e.message);
    }
    console.log('');
    
    // 3. Verificar tabela public.users
    console.log('3️⃣ Verificando tabela public.users...');
    try {
        const { data: dbUsers, error: dbError } = await window.supabase
            .from('users')
            .select('*')
            .eq('email', email);
        
        if (dbError) {
            console.log('❌ Erro ao buscar na tabela:', dbError.message);
        } else if (dbUsers && dbUsers.length > 0) {
            console.log('✅ ENCONTRADO na tabela users!');
            console.log('   Dados:', dbUsers[0]);
        } else {
            console.log('❌ NÃO encontrado na tabela users');
        }
    } catch (e) {
        console.log('❌ Erro:', e.message);
    }
    console.log('');
    
    // 4. Verificar sessão atual
    console.log('4️⃣ Verificando se está logado...');
    const session = localStorage.getItem('ns-session');
    if (session) {
        try {
            const sessionData = JSON.parse(session);
            if (sessionData.email.toLowerCase() === email.toLowerCase()) {
                console.log('✅ Esta conta ESTÁ LOGADA agora!');
                console.log('   Sessão:', sessionData);
            } else {
                console.log('ℹ️ Outra conta está logada:', sessionData.email);
            }
        } catch (e) {
            console.log('⚠️ Erro ao ler sessão');
        }
    } else {
        console.log('ℹ️ Nenhuma conta logada no momento');
    }
    console.log('');
    
    // 5. RESUMO E SOLUÇÕES
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('📊 RESUMO:\n');
    
    const emLocal = !!localUser;
    const emAuth = authUsers ? !!authUsers.find(u => u.email.toLowerCase() === email.toLowerCase()) : null;
    
    console.log(`localStorage: ${emLocal ? '✅' : '❌'}`);
    console.log(`Auth: ${emAuth === true ? '✅' : emAuth === false ? '❌' : '?'}`);
    console.log('');
    
    // Cenários
    if (emLocal && !emAuth) {
        console.log('🔍 DIAGNÓSTICO: Conta só existe localmente\n');
        console.log('❌ PROBLEMA: A conta foi criada no localStorage mas NÃO no Supabase\n');
        console.log('💡 SOLUÇÕES:\n');
        console.log('OPÇÃO 1 - Registrar no Supabase:');
        console.log('  1. Vá para register.html');
        console.log('  2. Use o MESMO email e senha');
        console.log('  3. Selecione o mesmo tipo de conta');
        console.log('  4. A conta será criada no Supabase\n');
        console.log('OPÇÃO 2 - Criar manualmente no Supabase:');
        console.log('  Execute no Console:');
        console.log(`  
  await window.supabase.auth.signUp({
    email: '${email}',
    password: 'sua_senha_aqui',
    options: {
      data: {
        name: '${localUser?.name || 'Nome'}',
        role: '${localUser?.role || 'student'}'
      }
    }
  });
        `);
    } else if (!emLocal && emAuth === true) {
        console.log('🔍 DIAGNÓSTICO: Conta existe no Supabase mas não localmente\n');
        console.log('💡 SOLUÇÃO: Faça LOGIN com esta conta para sincronizar localmente');
    } else if (!emLocal && emAuth === false) {
        console.log('🔍 DIAGNÓSTICO: Conta NÃO EXISTE em lugar nenhum!\n');
        console.log('❌ A conta não foi criada. Tente criar novamente.');
    } else if (emLocal && emAuth === true) {
        console.log('🔍 DIAGNÓSTICO: Conta existe EM AMBOS os lugares\n');
        console.log('✅ A conta DEVERIA aparecer no supabase-admin!\n');
        console.log('💡 SOLUÇÕES:\n');
        console.log('1. Clique em "🔄 Atualizar Lista" no supabase-admin');
        console.log('2. Recarregue a página (F5)');
        console.log('3. Verifique se há erro no Console vermelho');
    }
    
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
}

// Executar
diagnosticarConta();
