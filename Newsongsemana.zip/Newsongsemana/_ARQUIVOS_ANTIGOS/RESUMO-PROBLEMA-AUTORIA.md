# 🎯 RESUMO: Problema de Autoria de Vídeos

## 📋 Problema Relatado

**Situação**: Você postou um vídeo em uma conta de professor, mas quando visualiza os vídeos, aparece como se outra pessoa (outro professor) tivesse postado.

---

## 🔍 Análise Técnica

### Estrutura da Tabela `videos`

A tabela possui **múltiplas colunas** para identificar o autor:

```sql
videos (
  id SERIAL PRIMARY KEY,
  title VARCHAR(255),
  ...
  
  -- 📌 COLUNAS DE AUTORIA (problema está aqui!)
  uploaded_by UUID,           -- ID do usuário (auth.users)
  uploaded_by_name VARCHAR,   -- Nome do professor
  uploaded_by_email VARCHAR,  -- Email do professor
  teacher_email VARCHAR,      -- Email do professor (duplicado!)
  author_id UUID,             -- ID do autor (em alguns schemas)
  ...
)
```

### 🎯 Causas Possíveis

#### 1. **Vídeos Órfãos** (sem autor definido)
```sql
-- Vídeos onde todas as colunas de autor estão vazias
uploaded_by = NULL
uploaded_by_email = NULL  
teacher_email = NULL
uploaded_by_name = NULL
```
**Resultado**: O sistema pode atribuir um autor padrão ou mostrar "Anônimo"

#### 2. **Dados Inconsistentes**
```sql
-- Exemplo de inconsistência:
uploaded_by = 'uuid-do-professor-A'
teacher_email = 'professorB@newsong.com'  -- ❌ DIFERENTE!
uploaded_by_name = 'Professor C'          -- ❌ DIFERENTE!
```
**Resultado**: A interface pode mostrar informações de diferentes professores misturadas

#### 3. **Upload sem Autenticação Correta**
No código JavaScript, se o usuário não estiver corretamente autenticado no Supabase Auth, os campos de autoria ficam vazios.

#### 4. **Políticas RLS (Row Level Security)**
As políticas de segurança podem estar filtrando ou modificando os dados exibidos:

```sql
-- Esta política pode causar problema:
CREATE POLICY "Todos podem ver vídeos publicados"
  ON videos FOR SELECT
  USING (is_published = true);
```

Se você vê o vídeo mas com autor errado, não é problema de RLS. Se não vê o vídeo, pode ser RLS.

---

## 🔧 Solução Passo a Passo

### **PASSO 1: Diagnóstico Completo**

Execute no **Supabase SQL Editor**:

```sql
-- Arquivo: database/DIAGNOSTICO-VIDEOS-PROFESSORES.sql
```

Este script vai mostrar:
- ✅ Estrutura da tabela videos
- ✅ Todos os vídeos e suas associações
- ✅ Lista de professores cadastrados
- ✅ Vídeos órfãos (sem autor)
- ✅ Divergências de autoria
- ✅ Políticas RLS ativas

### **PASSO 2: Identificar o Professor Correto**

```sql
-- Ver todos os professores
SELECT id, email, name, role
FROM users
WHERE role IN ('teacher', 'professor')
ORDER BY created_at;
```

**Anote o email do professor que DEVERIA aparecer como autor**

### **PASSO 3: Corrigir os Vídeos**

**Opção A - Corrigir vídeos específicos:**

```sql
-- Primeiro, encontre os IDs dos vídeos com problema:
SELECT id, title, uploaded_by_email, uploaded_by_name
FROM videos
WHERE uploaded_by_email != 'seu-email@newsong.com'  -- Email esperado
ORDER BY created_at DESC;

-- Depois corrija (substitua 'professor-correto@newsong.com'):
UPDATE videos
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'professor-correto@newsong.com'),
  uploaded_by_email = 'professor-correto@newsong.com',
  teacher_email = 'professor-correto@newsong.com',
  uploaded_by_name = (SELECT name FROM users WHERE email = 'professor-correto@newsong.com')
WHERE id IN (1, 2, 3);  -- Coloque os IDs aqui
```

**Opção B - Corrigir TODOS os vídeos órfãos:**

```sql
UPDATE videos
SET 
  uploaded_by = (SELECT id FROM users WHERE email = 'professor-correto@newsong.com'),
  uploaded_by_email = 'professor-correto@newsong.com',
  teacher_email = 'professor-correto@newsong.com',
  uploaded_by_name = (SELECT name FROM users WHERE email = 'professor-correto@newsong.com')
WHERE 
  uploaded_by IS NULL 
  OR uploaded_by_email IS NULL
  OR uploaded_by_email = '';
```

**Use o arquivo pronto:**
```sql
-- database/CORRIGIR-AUTORIA-VIDEOS.sql
-- (Já tem várias opções prontas para você)
```

### **PASSO 4: Verificar o Resultado**

```sql
-- Ver vídeos corrigidos
SELECT 
  id,
  title,
  uploaded_by_email as professor,
  uploaded_by_name as nome,
  created_at
FROM videos
ORDER BY created_at DESC
LIMIT 10;

-- Contar vídeos por professor
SELECT 
  uploaded_by_email,
  uploaded_by_name,
  COUNT(*) as total
FROM videos
GROUP BY uploaded_by_email, uploaded_by_name
ORDER BY total DESC;
```

### **PASSO 5: Prevenir Problema Futuro**

#### No código JavaScript (arquivo onde faz upload):

**✅ CÓDIGO CORRETO:**
```javascript
// Sempre use a sessão do Supabase Auth
const { data: { session } } = await supabase.auth.getSession();

if (!session || !session.user) {
  alert('Você precisa estar autenticado para postar vídeos!');
  return;
}

const videoData = {
  title: 'Meu Vídeo',
  instrument: 'guitar',
  module: 'beginner',
  // ... outros campos
  
  // ✅ SEMPRE preencher estes campos:
  uploaded_by: session.user.id,
  uploaded_by_email: session.user.email,
  teacher_email: session.user.email,
  uploaded_by_name: session.user.user_metadata?.name || session.user.email.split('@')[0]
};

// Salvar no Supabase
const result = await supabase.from('videos').insert([videoData]);
```

**❌ CÓDIGO ERRADO (não faça assim):**
```javascript
const videoData = {
  title: 'Meu Vídeo',
  // ... campos
  uploaded_by: 'algum-id-hardcoded',  // ❌ ERRADO!
  uploaded_by_email: null,             // ❌ VAI FICAR ÓRFÃO!
};
```

---

## 📊 Verificação Rápida

Execute estas queries para verificar se está tudo OK:

```sql
-- 1. Vídeos órfãos (deve retornar 0)
SELECT COUNT(*) as orfaos
FROM videos
WHERE uploaded_by IS NULL OR uploaded_by_email IS NULL;

-- 2. Vídeos por professor
SELECT 
  uploaded_by_email as professor,
  COUNT(*) as videos
FROM videos
GROUP BY uploaded_by_email
ORDER BY videos DESC;

-- 3. Últimos 5 vídeos
SELECT 
  title, 
  uploaded_by_email, 
  uploaded_by_name,
  created_at
FROM videos
ORDER BY created_at DESC
LIMIT 5;
```

**Resultado esperado:**
- ✅ `orfaos = 0`
- ✅ Todos os vídeos com `uploaded_by_email` preenchido
- ✅ Autor correto nos últimos vídeos

---

## 🔍 Checklist de Solução

- [ ] **1. Executei o diagnóstico** (`DIAGNOSTICO-VIDEOS-PROFESSORES.sql`)
- [ ] **2. Identifiquei os vídeos com problema** (IDs anotados)
- [ ] **3. Verifiquei qual conta DEVERIA ser a autora**
- [ ] **4. Executei o UPDATE para corrigir** (usando `CORRIGIR-AUTORIA-VIDEOS.sql`)
- [ ] **5. Verifiquei que os vídeos agora aparecem corretos**
- [ ] **6. Testei fazer novo upload** (para garantir que não vai acontecer de novo)
- [ ] **7. Confirmei que o novo vídeo aparece com autor correto**

---

## 🚨 Atenção - Backup

**SEMPRE faça backup antes de executar UPDATE!**

```sql
-- Criar tabela de backup
CREATE TABLE videos_backup_20260128 AS 
SELECT * FROM videos;

-- Se der problema, restaurar:
-- DELETE FROM videos;
-- INSERT INTO videos SELECT * FROM videos_backup_20260128;
```

---

## 📞 Arquivos de Suporte

1. **`database/DIAGNOSTICO-VIDEOS-PROFESSORES.sql`**
   - Script completo de diagnóstico
   - Identifica todos os problemas

2. **`database/CORRIGIR-AUTORIA-VIDEOS.sql`**
   - Múltiplas opções de correção
   - Pronto para usar, só descomentar

3. **`PROBLEMA-AUTORIA-VIDEOS.md`**
   - Guia detalhado com explicações
   - Todas as causas e soluções

4. **`public/js/supabase-videos.js`** (linhas 16-60)
   - Código JavaScript que faz o upload
   - Já está correto, pegando dados do `session.user`

---

## 💡 Dica Final

Se após corrigir no banco os vídeos ainda aparecerem com autor errado no frontend:

1. **Limpe o cache do navegador** (Ctrl + Shift + Delete)
2. **Recarregue a página** (Ctrl + F5)
3. **Verifique se não tem dados em cache** no localStorage:
   ```javascript
   // No console do navegador (F12):
   localStorage.removeItem('ns-videos');
   window.location.reload();
   ```

---

## 📈 Próximos Passos

1. Execute o diagnóstico
2. Me mostre os resultados (quantos vídeos órfãos, etc.)
3. Confirme qual é o email do professor correto
4. Execute a correção apropriada
5. Teste fazer novo upload

**Qualquer dúvida, me avise! 🚀**
