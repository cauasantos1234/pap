# ⚡ SETUP RÁPIDO - SISTEMA DE NOTIFICAÇÕES

## 🚀 3 Passos para Ativar

### PASSO 1: Banco de Dados (2 minutos)

1. Acesse: https://supabase.com/dashboard
2. Abra seu projeto
3. Vá em **SQL Editor**
4. Clique em **New Query**
5. Cole o conteúdo de: `database/16-notifications-system.sql`
6. Clique em **RUN** (Ctrl+Enter)

✅ **Pronto!** Tabela `notifications` criada com todos os triggers.

---

### PASSO 2: Verificar Scripts (30 segundos)

Confira se estes scripts estão carregados em suas páginas principais:

#### app.html
```html
<script src="js/notifications.js"></script>
<script src="js/notification-bell.js"></script>
```

#### profile.html
```html
<script src="js/notifications.js"></script>
<script src="js/notification-bell.js"></script>
```

#### feedbacks.html
```html
<script src="js/notifications.js"></script>
<script src="js/notification-bell.js"></script>
```

✅ **Pronto!** Scripts já estão incluídos.

---

### PASSO 3: Testar (1 minuto)

1. Faça login no sistema
2. Veja o **sininho dourado** no canto superior direito
3. Clique nele para ver o dropdown

#### Criar Notificação de Teste

Abra o Console (F12) e cole:

```javascript
// Criar notificação de teste
await window.NotificationsAPI.createNotification({
  userEmail: 'seu-email@newsong.com', // SEU EMAIL AQUI
  type: 'new_video',
  title: '🎥 Teste de Notificação',
  message: 'Sistema funcionando perfeitamente!',
  link: 'app.html'
});

// Atualizar badge
await window.NotificationBell.updateBadge();
```

Você verá:
- Badge vermelho com número (1)
- Notificação no dropdown ao clicar

---

## 🎯 Testar Fluxos Completos

### Teste 1: Aluno Avalia Professor

1. Faça login como **aluno**
2. Acesse uma aula
3. Dê uma avaliação (1-5 estrelas)
4. Faça logout

5. Faça login como **professor**
6. Veja o sininho com badge (1)
7. Clique para ver: "⭐ Nova Avaliação Recebida"
8. Vá em Menu → **Feedbacks**
9. Veja a avaliação e responda

---

### Teste 2: Professor Responde Feedback

1. Como **professor**, vá em **Feedbacks**
2. Clique em "Responder" em uma avaliação
3. Digite um feedback
4. Clique em "Enviar Resposta"

5. Faça logout e login como **aluno**
6. Veja sininho com badge (1)
7. Clique para ver: "💬 Feedback do Professor"

---

### Teste 3: Novo Vídeo

1. Como **professor**, vá em **Enviar Vídeo**
2. Faça upload de um novo vídeo
3. Submeta

4. Faça logout e login como **aluno**
5. Veja sininho com badge (1)
6. Clique para ver: "🎥 Novo Vídeo Disponível"

---

## 🔧 Verificação de Funcionamento

### Console do Navegador (F12)

```javascript
// Verificar se módulos carregaram
console.log('NotificationsAPI:', window.NotificationsAPI);
console.log('NotificationBell:', window.NotificationBell);

// Ver notificações
const session = JSON.parse(localStorage.getItem('ns-session'));
const result = await window.NotificationsAPI.getAllNotifications(session.email, 10);
console.log('Minhas notificações:', result);

// Contar não lidas
const count = await window.NotificationsAPI.countUnread(session.email);
console.log('Não lidas:', count.count);
```

---

## 📊 Verificar no Banco de Dados

```sql
-- Ver todas notificações
SELECT * FROM notifications ORDER BY created_at DESC LIMIT 10;

-- Contar por tipo
SELECT type, COUNT(*) as total 
FROM notifications 
GROUP BY type;

-- Ver não lidas de um usuário
SELECT * FROM notifications 
WHERE user_email = 'aluno@newsong.com' AND is_read = FALSE;
```

---

## 🎨 Personalizações Rápidas

### Mudar Cor do Sininho

Edite `public/js/notification-bell.js` (linha ~78):

```css
background: linear-gradient(135deg, #d4af37, #f4d03f);
/* Troque para suas cores */
```

### Mudar Intervalo de Atualização

Edite `public/js/notification-bell.js` (linha ~531):

```javascript
updateInterval = setInterval(updateBadge, 30000); // 30s
/* Troque 30000 para o valor em milissegundos que desejar */
```

---

## ✅ Checklist Final

- [ ] SQL executado no Supabase
- [ ] Scripts carregados nas páginas
- [ ] Sininho aparece no canto direito
- [ ] Badge funciona ao criar notificação
- [ ] Dropdown abre ao clicar
- [ ] Menu "Feedbacks" aparece para professores
- [ ] Página feedbacks.html abre e carrega dados
- [ ] Professores podem responder avaliações
- [ ] Triggers funcionam automaticamente

---

## 🆘 Problemas Comuns

### Sininho não aparece

**Solução:** Limpe o cache (Ctrl+Shift+R) e recarregue

### Badge não atualiza

**Solução:** Abra o console e execute:
```javascript
await window.NotificationBell.updateBadge();
```

### "Erro ao conectar com banco de dados"

**Solução:** Verifique se o SQL foi executado:
```sql
SELECT COUNT(*) FROM notifications;
```
Se der erro, execute o arquivo SQL novamente.

### Menu "Feedbacks" não aparece

**Solução:** Verifique se seu usuário é professor:
```javascript
const session = JSON.parse(localStorage.getItem('ns-session'));
console.log('Role:', session.role); // Deve ser 'teacher'
```

---

## 📞 Suporte

Se algo não funcionar:

1. Abra o Console (F12)
2. Veja se há erros em vermelho
3. Cole no console:
```javascript
console.log('Sessão:', localStorage.getItem('ns-session'));
console.log('Supabase:', window.SupabaseAPI.getClient());
console.log('NotificationsAPI:', window.NotificationsAPI);
```
4. Verifique a saída

---

## 🎉 Tudo Pronto!

Seu sistema de notificações está **100% funcional!**

- ✅ Sininho com badge animado
- ✅ Notificações em tempo real
- ✅ Página de feedbacks completa
- ✅ Menu para professores
- ✅ Design responsivo

**Aproveite!** 🚀🔔
