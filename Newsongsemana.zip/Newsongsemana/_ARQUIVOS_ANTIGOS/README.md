# Arquivos Antigos - NewSong

Esta pasta contém arquivos antigos de debug, diagnóstico e correções que já foram resolvidas.

## Conteúdo

### Scripts de Debug (Raiz)
- `debug-users.js` - Script de debug de usuários
- `diagnosticar-conta.js` - Diagnóstico de contas
- `limpar-cache-local.js` - Limpeza de cache local
- `verificar-setup.js` - Verificação de setup
- `EXEMPLOS_NOTIFICACOES.js` - Exemplos de notificações para testes

### Documentos de Problemas Resolvidos
- Correções de erros gerais
- Diagnósticos de login
- Problemas de role e autenticação
- Soluções de progresso e ranking
- Correções de RLS (Row Level Security)

### Scripts SQL de Diagnóstico (database/)
- Diagnósticos de XP e ranking
- Correções de schema
- Limpezas de dados órfãos
- Verificações diversas
- Correções de autoria de vídeos

## Nota
Estes arquivos foram movidos em **28/01/2026** durante limpeza do projeto.
Mantidos para referência histórica caso seja necessário consultar soluções antigas.
