# 🔍 Diagnóstico: Notificações Não Aparecem

## Problema Relatado
- ✅ Aluno fez ações que deveriam notificar professor
- ❌ Professor não recebeu notificações

## Possíveis Causas

### 1. **Triggers não estão criados no banco**
O arquivo [18-sistema-notificacoes-completo.sql](database/18-sistema-notificacoes-completo.sql) precisa ser executado no Supabase.

### 2. **Notificações foram criadas mas não aparecem**
Problema com o sininho ou API de notificações.

### 3. **User_id ou email não correspondem**
As notificações usam `user_email` mas podem estar com email errado.

### 4. **RLS (Row Level Security) bloqueando**
Políticas podem estar impedindo o professor de ver as notificações.

## Como Diagnosticar

### Passo 1: Verificar no Console do Navegador

**Como Professor**, abra o console (F12) e execute:

```javascript
// Cole o conteúdo do arquivo testar-notificacoes.js aqui
// Ou apenas execute:
const session = JSON.parse(localStorage.getItem('ns-session'));
console.log('Email:', session.email);
console.log('Role:', session.role);

// Buscar notificações
window.NotificationsAPI.getAllNotifications(session.email, 20).then(result => {
  console.log('Resultado:', result);
});
```

### Passo 2: Verificar no Supabase

1. Vá em **SQL Editor** no Supabase
2. Execute as queries do arquivo [VERIFICAR-NOTIFICACOES.sql](database/VERIFICAR-NOTIFICACOES.sql)
3. Veja se:
   - Existem notificações na tabela
   - Os triggers estão criados
   - O email do professor está correto

### Passo 3: Verificar Triggers

Execute no SQL Editor do Supabase:

```sql
-- Ver se os triggers de notificação existem
SELECT trigger_name, event_object_table
FROM information_schema.triggers
WHERE trigger_name LIKE '%notify%';
```

**Resultado esperado:**
- `trigger_notify_teacher_on_video_like`
- `trigger_notify_teacher_on_new_follower`
- `trigger_notify_teacher_on_video_comment`
- `trigger_notify_followers_on_new_video`
- `trigger_notify_user_on_comment_like`

## Soluções Rápidas

### Se os triggers NÃO existem:

```bash
# Execute no Supabase SQL Editor:
# O arquivo completo:
database/18-sistema-notificacoes-completo.sql
```

### Se as notificações existem mas não aparecem:

**Console do navegador (F12):**
```javascript
// Forçar atualização do badge
window.NotificationBell.updateBadge();

// Recarregar notificações
window.NotificationBell.loadNotifications();
```

### Se o email está errado:

Execute no Supabase:
```sql
-- Ver todos os emails na tabela notifications
SELECT DISTINCT user_email FROM notifications;

-- Ver emails de usuários
SELECT email, name, role FROM users;

-- Atualizar notificações com email errado (CUIDADO!)
UPDATE notifications 
SET user_email = 'email-correto@exemplo.com'
WHERE user_email = 'email-errado@exemplo.com';
```

## Teste Manual

### Criar notificação de teste:

**No Supabase SQL Editor:**
```sql
INSERT INTO notifications (
  user_email,
  type,
  title,
  message,
  link,
  metadata
) VALUES (
  'SEU-EMAIL-DE-PROFESSOR@exemplo.com',  -- ⚠️ SUBSTITUA!
  'video_comment',
  '💬 Teste Manual',
  'Esta é uma notificação de teste',
  'videos.html',
  '{"test": true}'::jsonb
);
```

Depois, recarregue a página e veja se aparece no sininho.

## Debug Avançado

### Ver logs do sistema:

**Console do navegador:**
```javascript
// Habilitar logs detalhados
localStorage.setItem('debug', 'true');

// Ver estado atual
console.log('NotificationBell:', window.NotificationBell);
console.log('NotificationsAPI:', window.NotificationsAPI);
```

### Verificar subscription em tempo real:

```javascript
// Ver se está inscrito
const session = JSON.parse(localStorage.getItem('ns-session'));
const supabase = window.SupabaseAPI.getClient();

supabase
  .from('notifications')
  .select('*')
  .eq('user_email', session.email)
  .then(({data, error}) => {
    if (error) console.error('Erro:', error);
    else console.log('Notificações:', data);
  });
```

## Checklist de Verificação

- [ ] Arquivo `18-sistema-notificacoes-completo.sql` foi executado no Supabase?
- [ ] Triggers estão criados? (verificar com SQL)
- [ ] Notificações aparecem na tabela? (verificar com SQL)
- [ ] Email do professor está correto nas notificações?
- [ ] RLS permite o professor ver suas notificações?
- [ ] NotificationsAPI está carregado? (console: `window.NotificationsAPI`)
- [ ] Sininho aparece na página? (`#notificationBell`)
- [ ] Badge está sendo atualizado? (verificar no console)

## Scripts Úteis

### Arquivo de teste para console:
- [testar-notificacoes.js](testar-notificacoes.js) - Copie e cole no console

### SQL de verificação:
- [VERIFICAR-NOTIFICACOES.sql](database/VERIFICAR-NOTIFICACOES.sql) - Execute no Supabase

---

**Próximos Passos:**
1. Execute o script de teste no console como professor
2. Execute as queries SQL no Supabase
3. Me envie os resultados para análise
