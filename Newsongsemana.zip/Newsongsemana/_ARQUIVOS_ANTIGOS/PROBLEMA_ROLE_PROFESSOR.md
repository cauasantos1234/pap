# 🔧 PROBLEMA: Conta de Professor Aparece como Aluno

## 🎯 O QUE ESTÁ ACONTECENDO

Você criou uma conta que deveria ser de **Professor** mas está aparecendo como **Aluno** no sistema.

## 🔍 CAUSA RAIZ

Existem 3 lugares onde o problema pode estar:

### 1. **criar-conta-rapido.html (CORRIGIDO ✅)**
**Antes:** Só salvava no localStorage, sem enviar para o Supabase  
**Depois:** Agora envia para o Supabase com o `role` correto

### 2. **supabase-auth.js**
Quando não recebe o `role`, usa `'student'` como padrão:
```javascript
role: userData.role || 'student'  // ⚠️ Padrão = student
```

### 3. **Banco de Dados**
A conta já foi criada com `role = 'student'` e precisa ser atualizada

---

## ✅ SOLUÇÕES

### **SOLUÇÃO 1: Corrigir Conta Existente no Banco** (Mais Rápido)

1. Abra [Supabase Dashboard](https://supabase.com/dashboard) → SQL Editor
2. Execute o arquivo: `database/FIX-USER-ROLE.sql`
3. Modifique o email na linha 15:
```sql
UPDATE public.users
SET role = 'teacher'
WHERE email = 'SEU_EMAIL_AQUI';  -- ✏️ COLOQUE SEU EMAIL AQUI
```
4. Clique em **Run**
5. Pronto! A conta agora é de professor

---

### **SOLUÇÃO 2: Criar Nova Conta Corretamente**

Agora que o código foi corrigido, você pode:

1. **Deletar a conta antiga:**
   - Vá em [Supabase Dashboard](https://supabase.com/dashboard)
   - **Authentication** → **Users**
   - Encontre seu email e clique no **lixeira** 🗑️
   - OU execute no SQL:
   ```sql
   DELETE FROM public.users WHERE email = 'seu_email@gmail.com';
   DELETE FROM auth.users WHERE email = 'seu_email@gmail.com';
   ```

2. **Criar nova conta:**
   - Abra `criar-conta-rapido.html`
   - Clique no botão **"👨‍🏫 Professor"**
   - OU use o formulário personalizado e selecione **"Professor"**

---

### **SOLUÇÃO 3: Atualizar via Admin Panel**

1. Abra `supabase-admin.html`
2. No Console do navegador (F12), execute:
```javascript
// Atualizar role de um usuário específico
async function updateUserRole(email, newRole) {
    const { data, error } = await window.supabase
        .from('users')
        .update({ role: newRole })
        .eq('email', email)
        .select();
    
    if (error) {
        console.error('❌ Erro:', error);
    } else {
        console.log('✅ Role atualizado!', data);
    }
}

// Usar assim:
updateUserRole('seu_email@gmail.com', 'teacher');
```

---

## 🔍 COMO VERIFICAR SE ESTÁ CORRETO

### No supabase-admin.html:
1. Abra `supabase-admin.html`
2. Clique em "🔄 Atualizar Lista"
3. Procure seu email na tabela
4. A coluna **"Tipo"** deve mostrar: **teacher** ✅

### No Console (F12):
```javascript
// Ver dados de um usuário
const users = JSON.parse(localStorage.getItem('ns-users') || '[]');
const meuUser = users.find(u => u.email === 'seu_email@gmail.com');
console.log('Role:', meuUser.role);
// Deve mostrar: "teacher"
```

### No Supabase Dashboard:
1. **Table Editor** → **users**
2. Encontre seu email
3. Coluna **role** deve ser: **teacher**

---

## 📊 DIFERENÇAS: Professor vs Aluno

| Recurso | Aluno (student) | Professor (teacher) |
|---------|-----------------|---------------------|
| Ver aulas | ✅ Sim | ✅ Sim |
| Upload de vídeos | ❌ Não | ✅ Sim |
| Editar vídeos | ❌ Não | ✅ Sim |
| Deletar vídeos | ❌ Não | ✅ Sim |
| Avaliar professores | ✅ Sim | ❌ Não |
| Ver botão "Upload" | ❌ Oculto | ✅ Visível |

---

## 🛠️ CÓDIGO CORRIGIDO

### No `criar-conta-rapido.html`:
Agora a função `criarConta()` faz:
1. ✅ Salva no localStorage com role correto
2. ✅ Cria conta no Supabase Auth com metadata `role`
3. ✅ Insere na tabela `public.users` com role correto
4. ✅ Mostra logs no console para debug

### Teste se Está Funcionando:
1. Abra `criar-conta-rapido.html`
2. Abra o Console (F12)
3. Crie uma conta de professor
4. Você deve ver:
```
📝 Criando usuário: { name: "...", email: "...", role: "teacher" }
🔄 Registrando no Supabase também...
✅ Usuário criado no Supabase!
📊 Role configurado: teacher
✅ Usuário inserido na tabela users com role: teacher
```

---

## 🎯 RESUMO RÁPIDO

**Para corrigir SUA conta existente:**
```sql
-- Execute no Supabase SQL Editor:
UPDATE public.users SET role = 'teacher' WHERE email = 'SEU_EMAIL';
UPDATE auth.users SET raw_user_meta_data = jsonb_set(
  COALESCE(raw_user_meta_data, '{}'::jsonb),
  '{role}', '"teacher"'
) WHERE email = 'SEU_EMAIL';
```

**Para criar novas contas corretamente:**
- Use `criar-conta-rapido.html` (já corrigido ✅)
- OU use `register.html` e selecione "Professor"

**Para verificar:**
- Abra `supabase-admin.html`
- Procure seu email
- Coluna "Tipo" deve mostrar **teacher**

---

## 🆘 AINDA NÃO FUNCIONA?

Execute no Console (F12) e me mostre o resultado:
```javascript
// Diagnóstico completo
const users = JSON.parse(localStorage.getItem('ns-users') || '[]');
console.log('📊 DIAGNÓSTICO:');
console.log('1. localStorage users:', users);
console.log('2. Meu email:', 'coloque_seu_email_aqui');
console.log('3. Minha conta:', users.find(u => u.email === 'coloque_seu_email_aqui'));

// Ver no Supabase
window.supabase.from('users')
    .select('*')
    .eq('email', 'coloque_seu_email_aqui')
    .then(({ data }) => console.log('4. Supabase:', data));
```

---

**Agora as contas de professor serão criadas corretamente!** 🎉
