-- ============================================
-- NEWSONG PLATFORM - DELETAR VÍDEOS SEM THUMBNAIL
-- Remove apenas os vídeos de placeholder (sem thumbnail real)
-- Data: 03/02/2026
-- ============================================

-- ⚠️ ATENÇÃO: Este script irá deletar apenas vídeos SEM thumbnail
-- Os vídeos com thumbnail real serão mantidos

BEGIN;

-- 1. Identificar os vídeos sem thumbnail real (sem base64)
SELECT 
    id,
    title,
    thumbnail_url,
    created_at
FROM videos
WHERE thumbnail_url IS NULL 
   OR thumbnail_url = ''
   OR thumbnail_url NOT LIKE 'data:image/%'
ORDER BY created_at DESC;

-- 2. Armazenar os IDs dos vídeos a serem deletados
CREATE TEMP TABLE videos_to_delete AS
SELECT id FROM videos
WHERE thumbnail_url IS NULL 
   OR thumbnail_url = ''
   OR thumbnail_url NOT LIKE 'data:image/%';

-- 3. Deletar dados relacionados aos vídeos sem thumbnail
DELETE FROM video_views 
WHERE video_id IN (SELECT id FROM videos_to_delete);

DELETE FROM saved_videos 
WHERE video_id IN (SELECT id FROM videos_to_delete);

DELETE FROM comments 
WHERE video_id IN (SELECT id FROM videos_to_delete);

DELETE FROM user_progress 
WHERE video_id IN (SELECT id FROM videos_to_delete);

DELETE FROM video_likes 
WHERE video_id IN (SELECT id FROM videos_to_delete);

-- 4. Deletar os vídeos sem thumbnail
DELETE FROM videos 
WHERE id IN (SELECT id FROM videos_to_delete);

COMMIT;

-- ============================================
-- VERIFICAÇÃO FINAL
-- ============================================
SELECT 'Vídeos restantes (com thumbnail):' as status, COUNT(*) as total 
FROM videos;

SELECT 'Últimos vídeos no banco:' as status;
SELECT 
    id,
    title,
    thumbnail_url,
    views,
    created_at
FROM videos
ORDER BY created_at DESC
LIMIT 10;

-- ============================================
-- RESULTADO ESPERADO
-- ============================================
-- Apenas vídeos com thumbnail real devem permanecer
-- Ex: "modos gregos" e outros vídeos reais
