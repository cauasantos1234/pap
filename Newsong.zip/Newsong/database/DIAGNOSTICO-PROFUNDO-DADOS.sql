-- ============================================================================
-- DIAGNÓSTICO PROFUNDO: Análise Completa dos Dados
-- ============================================================================

-- 📊 SEÇÃO 1: ESTRUTURA COMPLETA users_stats
-- ============================================================================
SELECT '=== ESTRUTURA COMPLETA: users_stats ===' as info;

SELECT 
    column_name as "Coluna",
    data_type as "Tipo",
    is_nullable as "NULL?",
    column_default as "Padrão"
FROM information_schema.columns
WHERE table_name = 'users_stats'
ORDER BY ordinal_position;

-- ============================================================================
-- 📊 SEÇÃO 2: ESTRUTURA COMPLETA user_xp
-- ============================================================================
SELECT '=== ESTRUTURA COMPLETA: user_xp ===' as info;

SELECT 
    column_name as "Coluna",
    data_type as "Tipo",
    is_nullable as "NULL?",
    column_default as "Padrão"
FROM information_schema.columns
WHERE table_name = 'user_xp'
ORDER BY ordinal_position;

-- ============================================================================
-- 📈 SEÇÃO 3: ESTATÍSTICAS DETALHADAS video_progress
-- ============================================================================
SELECT '=== ESTATÍSTICAS DETALHADAS: video_progress ===' as info;

SELECT 
    COUNT(*) as "Total Registros",
    COUNT(DISTINCT user_id) as "Usuários Únicos",
    COUNT(DISTINCT video_id) as "Vídeos Únicos",
    COUNT(DISTINCT lesson_id) as "Lições Únicas",
    COUNT(CASE WHEN completed = true THEN 1 END) as "Vídeos Completos",
    COUNT(CASE WHEN completed = false THEN 1 END) as "Vídeos Incompletos",
    ROUND(AVG(progress_percentage), 2) as "Progresso Médio %",
    ROUND(AVG(watch_count), 2) as "Média Visualizações",
    MIN(created_at) as "Primeiro Registro",
    MAX(updated_at) as "Última Atualização"
FROM video_progress;

-- ============================================================================
-- 📈 SEÇÃO 4: ANÁLISE completed_lessons (ARRAY)
-- ============================================================================
SELECT '=== ANÁLISE: Campo completed_lessons[] ===' as info;

SELECT 
    user_id,
    COUNT(*) as "Linhas do Usuário",
    COUNT(DISTINCT completed_lessons::text) as "Arrays Diferentes",
    CASE 
        WHEN COUNT(DISTINCT completed_lessons::text) = 1 THEN '✅ Consistente'
        ELSE '❌ INCONSISTENTE (arrays diferentes!)'
    END as "Status",
    MAX(array_length(completed_lessons, 1)) as "Tamanho Máximo Array"
FROM video_progress
WHERE completed_lessons IS NOT NULL
GROUP BY user_id
ORDER BY COUNT(*) DESC
LIMIT 10;

-- ============================================================================
-- 📈 SEÇÃO 5: ANÁLISE instrument_progress (JSONB)
-- ============================================================================
SELECT '=== ANÁLISE: Campo instrument_progress ===' as info;

SELECT 
    user_id,
    COUNT(*) as "Linhas do Usuário",
    COUNT(DISTINCT instrument_progress::text) as "JSONs Diferentes",
    CASE 
        WHEN COUNT(DISTINCT instrument_progress::text) = 1 THEN '✅ Consistente'
        ELSE '❌ INCONSISTENTE (jsons diferentes!)'
    END as "Status"
FROM video_progress
WHERE instrument_progress IS NOT NULL AND instrument_progress::text != '{}'
GROUP BY user_id
ORDER BY COUNT(*) DESC
LIMIT 10;

-- ============================================================================
-- 📈 SEÇÃO 6: ESTATÍSTICAS users_stats
-- ============================================================================
SELECT '=== ESTATÍSTICAS: users_stats ===' as info;

SELECT 
    COUNT(*) as "Total Registros",
    COUNT(DISTINCT user_id) as "Usuários Únicos",
    MIN(total_xp) as "XP Mínimo",
    MAX(total_xp) as "XP Máximo",
    ROUND(AVG(total_xp), 2) as "XP Médio",
    MIN(level) as "Level Mínimo",
    MAX(level) as "Level Máximo",
    ROUND(AVG(level), 2) as "Level Médio",
    MAX(streak_days) as "Maior Streak",
    ROUND(AVG(streak_days), 2) as "Streak Médio",
    SUM(total_study_time_minutes) as "Total Minutos Estudo"
FROM users_stats;

-- ============================================================================
-- 📈 SEÇÃO 7: COMPARAÇÃO - Usuários em cada tabela
-- ============================================================================
SELECT '=== COMPARAÇÃO: Usuários por Tabela ===' as info;

SELECT 
    (SELECT COUNT(DISTINCT id) FROM users) as "Total Usuários (users)",
    (SELECT COUNT(DISTINCT user_id) FROM video_progress) as "Com video_progress",
    (SELECT COUNT(DISTINCT user_id) FROM users_stats) as "Com users_stats",
    (SELECT COUNT(DISTINCT user_id) FROM user_xp) as "Com user_xp";

-- ============================================================================
-- 👥 SEÇÃO 8: TOP 10 Usuários Mais Ativos
-- ============================================================================
SELECT '=== TOP 10: Usuários Mais Ativos ===' as info;

SELECT 
    u.email as "Email",
    u.role as "Função",
    COUNT(vp.id) as "Vídeos Assistidos",
    COUNT(CASE WHEN vp.completed THEN 1 END) as "Vídeos Completos",
    COALESCE(us.total_xp, 0) as "XP",
    COALESCE(us.level, 1) as "Level",
    COALESCE(us.streak_days, 0) as "Streak",
    MAX(vp.updated_at) as "Última Atividade"
FROM users u
LEFT JOIN video_progress vp ON vp.user_id = u.id
LEFT JOIN users_stats us ON us.user_id = u.id
GROUP BY u.id, u.email, u.role, us.total_xp, us.level, us.streak_days
ORDER BY COUNT(vp.id) DESC
LIMIT 10;

-- ============================================================================
-- ❌ SEÇÃO 9: VERIFICAR REGISTROS ÓRFÃOS
-- ============================================================================
SELECT '=== ÓRFÃOS: video_progress ===' as info;

SELECT 
    COUNT(*) as "Total",
    COUNT(CASE WHEN u.id IS NOT NULL THEN 1 END) as "✅ User Válido",
    COUNT(CASE WHEN u.id IS NULL THEN 1 END) as "❌ User Inválido",
    COUNT(CASE WHEN v.id IS NOT NULL THEN 1 END) as "✅ Vídeo Válido",
    COUNT(CASE WHEN v.id IS NULL AND vp.video_id IS NOT NULL THEN 1 END) as "❌ Vídeo Inválido"
FROM video_progress vp
LEFT JOIN users u ON vp.user_id = u.id
LEFT JOIN videos v ON vp.video_id = v.id;

-- ============================================================================
SELECT '=== ÓRFÃOS: users_stats ===' as info;

SELECT 
    COUNT(*) as "Total",
    COUNT(CASE WHEN u.id IS NOT NULL THEN 1 END) as "✅ User Válido",
    COUNT(CASE WHEN u.id IS NULL THEN 1 END) as "❌ User Inválido"
FROM users_stats us
LEFT JOIN users u ON us.user_id = u.id;

-- ============================================================================
-- 🔍 SEÇÃO 10: USUÁRIOS SEM STATS
-- ============================================================================
SELECT '=== USUÁRIOS SEM STATS ===' as info;

SELECT 
    COUNT(*) as "Total Usuários Sem Stats"
FROM users u
LEFT JOIN users_stats us ON us.user_id = u.id
WHERE us.id IS NULL;

-- Detalhes
SELECT 
    u.id,
    u.email,
    u.role,
    u.created_at as "Cadastro",
    COUNT(vp.id) as "Vídeos Assistidos"
FROM users u
LEFT JOIN users_stats us ON us.user_id = u.id
LEFT JOIN video_progress vp ON vp.user_id = u.id
WHERE us.id IS NULL
GROUP BY u.id, u.email, u.role, u.created_at
ORDER BY u.created_at DESC
LIMIT 10;

-- ============================================================================
-- 📊 SEÇÃO 11: AMOSTRA REAL - video_progress com dados duplicados
-- ============================================================================
SELECT '=== AMOSTRA: Dados Duplicados em video_progress ===' as info;

-- Pegar um usuário com múltiplos registros
SELECT 
    vp.user_id,
    u.email,
    COUNT(*) as "Total Linhas"
FROM video_progress vp
LEFT JOIN users u ON vp.user_id = u.id
GROUP BY vp.user_id, u.email
HAVING COUNT(*) > 3
ORDER BY COUNT(*) DESC
LIMIT 1;

-- Mostrar as linhas desse usuário
WITH top_user AS (
    SELECT user_id
    FROM video_progress
    GROUP BY user_id
    HAVING COUNT(*) > 3
    ORDER BY COUNT(*) DESC
    LIMIT 1
)
SELECT 
    vp.id,
    v."Titulo" as "Vídeo",
    vp.completed as "Completo",
    vp.progress_percentage as "%",
    array_length(vp.completed_lessons, 1) as "Tamanho Array",
    jsonb_pretty(vp.instrument_progress) as "JSON Progress",
    vp.instrument as "Instrumento",
    vp.module as "Módulo"
FROM video_progress vp
LEFT JOIN videos v ON vp.video_id = v.id
WHERE vp.user_id = (SELECT user_id FROM top_user)
ORDER BY vp.created_at
LIMIT 5;

-- ============================================================================
-- 📊 SEÇÃO 12: VERIFICAR DUPLICAÇÃO REAL
-- ============================================================================
SELECT '=== VERIFICAR: Quantos usuários têm dados duplicados ===' as info;

SELECT 
    COUNT(*) as "Usuários com Múltiplas Linhas",
    SUM(total_linhas) as "Total de Linhas",
    ROUND(AVG(total_linhas), 2) as "Média Linhas/Usuário",
    MAX(total_linhas) as "Máximo Linhas"
FROM (
    SELECT user_id, COUNT(*) as total_linhas
    FROM video_progress
    GROUP BY user_id
    HAVING COUNT(*) > 1
) subquery;

-- ============================================================================
-- 🔐 SEÇÃO 13: VERIFICAR POLÍTICAS RLS
-- ============================================================================
SELECT '=== POLÍTICAS RLS: video_progress ===' as info;

SELECT 
    policyname as "Política",
    cmd as "Comando",
    roles as "Funções",
    permissive as "Permissiva"
FROM pg_policies
WHERE tablename = 'video_progress';

-- ============================================================================
SELECT '=== POLÍTICAS RLS: users_stats ===' as info;

SELECT 
    policyname as "Política",
    cmd as "Comando",
    roles as "Funções",
    permissive as "Permissiva"
FROM pg_policies
WHERE tablename = 'users_stats';

-- ============================================================================
-- 📋 SEÇÃO 14: ÍNDICES
-- ============================================================================
SELECT '=== ÍNDICES: video_progress ===' as info;

SELECT
    indexname as "Índice",
    indexdef as "Definição"
FROM pg_indexes
WHERE tablename = 'video_progress';

-- ============================================================================
SELECT '=== ÍNDICES: users_stats ===' as info;

SELECT
    indexname as "Índice",
    indexdef as "Definição"
FROM pg_indexes
WHERE tablename = 'users_stats';

-- ============================================================================
-- ✅ SEÇÃO 15: RECOMENDAÇÕES FINAIS
-- ============================================================================
SELECT '=== ANÁLISE FINAL E RECOMENDAÇÕES ===' as info;

-- Check 1: Duplicação
SELECT 
    CASE 
        WHEN (
            SELECT COUNT(*)
            FROM (
                SELECT user_id, COUNT(*) as cnt
                FROM video_progress
                GROUP BY user_id
                HAVING COUNT(*) > 1
            ) sub
        ) > 0 THEN '❌ PROBLEMA: Dados duplicados em video_progress'
        ELSE '✅ OK: Sem duplicação'
    END as "Check 1: Duplicação";

-- Check 2: Órfãos
SELECT 
    CASE 
        WHEN EXISTS (
            SELECT 1 FROM video_progress vp
            LEFT JOIN users u ON vp.user_id = u.id
            WHERE u.id IS NULL
        ) THEN '❌ PROBLEMA: Registros órfãos (usuários inválidos)'
        ELSE '✅ OK: Sem órfãos'
    END as "Check 2: Órfãos";

-- Check 3: Usuários sem stats
SELECT 
    CASE 
        WHEN (
            SELECT COUNT(*)
            FROM users u
            LEFT JOIN users_stats us ON us.user_id = u.id
            WHERE us.id IS NULL AND u.role = 'student'
        ) > 0 THEN '⚠️ AVISO: Alunos sem registro em users_stats'
        ELSE '✅ OK: Todos os alunos têm stats'
    END as "Check 3: Users Stats";

-- Check 4: Arrays vazios
SELECT 
    CASE 
        WHEN (
            SELECT COUNT(*)
            FROM video_progress
            WHERE completed_lessons = '{}'::integer[] OR completed_lessons IS NULL
        ) > (SELECT COUNT(*) * 0.5 FROM video_progress)
        THEN '⚠️ AVISO: Muitos completed_lessons vazios'
        ELSE '✅ OK: Arrays populados'
    END as "Check 4: Arrays";

-- ============================================================================
SELECT '=== FIM DO DIAGNÓSTICO PROFUNDO ===' as resultado;
-- ============================================================================
