-- ============================================================================
-- LIMPEZA: REMOVER DUPLICAÇÕES DAS TABELAS
-- ============================================================================
-- IMPORTANTE: Este script vai remover colunas e pode afetar o código existente
-- Faça backup antes de executar!
-- ============================================================================

-- 📊 PASSO 1: VERIFICAR DADOS ANTES DA LIMPEZA
-- ============================================================================
SELECT '=== BACKUP: Contagem de registros ANTES ===' as info;

SELECT 
    'video_progress' as tabela,
    COUNT(*) as total_registros,
    COUNT(DISTINCT user_id) as usuarios_unicos
FROM video_progress

UNION ALL

SELECT 
    'users_stats' as tabela,
    COUNT(*) as total_registros,
    COUNT(DISTINCT user_id) as usuarios_unicos
FROM users_stats

UNION ALL

SELECT 
    'user_xp' as tabela,
    COUNT(*) as total_registros,
    COUNT(DISTINCT user_id) as usuarios_unicos
FROM user_xp;

-- ============================================================================
-- 🔄 PASSO 2: MIGRAR DADOS DE user_xp PARA users_stats (SE NECESSÁRIO)
-- ============================================================================
SELECT '=== MIGRAÇÃO: user_xp → users_stats ===' as info;

-- Atualizar users_stats com dados de user_xp onde users_stats tem valores menores
UPDATE users_stats us
SET 
    total_xp = GREATEST(us.total_xp, ux.total_xp),
    level = GREATEST(us.level, ux.level),
    streak_days = GREATEST(COALESCE(us.streak_days, 0), COALESCE(ux.current_streak, 0))
FROM user_xp ux
WHERE us.user_id = ux.user_id
    AND (ux.total_xp > us.total_xp OR ux.level > us.level OR ux.current_streak > COALESCE(us.streak_days, 0));

-- Inserir usuários que estão em user_xp mas não em users_stats
INSERT INTO users_stats (
    user_id,
    user_email,
    total_xp,
    level,
    streak_days,
    created_at,
    updated_at
)
SELECT 
    ux.user_id,
    u.email,
    ux.total_xp,
    ux.level,
    ux.current_streak,
    ux.created_at,
    NOW()
FROM user_xp ux
LEFT JOIN users_stats us ON us.user_id = ux.user_id
LEFT JOIN users u ON u.id = ux.user_id
WHERE us.id IS NULL AND u.id IS NOT NULL;

SELECT 'Dados migrados de user_xp para users_stats' as resultado;

-- ============================================================================
-- 🗑️ PASSO 3: REMOVER COLUNAS DUPLICADAS DE video_progress
-- ============================================================================
SELECT '=== LIMPEZA: Removendo colunas duplicadas de video_progress ===' as info;

-- Remover colunas que não pertencem ao progresso individual de vídeo
ALTER TABLE video_progress
    DROP COLUMN IF EXISTS instrument CASCADE,
    DROP COLUMN IF EXISTS module CASCADE,
    DROP COLUMN IF EXISTS completed_lessons CASCADE,
    DROP COLUMN IF EXISTS last_watched_date CASCADE,
    DROP COLUMN IF EXISTS instrument_progress CASCADE;

SELECT 'Colunas duplicadas removidas de video_progress' as resultado;

-- ============================================================================
-- 🗑️ PASSO 4: DELETAR TABELA user_xp (REDUNDANTE)
-- ============================================================================
SELECT '=== LIMPEZA: Removendo tabela user_xp (redundante) ===' as info;

-- Remover foreign keys que referenciam user_xp
DO $$ 
DECLARE
    r RECORD;
BEGIN
    FOR r IN (
        SELECT tc.constraint_name, tc.table_name
        FROM information_schema.table_constraints tc
        JOIN information_schema.constraint_column_usage ccu
            ON tc.constraint_name = ccu.constraint_name
        WHERE ccu.table_name = 'user_xp'
            AND tc.constraint_type = 'FOREIGN KEY'
    ) LOOP
        EXECUTE format('ALTER TABLE %I DROP CONSTRAINT IF EXISTS %I', r.table_name, r.constraint_name);
    END LOOP;
END $$;

-- Deletar a tabela
DROP TABLE IF EXISTS user_xp CASCADE;

SELECT 'Tabela user_xp removida (dados foram migrados para users_stats)' as resultado;

-- ============================================================================
-- 🗑️ PASSO 5: DELETAR TABELA xp_transactions (OPCIONAL)
-- ============================================================================
-- Se você não usa o histórico de transações de XP, pode remover
-- Comente esta seção se quiser manter o histórico

SELECT '=== LIMPEZA: Removendo tabela xp_transactions ===' as info;

-- DROP TABLE IF EXISTS xp_transactions CASCADE;
-- SELECT 'Tabela xp_transactions removida' as resultado;

-- OU mantenha mas limpe referências quebradas
DELETE FROM xp_transactions
WHERE user_id NOT IN (SELECT id FROM users);

SELECT 'Registros órfãos removidos de xp_transactions' as resultado;

-- ============================================================================
-- ✅ PASSO 6: VERIFICAR ESTRUTURA FINAL
-- ============================================================================
SELECT '=== VERIFICAÇÃO: Estrutura final de video_progress ===' as info;

SELECT 
    column_name as "Coluna Restante",
    data_type as "Tipo",
    is_nullable as "NULL?"
FROM information_schema.columns
WHERE table_name = 'video_progress'
ORDER BY ordinal_position;

-- ============================================================================
SELECT '=== VERIFICAÇÃO: Contagem DEPOIS ===' as info;

SELECT 
    'video_progress' as tabela,
    COUNT(*) as total_registros,
    COUNT(DISTINCT user_id) as usuarios_unicos
FROM video_progress

UNION ALL

SELECT 
    'users_stats' as tabela,
    COUNT(*) as total_registros,
    COUNT(DISTINCT user_id) as usuarios_unicos
FROM users_stats;

-- ============================================================================
-- ✅ PASSO 7: RECRIAR ÍNDICES OTIMIZADOS
-- ============================================================================
SELECT '=== OTIMIZAÇÃO: Recriando índices ===' as info;

-- video_progress: manter apenas índices relevantes
DROP INDEX IF EXISTS idx_video_progress_instrument;
DROP INDEX IF EXISTS idx_video_progress_module;

-- Criar/recriar índices essenciais
CREATE INDEX IF NOT EXISTS idx_video_progress_user_id ON video_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_video_progress_video_id ON video_progress(video_id);
CREATE INDEX IF NOT EXISTS idx_video_progress_lesson_id ON video_progress(lesson_id);
CREATE INDEX IF NOT EXISTS idx_video_progress_completed ON video_progress(completed);
CREATE INDEX IF NOT EXISTS idx_video_progress_updated ON video_progress(updated_at DESC);

-- users_stats: índices para ranking e queries
CREATE INDEX IF NOT EXISTS idx_users_stats_user_id ON users_stats(user_id);
CREATE INDEX IF NOT EXISTS idx_users_stats_email ON users_stats(user_email);
CREATE INDEX IF NOT EXISTS idx_users_stats_xp ON users_stats(total_xp DESC);
CREATE INDEX IF NOT EXISTS idx_users_stats_level ON users_stats(level DESC);
CREATE INDEX IF NOT EXISTS idx_users_stats_streak ON users_stats(streak_days DESC);

SELECT 'Índices otimizados criados' as resultado;

-- ============================================================================
-- 📋 PASSO 8: CRIAR VIEW DE COMPATIBILIDADE (OPCIONAL)
-- ============================================================================
SELECT '=== COMPATIBILIDADE: Criando view user_progress_view ===' as info;

-- View para manter compatibilidade com código antigo que usa os campos removidos
CREATE OR REPLACE VIEW user_progress_view AS
SELECT 
    vp.id,
    vp.user_id,
    vp.video_id,
    vp.lesson_id,
    vp.completed,
    vp.progress_percentage,
    vp.last_watched_at,
    vp.watch_count,
    vp.created_at,
    vp.updated_at,
    -- Campos "virtuais" vindos de users_stats
    us.total_xp,
    us.level,
    us.streak_days,
    us.last_study_date,
    us.total_study_time_minutes,
    us.achievements,
    -- Campos que foram removidos (agora NULL ou vazios)
    NULL::text as instrument,
    NULL::text as module,
    '{}'::integer[] as completed_lessons,
    us.last_study_date as last_watched_date,
    '{}'::jsonb as instrument_progress
FROM video_progress vp
LEFT JOIN users_stats us ON us.user_id = vp.user_id;

SELECT 'View de compatibilidade criada: user_progress_view' as resultado;

-- ============================================================================
-- ✅ PASSO 9: ATUALIZAR RLS (ROW LEVEL SECURITY)
-- ============================================================================
SELECT '=== SEGURANÇA: Verificando RLS ===' as info;

-- Garantir que RLS está habilitado
ALTER TABLE video_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE users_stats ENABLE ROW LEVEL SECURITY;

-- Garantir permissões
GRANT SELECT, INSERT, UPDATE, DELETE ON video_progress TO authenticated;
GRANT SELECT, INSERT, UPDATE, DELETE ON users_stats TO authenticated;
GRANT SELECT ON user_progress_view TO authenticated;

SELECT 'RLS e permissões atualizados' as resultado;

-- ============================================================================
-- 📊 PASSO 10: RELATÓRIO FINAL
-- ============================================================================
SELECT '=== RELATÓRIO FINAL ===' as info;

SELECT 
    'video_progress' as "Tabela",
    (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'video_progress') as "Colunas",
    (SELECT COUNT(*) FROM video_progress) as "Registros",
    (SELECT COUNT(DISTINCT user_id) FROM video_progress) as "Usuários"

UNION ALL

SELECT 
    'users_stats' as "Tabela",
    (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'users_stats') as "Colunas",
    (SELECT COUNT(*) FROM users_stats) as "Registros",
    (SELECT COUNT(DISTINCT user_id) FROM users_stats) as "Usuários";

-- ============================================================================
SELECT '=== ✅ LIMPEZA CONCLUÍDA COM SUCESSO! ===' as resultado;
-- ============================================================================

-- PRÓXIMOS PASSOS:
-- 1. Verificar se o código JavaScript precisa ser atualizado
-- 2. Testar funcionalidades de progresso do usuário
-- 3. Verificar se há queries que usam os campos removidos
-- 4. Atualizar documentação do sistema
