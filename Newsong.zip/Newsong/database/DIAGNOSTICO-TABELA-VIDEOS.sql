-- ============================================================================
-- DIAGNÓSTICO COMPLETO: TABELA VIDEOS
-- ============================================================================

-- 📋 1. ESTRUTURA DA TABELA VIDEOS
-- ============================================================================
SELECT '=== ESTRUTURA DA TABELA VIDEOS ===' as info;

SELECT 
    column_name as "Coluna",
    data_type as "Tipo",
    character_maximum_length as "Tamanho",
    column_default as "Padrão",
    is_nullable as "Nulo?",
    ordinal_position as "Ordem"
FROM information_schema.columns
WHERE table_name = 'videos'
ORDER BY ordinal_position;

-- ============================================================================
-- 📊 2. ESTATÍSTICAS GERAIS
-- ============================================================================
SELECT '=== ESTATÍSTICAS GERAIS ===' as info;

SELECT 
    COUNT(*) as total_videos,
    COUNT(DISTINCT uploaded_by) as total_autores,
    COUNT(DISTINCT instrument) as total_instrumentos,
    COUNT(DISTINCT module) as total_modulos,
    COUNT(CASE WHEN is_published = true THEN 1 END) as videos_publicados,
    COUNT(CASE WHEN is_published = false THEN 1 END) as videos_nao_publicados,
    SUM(views) as total_visualizacoes,
    SUM(likes) as total_likes
FROM videos;

-- ============================================================================
-- 📹 3. VÍDEOS POR INSTRUMENTO
-- ============================================================================
SELECT '=== VÍDEOS POR INSTRUMENTO ===' as info;

SELECT 
    COALESCE(instrument, 'Sem instrumento') as instrumento,
    COUNT(*) as quantidade,
    COUNT(CASE WHEN is_published = true THEN 1 END) as publicados,
    SUM(views) as visualizacoes,
    SUM(likes) as curtidas
FROM videos
GROUP BY instrument
ORDER BY quantidade DESC;

-- ============================================================================
-- 📚 4. VÍDEOS POR MÓDULO
-- ============================================================================
SELECT '=== VÍDEOS POR MÓDULO ===' as info;

SELECT 
    COALESCE(module, 'Sem módulo') as modulo,
    COUNT(*) as quantidade,
    COUNT(CASE WHEN is_published = true THEN 1 END) as publicados,
    AVG(views) as media_visualizacoes
FROM videos
GROUP BY module
ORDER BY quantidade DESC;

-- ============================================================================
-- 👥 5. VÍDEOS POR AUTOR
-- ============================================================================
SELECT '=== VÍDEOS POR AUTOR ===' as info;

SELECT 
    u.name as autor,
    u.email,
    u.role as papel,
    COUNT(v.id) as total_videos,
    COUNT(CASE WHEN v.is_published = true THEN 1 END) as publicados,
    SUM(v.views) as total_visualizacoes,
    SUM(v.likes) as total_likes
FROM videos v
LEFT JOIN users u ON v.uploaded_by = u.id
GROUP BY u.id, u.name, u.email, u.role
ORDER BY total_videos DESC;

-- ============================================================================
-- 🔗 6. VÍDEOS COM AULAS (TEXTO)
-- ============================================================================
SELECT '=== VÍDEOS POR AULA ===' as info;

SELECT 
    COUNT(*) as total_videos,
    COUNT(DISTINCT lesson) as aulas_diferentes,
    COUNT(CASE WHEN lesson IS NULL OR lesson = '' THEN 1 END) as videos_sem_aula
FROM videos;

SELECT 
    COALESCE(lesson, 'Sem aula') as aula,
    COUNT(*) as quantidade_videos,
    SUM(views) as total_visualizacoes
FROM videos
GROUP BY lesson
ORDER BY quantidade_videos DESC
LIMIT 10;

-- ============================================================================
-- 📊 7. VÍDEOS MAIS POPULARES
-- ============================================================================
SELECT '=== TOP 10 VÍDEOS MAIS VISTOS ===' as info;

SELECT 
    v.title,
    v.instrument as instrumento,
    v.module as modulo,
    v.lesson as aula,
    v.views as visualizacoes,
    v.likes as curtidas,
    u.name as autor,
    v.created_at as criado_em
FROM videos v
LEFT JOIN users u ON v.uploaded_by = u.id
ORDER BY v.views DESC
LIMIT 10;

-- ============================================================================
-- 🎯 8. TIPO DE UPLOAD
-- ============================================================================
SELECT '=== TIPOS DE UPLOAD ===' as info;

SELECT 
    COALESCE(upload_type, 'Não especificado') as tipo_upload,
    COUNT(*) as quantidade,
    ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM videos), 2) as percentual
FROM videos
GROUP BY upload_type
ORDER BY quantidade DESC;

-- ============================================================================
-- ⚠️ 9. VERIFICAR PROBLEMAS
-- ============================================================================
SELECT '=== VERIFICANDO PROBLEMAS ===' as info;

-- Vídeos sem título
SELECT 'Vídeos sem título' as problema, COUNT(*) as quantidade
FROM videos
WHERE title IS NULL OR title = ''

UNION ALL

-- Vídeos sem URL
SELECT 'Vídeos sem URL' as problema, COUNT(*) as quantidade
FROM videos
WHERE url IS NULL OR url = ''

UNION ALL

-- Vídeos sem autor
SELECT 'Vídeos sem autor (uploaded_by NULL)' as problema, COUNT(*) as quantidade
FROM videos
WHERE uploaded_by IS NULL

UNION ALL

-- Vídeos com autor inexistente
SELECT 'Vídeos com autor inexistente' as problema, COUNT(*) as quantidade
FROM videos v
LEFT JOIN users u ON v.uploaded_by = u.id
WHERE v.uploaded_by IS NOT NULL AND u.id IS NULL

UNION ALL

-- Vídeos sem instrumento
SELECT 'Vídeos sem instrumento' as problema, COUNT(*) as quantidade
FROM videos
WHERE instrument IS NULL OR instrument = '';

-- ============================================================================
-- 📅 10. ATIVIDADE RECENTE
-- ============================================================================
SELECT '=== ÚLTIMOS 10 VÍDEOS CRIADOS ===' as info;

SELECT 
    v.title,
    v.instrument,
    v.module,
    u.name as autor,
    v.uploaded_by_name as nome_uploader,
    v.views as visualizacoes,
    v.is_published as publicado,
    v.created_at as criado_em
FROM videos v
LEFT JOIN users u ON v.uploaded_by = u.id
ORDER BY v.created_at DESC
LIMIT 10;

-- ============================================================================
-- 🔐 11. POLÍTICAS RLS (ROW LEVEL SECURITY)
-- ============================================================================
SELECT '=== POLÍTICAS RLS DA TABELA VIDEOS ===' as info;

SELECT 
    schemaname,
    tablename,
    policyname as "Nome da Política",
    permissive as "Permissivo",
    roles as "Papéis",
    cmd as "Comando",
    qual as "Condição",
    with_check as "Verificação"
FROM pg_policies
WHERE tablename = 'videos';

-- ============================================================================
-- 📑 12. ÍNDICES DA TABELA VIDEOS
-- ============================================================================
SELECT '=== ÍNDICES DA TABELA VIDEOS ===' as info;

SELECT 
    indexname as "Nome do Índice",
    indexdef as "Definição"
FROM pg_indexes
WHERE tablename = 'videos'
ORDER BY indexname;

-- ============================================================================
SELECT '=== ✅ DIAGNÓSTICO COMPLETO! ===' as resultado;
-- ============================================================================
