-- ============================================================================
-- VERIFICAÇÃO E CRIAÇÃO: TABELA USER_PROGRESS
-- ============================================================================

-- 🔍 PASSO 1: Verificar se a tabela existe
-- ============================================================================
SELECT 
    CASE 
        WHEN EXISTS (
            SELECT 1 FROM information_schema.tables 
            WHERE table_schema = 'public' 
            AND table_name = 'user_progress'
        ) THEN '✅ Tabela user_progress EXISTE'
        ELSE '❌ Tabela user_progress NÃO EXISTE'
    END as "Status da Tabela";

-- ============================================================================
-- 🔍 PASSO 2: Listar todas as tabelas do schema public
-- ============================================================================
SELECT 
    table_name as "Tabelas Existentes"
FROM information_schema.tables
WHERE table_schema = 'public'
ORDER BY table_name;

-- ============================================================================
-- 📝 PASSO 3: CRIAR TABELA user_progress (SE NÃO EXISTIR)
-- ============================================================================

-- Tabela para rastrear progresso individual de aulas/vídeos
CREATE TABLE IF NOT EXISTS user_progress (
    id SERIAL PRIMARY KEY,
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    lesson_id INTEGER REFERENCES lessons(id) ON DELETE CASCADE,
    completed BOOLEAN DEFAULT false,
    progress_percentage INTEGER DEFAULT 0 CHECK (progress_percentage >= 0 AND progress_percentage <= 100),
    last_accessed TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    
    -- Constraint para evitar duplicatas
    UNIQUE(user_id, lesson_id)
);

-- Comentários descritivos
COMMENT ON TABLE user_progress IS 'Rastreamento de progresso individual dos usuários em aulas';
COMMENT ON COLUMN user_progress.user_id IS 'Referência ao usuário';
COMMENT ON COLUMN user_progress.lesson_id IS 'Referência à lição/aula';
COMMENT ON COLUMN user_progress.completed IS 'Se a aula foi completada';
COMMENT ON COLUMN user_progress.progress_percentage IS 'Porcentagem de conclusão (0-100)';
COMMENT ON COLUMN user_progress.last_accessed IS 'Última vez que acessou a aula';
COMMENT ON COLUMN user_progress.completed_at IS 'Data/hora de conclusão';

-- ============================================================================
-- 📊 PASSO 4: CRIAR ÍNDICES
-- ============================================================================

CREATE INDEX IF NOT EXISTS idx_progress_user ON user_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_progress_lesson ON user_progress(lesson_id);
CREATE INDEX IF NOT EXISTS idx_progress_completed ON user_progress(completed);
CREATE INDEX IF NOT EXISTS idx_progress_last_accessed ON user_progress(last_accessed DESC);
CREATE INDEX IF NOT EXISTS idx_progress_updated ON user_progress(updated_at DESC);

-- ============================================================================
-- 🔄 PASSO 5: CRIAR TRIGGER para updated_at
-- ============================================================================

-- Função para atualizar updated_at automaticamente
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger para user_progress
DROP TRIGGER IF EXISTS user_progress_updated_at ON user_progress;
CREATE TRIGGER user_progress_updated_at
    BEFORE UPDATE ON user_progress
    FOR EACH ROW
    EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- 🔐 PASSO 6: CONFIGURAR RLS (Row Level Security)
-- ============================================================================

-- Habilitar RLS
ALTER TABLE user_progress ENABLE ROW LEVEL SECURITY;

-- Remover políticas antigas se existirem
DROP POLICY IF EXISTS "users_select_own_progress" ON user_progress;
DROP POLICY IF EXISTS "users_insert_own_progress" ON user_progress;
DROP POLICY IF EXISTS "users_update_own_progress" ON user_progress;
DROP POLICY IF EXISTS "users_delete_own_progress" ON user_progress;

-- SELECT: Usuários podem ver apenas seu próprio progresso
CREATE POLICY "users_select_own_progress"
ON user_progress FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- INSERT: Usuários podem inserir apenas seu próprio progresso
CREATE POLICY "users_insert_own_progress"
ON user_progress FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

-- UPDATE: Usuários podem atualizar apenas seu próprio progresso
CREATE POLICY "users_update_own_progress"
ON user_progress FOR UPDATE
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- DELETE: Usuários podem deletar apenas seu próprio progresso
CREATE POLICY "users_delete_own_progress"
ON user_progress FOR DELETE
TO authenticated
USING (user_id = auth.uid());

-- ============================================================================
-- 🎯 PASSO 7: CONCEDER PERMISSÕES
-- ============================================================================

GRANT SELECT, INSERT, UPDATE, DELETE ON user_progress TO authenticated;
GRANT USAGE, SELECT ON SEQUENCE user_progress_id_seq TO authenticated;

-- ============================================================================
-- ✅ PASSO 8: VERIFICAR CRIAÇÃO
-- ============================================================================

SELECT '=== VERIFICAÇÃO FINAL ===' as info;

-- Verificar estrutura da tabela
SELECT 
    column_name as "Coluna",
    data_type as "Tipo",
    is_nullable as "NULL?",
    column_default as "Padrão"
FROM information_schema.columns
WHERE table_name = 'user_progress'
ORDER BY ordinal_position;

-- Verificar constraints
SELECT
    tc.constraint_name as "Constraint",
    tc.constraint_type as "Tipo",
    kcu.column_name as "Coluna"
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
WHERE tc.table_name = 'user_progress'
ORDER BY tc.constraint_type, tc.constraint_name;

-- Verificar índices
SELECT
    indexname as "Índice",
    indexdef as "Definição"
FROM pg_indexes
WHERE tablename = 'user_progress';

-- Verificar políticas RLS
SELECT 
    policyname as "Política",
    cmd as "Comando",
    roles as "Funções"
FROM pg_policies
WHERE tablename = 'user_progress';

-- ============================================================================
SELECT '=== TABELA user_progress CRIADA E CONFIGURADA COM SUCESSO! ===' as resultado;
-- ============================================================================
