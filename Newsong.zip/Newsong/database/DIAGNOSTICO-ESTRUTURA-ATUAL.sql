-- ============================================================================
-- DIAGNÓSTICO: ESTRUTURA REAL DO BANCO DE DADOS
-- ============================================================================

-- 📊 VERIFICAR ESTRUTURA: video_progress
-- ============================================================================
SELECT '=== ESTRUTURA: video_progress ===' as info;

SELECT 
    column_name as "Coluna",
    data_type as "Tipo",
    is_nullable as "NULL?",
    column_default as "Padrão"
FROM information_schema.columns
WHERE table_name = 'video_progress'
ORDER BY ordinal_position;

-- ============================================================================
-- 📊 VERIFICAR ESTRUTURA: users_stats
-- ============================================================================
SELECT '=== ESTRUTURA: users_stats ===' as info;

SELECT 
    column_name as "Coluna",
    data_type as "Tipo",
    is_nullable as "NULL?",
    column_default as "Padrão"
FROM information_schema.columns
WHERE table_name = 'users_stats'
ORDER BY ordinal_position;

-- ============================================================================
-- 📊 VERIFICAR ESTRUTURA: user_xp
-- ============================================================================
SELECT '=== ESTRUTURA: user_xp ===' as info;

SELECT 
    column_name as "Coluna",
    data_type as "Tipo",
    is_nullable as "NULL?",
    column_default as "Padrão"
FROM information_schema.columns
WHERE table_name = 'user_xp'
ORDER BY ordinal_position;

-- ============================================================================
-- 🔗 VERIFICAR FOREIGN KEYS: video_progress
-- ============================================================================
SELECT '=== FOREIGN KEYS: video_progress ===' as info;

SELECT
    tc.constraint_name as "Constraint",
    kcu.column_name as "Coluna",
    ccu.table_name as "Tabela Ref",
    ccu.column_name as "Coluna Ref"
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage AS ccu
    ON ccu.constraint_name = tc.constraint_name
WHERE tc.table_name = 'video_progress' 
    AND tc.constraint_type = 'FOREIGN KEY';

-- ============================================================================
-- 🔗 VERIFICAR FOREIGN KEYS: users_stats
-- ============================================================================
SELECT '=== FOREIGN KEYS: users_stats ===' as info;

SELECT
    tc.constraint_name as "Constraint",
    kcu.column_name as "Coluna",
    ccu.table_name as "Tabela Ref",
    ccu.column_name as "Coluna Ref"
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage AS ccu
    ON ccu.constraint_name = tc.constraint_name
WHERE tc.table_name = 'users_stats' 
    AND tc.constraint_type = 'FOREIGN KEY';

-- ============================================================================
-- 📈 ESTATÍSTICAS: video_progress
-- ============================================================================
SELECT '=== ESTATÍSTICAS: video_progress ===' as info;

SELECT 
    COUNT(*) as "Total Registros",
    COUNT(DISTINCT user_id) as "Usuários Distintos",
    COUNT(DISTINCT video_id) as "Vídeos Distintos",
    COUNT(CASE WHEN completed = true THEN 1 END) as "Vídeos Completos",
    ROUND(AVG(progress_percentage), 2) as "Progresso Médio %"
FROM video_progress;

-- ============================================================================
-- 📈 ESTATÍSTICAS: users_stats
-- ============================================================================
SELECT '=== ESTATÍSTICAS: users_stats ===' as info;

SELECT 
    COUNT(*) as "Total Usuários",
    MIN(total_xp) as "XP Mínimo",
    MAX(total_xp) as "XP Máximo",
    ROUND(AVG(total_xp), 2) as "XP Médio",
    MIN(level) as "Level Mínimo",
    MAX(level) as "Level Máximo",
    MAX(streak_days) as "Maior Streak"
FROM users_stats;

-- ============================================================================
-- 👥 AMOSTRA: video_progress (Top 10)
-- ============================================================================
SELECT '=== AMOSTRA: video_progress ===' as info;

SELECT 
    vp.id,
    u.email as "Usuário",
    v."Titulo" as "Vídeo",
    vp.progress_percentage as "Progresso %",
    vp.completed as "Completo",
    vp.updated_at as "Atualizado em"
FROM video_progress vp
LEFT JOIN users u ON vp.user_id = u.id
LEFT JOIN videos v ON vp.video_id = v.id
ORDER BY vp.updated_at DESC NULLS LAST
LIMIT 10;

-- ============================================================================
-- 👥 AMOSTRA: users_stats (Top 10 por XP)
-- ============================================================================
SELECT '=== AMOSTRA: users_stats (Top 10 XP) ===' as info;

SELECT 
    u.email as "Usuário",
    us.total_xp as "XP",
    us.level as "Level",
    us.streak_days as "Streak",
    us.total_study_time_minutes as "Tempo Estudo (min)",
    us.updated_at as "Atualizado"
FROM users_stats us
LEFT JOIN users u ON us.user_id = u.id
ORDER BY us.total_xp DESC
LIMIT 10;

-- ============================================================================
-- ❌ VERIFICAR PROBLEMAS: Registros Órfãos video_progress
-- ============================================================================
SELECT '=== VERIFICAR ÓRFÃOS: video_progress ===' as info;

SELECT 
    COUNT(*) as "Total",
    COUNT(CASE WHEN u.id IS NOT NULL THEN 1 END) as "✅ User Válido",
    COUNT(CASE WHEN u.id IS NULL THEN 1 END) as "❌ User Inválido",
    COUNT(CASE WHEN v.id IS NOT NULL THEN 1 END) as "✅ Vídeo Válido",
    COUNT(CASE WHEN v.id IS NULL THEN 1 END) as "❌ Vídeo Inválido"
FROM video_progress vp
LEFT JOIN users u ON vp.user_id = u.id
LEFT JOIN videos v ON vp.video_id = v.id;

-- ============================================================================
-- ❌ VERIFICAR PROBLEMAS: users_stats sem user_id válido
-- ============================================================================
SELECT '=== VERIFICAR ÓRFÃOS: users_stats ===' as info;

SELECT 
    COUNT(*) as "Total Stats",
    COUNT(CASE WHEN u.id IS NOT NULL THEN 1 END) as "✅ User Válido",
    COUNT(CASE WHEN u.id IS NULL THEN 1 END) as "❌ User Inválido"
FROM users_stats us
LEFT JOIN users u ON us.user_id = u.id;

-- ============================================================================
-- 🔍 VERIFICAR: Usuários sem stats
-- ============================================================================
SELECT '=== USUÁRIOS SEM STATS ===' as info;

SELECT 
    u.id,
    u.email,
    u.role,
    u.created_at
FROM users u
LEFT JOIN users_stats us ON us.user_id = u.id
WHERE us.id IS NULL
ORDER BY u.created_at DESC
LIMIT 10;

-- ============================================================================
SELECT '=== FIM DO DIAGNÓSTICO ESTRUTURAL ===' as resultado;
-- ============================================================================
