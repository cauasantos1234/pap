-- ============================================
-- NEWSONG PLATFORM - DELETAR VÍDEOS DE TESTE
-- Remove todos os vídeos de teste do banco
-- Data: 03/02/2026
-- ============================================

-- ⚠️ ATENÇÃO: Este script irá deletar TODOS os vídeos existentes
-- Execute apenas se tiver certeza que deseja remover os vídeos de teste

BEGIN;

-- 1. Deletar primeiro os dados relacionados aos vídeos
DELETE FROM video_views;
DELETE FROM saved_videos;
DELETE FROM comments WHERE video_id IS NOT NULL;
DELETE FROM user_progress;

-- 2. Deletar os vídeos
DELETE FROM videos;

-- 3. Resetar a sequência dos IDs (opcional)
ALTER SEQUENCE videos_id_seq RESTART WITH 1;
ALTER SEQUENCE video_views_id_seq RESTART WITH 1;
ALTER SEQUENCE saved_videos_id_seq RESTART WITH 1;
ALTER SEQUENCE user_progress_id_seq RESTART WITH 1;

COMMIT;

-- ============================================
-- VERIFICAÇÃO
-- Executar para confirmar que não há mais vídeos
-- ============================================
SELECT 'Vídeos restantes:' as status, COUNT(*) as total FROM videos;
SELECT 'Visualizações restantes:' as status, COUNT(*) as total FROM video_views;
SELECT 'Vídeos salvos restantes:' as status, COUNT(*) as total FROM saved_videos;
SELECT 'Progresso restante:' as status, COUNT(*) as total FROM user_progress;

-- ============================================
-- RESULTADO ESPERADO
-- ============================================
-- Todas as queries acima devem retornar 0
-- Banco pronto para receber novos vídeos
