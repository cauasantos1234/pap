-- ============================================================================
-- SOLUÇÃO COMPLETA: Correção da Base de Dados de Progresso
-- ============================================================================
-- Este script limpa duplicações e consolida as tabelas corretamente
-- IMPORTANTE: Faça backup antes de executar!
-- ============================================================================

-- 📊 PASSO 1: BACKUP - Verificar estado atual
-- ============================================================================
SELECT '=== BACKUP: Contagem de registros ANTES ===' as info;

SELECT 
    'video_progress' as tabela,
    COUNT(*) as total_registros,
    COUNT(DISTINCT user_id) as usuarios_unicos
FROM video_progress

UNION ALL

SELECT 
    'users_stats' as tabela,
    COUNT(*) as total_registros,
    COUNT(DISTINCT user_id) as usuarios_unicos
FROM users_stats

UNION ALL

SELECT 
    'user_xp' as tabela,
    COUNT(*) as total_registros,
    COUNT(DISTINCT user_id) as usuarios_unicos
FROM user_xp;

-- ============================================================================
-- 🔄 PASSO 2: CONSOLIDAR user_xp em users_stats
-- ============================================================================
SELECT '=== CONSOLIDANDO: user_xp → users_stats ===' as info;

-- Atualizar users_stats com valores maiores de user_xp
UPDATE users_stats us
SET 
    total_xp = GREATEST(us.total_xp, ux.total_xp),
    level = GREATEST(us.level, ux.level),
    streak_days = GREATEST(COALESCE(us.streak_days, 0), COALESCE(ux.current_streak, 0)),
    updated_at = NOW()
FROM user_xp ux
WHERE us.user_id = ux.user_id
    AND (ux.total_xp > us.total_xp OR ux.level > us.level OR ux.current_streak > COALESCE(us.streak_days, 0));

-- Inserir usuários que existem em user_xp mas não em users_stats
INSERT INTO users_stats (
    user_id,
    user_email,
    total_xp,
    level,
    streak_days,
    created_at,
    updated_at
)
SELECT 
    ux.user_id,
    u.email,
    ux.total_xp,
    ux.level,
    COALESCE(ux.current_streak, 0),
    ux.created_at,
    NOW()
FROM user_xp ux
JOIN users u ON u.id = ux.user_id
LEFT JOIN users_stats us ON us.user_id = ux.user_id
WHERE us.id IS NULL;

SELECT 'Dados consolidados de user_xp em users_stats' as resultado;

-- ============================================================================
-- 🔄 PASSO 3: MIGRAR completed_lessons de video_progress para users_stats
-- ============================================================================
SELECT '=== MIGRANDO: completed_lessons para users_stats ===' as info;

-- Adicionar coluna se não existir
ALTER TABLE users_stats 
ADD COLUMN IF NOT EXISTS completed_lessons INTEGER[] DEFAULT '{}';

-- Pegar o array mais completo de cada usuário e salvar em users_stats
UPDATE users_stats us
SET 
    completed_lessons = COALESCE(
        (
            SELECT vp.completed_lessons
            FROM video_progress vp
            WHERE vp.user_id = us.user_id
                AND vp.completed_lessons IS NOT NULL
                AND array_length(vp.completed_lessons, 1) IS NOT NULL
            ORDER BY array_length(vp.completed_lessons, 1) DESC NULLS LAST
            LIMIT 1
        ),
        '{}'
    ),
    updated_at = NOW()
WHERE us.user_id IN (SELECT DISTINCT user_id FROM video_progress WHERE completed_lessons IS NOT NULL);

SELECT 'Migrado completed_lessons para users_stats' as resultado;

-- ============================================================================
-- 🔄 PASSO 4: MIGRAR instrument_progress de video_progress para users_stats
-- ============================================================================
SELECT '=== MIGRANDO: instrument_progress para users_stats ===' as info;

-- Adicionar coluna se não existir
ALTER TABLE users_stats 
ADD COLUMN IF NOT EXISTS instrument_progress JSONB DEFAULT '{}';

-- Pegar o JSON mais completo de cada usuário
UPDATE users_stats us
SET 
    instrument_progress = COALESCE(
        (
            SELECT vp.instrument_progress
            FROM video_progress vp
            WHERE vp.user_id = us.user_id
                AND vp.instrument_progress IS NOT NULL
                AND vp.instrument_progress::text != '{}'
            ORDER BY jsonb_object_keys(vp.instrument_progress) DESC
            LIMIT 1
        ),
        '{}'::jsonb
    ),
    updated_at = NOW()
WHERE us.user_id IN (SELECT DISTINCT user_id FROM video_progress WHERE instrument_progress IS NOT NULL);

SELECT 'Migrado instrument_progress para users_stats' as resultado;

-- ============================================================================
-- 🗑️ PASSO 5: REMOVER COLUNAS DUPLICADAS de video_progress
-- ============================================================================
SELECT '=== LIMPANDO: Removendo colunas duplicadas ===' as info;

ALTER TABLE video_progress
    DROP COLUMN IF EXISTS instrument CASCADE,
    DROP COLUMN IF EXISTS module CASCADE,
    DROP COLUMN IF EXISTS completed_lessons CASCADE,
    DROP COLUMN IF EXISTS last_watched_date CASCADE,
    DROP COLUMN IF EXISTS instrument_progress CASCADE;

SELECT 'Colunas duplicadas removidas de video_progress' as resultado;

-- ============================================================================
-- 🗑️ PASSO 6: REMOVER TABELA user_xp (agora redundante)
-- ============================================================================
SELECT '=== REMOVENDO: Tabela user_xp redundante ===' as info;

-- Remover foreign keys que referenciam user_xp
DO $$ 
DECLARE
    r RECORD;
BEGIN
    FOR r IN (
        SELECT tc.constraint_name, tc.table_name
        FROM information_schema.table_constraints tc
        JOIN information_schema.constraint_column_usage ccu
            ON tc.constraint_name = ccu.constraint_name
        WHERE ccu.table_name = 'user_xp'
            AND tc.constraint_type = 'FOREIGN KEY'
    ) LOOP
        EXECUTE format('ALTER TABLE %I DROP CONSTRAINT IF EXISTS %I CASCADE', r.table_name, r.constraint_name);
    END LOOP;
END $$;

-- Deletar a tabela
DROP TABLE IF EXISTS user_xp CASCADE;

SELECT 'Tabela user_xp removida' as resultado;

-- ============================================================================
-- 🧹 PASSO 7: LIMPAR xp_transactions órfãos (opcional)
-- ============================================================================
SELECT '=== LIMPANDO: Registros órfãos de xp_transactions ===' as info;

DELETE FROM xp_transactions
WHERE user_id NOT IN (SELECT id FROM users);

SELECT 'Registros órfãos removidos de xp_transactions' as resultado;

-- ============================================================================
-- 📊 PASSO 8: CRIAR ÍNDICES OTIMIZADOS
-- ============================================================================
SELECT '=== OTIMIZANDO: Criando índices ===' as info;

-- Remover índices antigos desnecessários
DROP INDEX IF EXISTS idx_video_progress_instrument;
DROP INDEX IF EXISTS idx_video_progress_module;

-- video_progress: índices essenciais
CREATE INDEX IF NOT EXISTS idx_video_progress_user_id ON video_progress(user_id);
CREATE INDEX IF NOT EXISTS idx_video_progress_video_id ON video_progress(video_id);
CREATE INDEX IF NOT EXISTS idx_video_progress_lesson_id ON video_progress(lesson_id) WHERE lesson_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_video_progress_completed ON video_progress(completed);
CREATE INDEX IF NOT EXISTS idx_video_progress_updated ON video_progress(updated_at DESC);

-- users_stats: índices para ranking e queries
CREATE INDEX IF NOT EXISTS idx_users_stats_user_id ON users_stats(user_id);
CREATE INDEX IF NOT EXISTS idx_users_stats_email ON users_stats(user_email);
CREATE INDEX IF NOT EXISTS idx_users_stats_xp ON users_stats(total_xp DESC);
CREATE INDEX IF NOT EXISTS idx_users_stats_level ON users_stats(level DESC);
CREATE INDEX IF NOT EXISTS idx_users_stats_streak ON users_stats(streak_days DESC);

SELECT 'Índices otimizados' as resultado;

-- ============================================================================
-- 🔐 PASSO 9: CONFIGURAR RLS para users_stats
-- ============================================================================
SELECT '=== SEGURANÇA: Configurando RLS ===' as info;

-- Habilitar RLS
ALTER TABLE users_stats ENABLE ROW LEVEL SECURITY;

-- Remover políticas antigas
DROP POLICY IF EXISTS "users_select_own_stats" ON users_stats;
DROP POLICY IF EXISTS "users_insert_own_stats" ON users_stats;
DROP POLICY IF EXISTS "users_update_own_stats" ON users_stats;
DROP POLICY IF EXISTS "users_delete_own_stats" ON users_stats;

-- SELECT: Usuários autenticados podem ver qualquer stats (para ranking)
CREATE POLICY "users_select_stats"
ON users_stats FOR SELECT
TO authenticated
USING (true);

-- INSERT: Apenas próprio stats
CREATE POLICY "users_insert_own_stats"
ON users_stats FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

-- UPDATE: Apenas próprio stats
CREATE POLICY "users_update_own_stats"
ON users_stats FOR UPDATE
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- DELETE: Apenas próprio stats
CREATE POLICY "users_delete_own_stats"
ON users_stats FOR DELETE
TO authenticated
USING (user_id = auth.uid());

-- Garantir permissões
GRANT SELECT, INSERT, UPDATE, DELETE ON users_stats TO authenticated;

-- Conceder permissão na sequência apenas se existir (tabelas com SERIAL)
DO $$
BEGIN
    IF EXISTS (
        SELECT 1 FROM pg_class WHERE relname = 'users_stats_id_seq' AND relkind = 'S'
    ) THEN
        GRANT USAGE, SELECT ON SEQUENCE users_stats_id_seq TO authenticated;
    END IF;
END $$;

SELECT 'RLS configurado para users_stats' as resultado;

-- ============================================================================
-- ✅ PASSO 10: VERIFICAR ESTRUTURA FINAL
-- ============================================================================
SELECT '=== VERIFICAÇÃO: Estrutura final ===' as info;

-- Estrutura video_progress
SELECT 
    'video_progress' as tabela,
    column_name as coluna,
    data_type as tipo
FROM information_schema.columns
WHERE table_name = 'video_progress'
ORDER BY ordinal_position;

-- Estrutura users_stats
SELECT 
    'users_stats' as tabela,
    column_name as coluna,
    data_type as tipo
FROM information_schema.columns
WHERE table_name = 'users_stats'
ORDER BY ordinal_position;

-- ============================================================================
SELECT '=== VERIFICAÇÃO: Contagem DEPOIS ===' as info;

SELECT 
    'video_progress' as tabela,
    COUNT(*) as total_registros,
    COUNT(DISTINCT user_id) as usuarios_unicos,
    (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'video_progress') as colunas
FROM video_progress

UNION ALL

SELECT 
    'users_stats' as tabela,
    COUNT(*) as total_registros,
    COUNT(DISTINCT user_id) as usuarios_unicos,
    (SELECT COUNT(*) FROM information_schema.columns WHERE table_name = 'users_stats') as colunas
FROM users_stats;

-- ============================================================================
-- 📋 PASSO 11: RELATÓRIO FINAL
-- ============================================================================
SELECT '=== RELATÓRIO FINAL ===' as info;

SELECT 
    '✅ video_progress' as "Status",
    'Limpo - apenas progresso individual' as "Descrição",
    (SELECT COUNT(*) FROM video_progress) as "Registros"

UNION ALL

SELECT 
    '✅ users_stats' as "Status",
    'Consolidado - XP, Level, Streak, Achievements, Completed Lessons, Instrument Progress' as "Descrição",
    (SELECT COUNT(*) FROM users_stats) as "Registros"

UNION ALL

SELECT 
    '✅ user_xp' as "Status",
    'Removido - dados migrados para users_stats' as "Descrição",
    0 as "Registros";

-- ============================================================================
SELECT '=== ✅ CORREÇÃO CONCLUÍDA COM SUCESSO! ===' as resultado;
-- ============================================================================

/*
PRÓXIMOS PASSOS:

1. ✅ Banco de dados corrigido
2. ⚠️ Atualizar código JavaScript (public/js/supabase-progress.js)
3. ⚠️ Testar funcionalidades de progresso
4. ⚠️ Verificar se há outros arquivos que usam as colunas removidas

Execute o script JavaScript a seguir para corrigir o código frontend.
*/
