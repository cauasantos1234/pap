-- ============================================================================
-- DIAGNÓSTICO COMPLETO: PROGRESSO DO USUÁRIO
-- Execute este script no Supabase SQL Editor para verificar o estado atual
-- ============================================================================

-- 📊 SEÇÃO 1: ESTRUTURA DA TABELA
-- ============================================================================
SELECT '=== ESTRUTURA DA TABELA USER_PROGRESS ===' as info;

SELECT 
    column_name as "Coluna",
    data_type as "Tipo",
    is_nullable as "Aceita NULL",
    column_default as "Valor Padrão"
FROM information_schema.columns
WHERE table_name = 'user_progress'
ORDER BY ordinal_position;

-- ============================================================================

-- 🔗 SEÇÃO 2: FOREIGN KEYS E CONSTRAINTS
-- ============================================================================
SELECT '=== FOREIGN KEYS ===' as info;

SELECT
    tc.constraint_name as "Nome Constraint",
    kcu.column_name as "Coluna",
    ccu.table_name as "Tabela Referenciada",
    ccu.column_name as "Coluna Referenciada"
FROM information_schema.table_constraints AS tc
JOIN information_schema.key_column_usage AS kcu
    ON tc.constraint_name = kcu.constraint_name
JOIN information_schema.constraint_column_usage AS ccu
    ON ccu.constraint_name = tc.constraint_name
WHERE tc.table_name = 'user_progress' 
    AND tc.constraint_type = 'FOREIGN KEY';

-- ============================================================================

-- 📈 SEÇÃO 3: ESTATÍSTICAS GERAIS
-- ============================================================================
SELECT '=== ESTATÍSTICAS GERAIS ===' as info;

SELECT 
    COUNT(*) as "Total Registros",
    COUNT(DISTINCT user_id) as "Usuários com Progresso",
    COUNT(CASE WHEN user_id IS NULL THEN 1 END) as "⚠️ Registros sem user_id",
    COUNT(DISTINCT lesson_id) as "Lições com Progresso",
    COUNT(CASE WHEN completed = true THEN 1 END) as "Aulas Completadas",
    ROUND(AVG(progress_percentage), 2) as "Progresso Médio %",
    MIN(created_at) as "Primeiro Registro",
    MAX(last_accessed) as "Última Atividade"
FROM user_progress;

-- ============================================================================

-- 👥 SEÇÃO 4: PROGRESSO POR USUÁRIO
-- ============================================================================
SELECT '=== PROGRESSO POR USUÁRIO (TOP 10) ===' as info;

SELECT 
    u.email as "Email",
    u.role as "Função",
    COUNT(up.id) as "Aulas Assistidas",
    COUNT(CASE WHEN up.completed THEN 1 END) as "Aulas Completas",
    ROUND(AVG(up.progress_percentage), 2) as "Progresso Médio %",
    MAX(up.last_accessed) as "Última Atividade"
FROM users u
LEFT JOIN user_progress up ON up.user_id = u.id
GROUP BY u.id, u.email, u.role
HAVING COUNT(up.id) > 0
ORDER BY COUNT(up.id) DESC
LIMIT 10;

-- ============================================================================

-- ❌ SEÇÃO 5: REGISTROS ÓRFÃOS (PROBLEMAS)
-- ============================================================================
SELECT '=== VERIFICAÇÃO DE REGISTROS ÓRFÃOS ===' as info;

SELECT 
    COUNT(*) as "Total Progressos",
    COUNT(CASE WHEN u.id IS NOT NULL THEN 1 END) as "✅ Usuário Válido",
    COUNT(CASE WHEN u.id IS NULL THEN 1 END) as "❌ Usuário Inválido",
    COUNT(CASE WHEN l.id IS NOT NULL THEN 1 END) as "✅ Lição Válida",
    COUNT(CASE WHEN l.id IS NULL AND up.lesson_id IS NOT NULL THEN 1 END) as "❌ Lição Inválida"
FROM user_progress up
LEFT JOIN users u ON up.user_id = u.id
LEFT JOIN lessons l ON up.lesson_id = l.id;

-- ============================================================================

-- 🔍 SEÇÃO 6: DETALHES DOS REGISTROS ÓRFÃOS
-- ============================================================================
SELECT '=== DETALHES DOS REGISTROS ÓRFÃOS ===' as info;

SELECT 
    up.id as "ID",
    up.user_id as "User ID",
    up.lesson_id as "Lesson ID",
    up.progress_percentage as "Progresso %",
    up.completed as "Completo",
    CASE 
        WHEN u.id IS NULL THEN '❌ Usuário não existe'
        ELSE '✅ Usuário OK'
    END as "Status Usuário",
    CASE 
        WHEN l.id IS NULL AND up.lesson_id IS NOT NULL THEN '❌ Lição não existe'
        WHEN up.lesson_id IS NULL THEN '⚠️ Lesson ID NULL'
        ELSE '✅ Lição OK'
    END as "Status Lição",
    up.last_accessed as "Última Acesso"
FROM user_progress up
LEFT JOIN users u ON up.user_id = u.id
LEFT JOIN lessons l ON up.lesson_id = l.id
WHERE u.id IS NULL OR (l.id IS NULL AND up.lesson_id IS NOT NULL)
ORDER BY up.last_accessed DESC
LIMIT 20;

-- ============================================================================

-- 🔁 SEÇÃO 7: REGISTROS DUPLICADOS
-- ============================================================================
SELECT '=== REGISTROS DUPLICADOS (user_id + lesson_id) ===' as info;

SELECT 
    user_id,
    lesson_id,
    COUNT(*) as "Duplicatas",
    STRING_AGG(id::text, ', ') as "IDs Duplicados"
FROM user_progress
WHERE lesson_id IS NOT NULL
GROUP BY user_id, lesson_id
HAVING COUNT(*) > 1
LIMIT 10;

-- ============================================================================

-- 🔐 SEÇÃO 8: POLÍTICAS RLS (ROW LEVEL SECURITY)
-- ============================================================================
SELECT '=== POLÍTICAS RLS ATIVAS ===' as info;

SELECT 
    schemaname as "Schema",
    tablename as "Tabela",
    policyname as "Nome da Política",
    permissive as "Permissiva",
    roles as "Funções",
    cmd as "Comando",
    qual as "Condição"
FROM pg_policies
WHERE tablename = 'user_progress';

-- ============================================================================

-- ✅ SEÇÃO 9: ÍNDICES
-- ============================================================================
SELECT '=== ÍNDICES DA TABELA ===' as info;

SELECT
    indexname as "Nome do Índice",
    indexdef as "Definição"
FROM pg_indexes
WHERE tablename = 'user_progress';

-- ============================================================================

-- 📋 SEÇÃO 10: ÚLTIMOS 20 REGISTROS
-- ============================================================================
SELECT '=== ÚLTIMOS 20 REGISTROS ===' as info;

SELECT 
    up.id as "ID",
    u.email as "Usuário",
    l.title as "Aula",
    up.progress_percentage as "Progresso %",
    up.completed as "Completo",
    up.last_accessed as "Último Acesso",
    up.created_at as "Criado em"
FROM user_progress up
LEFT JOIN users u ON up.user_id = u.id
LEFT JOIN lessons l ON up.lesson_id = l.id
ORDER BY up.last_accessed DESC NULLS LAST
LIMIT 20;

-- ============================================================================

-- 💡 SEÇÃO 11: RECOMENDAÇÕES
-- ============================================================================
SELECT '=== ANÁLISE E RECOMENDAÇÕES ===' as info;

SELECT 
    CASE 
        WHEN COUNT(CASE WHEN up.user_id IS NULL THEN 1 END) > 0 
        THEN '❌ PROBLEMA: Existem registros sem user_id (órfãos)'
        ELSE '✅ OK: Todos os registros têm user_id válido'
    END as "Check 1: user_id"
FROM user_progress up;

SELECT 
    CASE 
        WHEN COUNT(*) > 0 
        THEN '❌ PROBLEMA: Existem usuários inválidos em user_progress'
        ELSE '✅ OK: Todos os user_id referenciam usuários válidos'
    END as "Check 2: Referências de Usuários"
FROM user_progress up
LEFT JOIN users u ON up.user_id = u.id
WHERE u.id IS NULL;

SELECT 
    CASE 
        WHEN COUNT(*) > 0 
        THEN '⚠️ AVISO: Existem lições inválidas em user_progress'
        ELSE '✅ OK: Todos os lesson_id referenciam lições válidas'
    END as "Check 3: Referências de Lições"
FROM user_progress up
LEFT JOIN lessons l ON up.lesson_id = l.id
WHERE up.lesson_id IS NOT NULL AND l.id IS NULL;

SELECT 
    CASE 
        WHEN COUNT(*) > 0 
        THEN '❌ PROBLEMA: Existem registros duplicados (mesmo usuário + lição)'
        ELSE '✅ OK: Não há duplicatas'
    END as "Check 4: Duplicatas"
FROM (
    SELECT user_id, lesson_id, COUNT(*) as cnt
    FROM user_progress
    WHERE lesson_id IS NOT NULL
    GROUP BY user_id, lesson_id
    HAVING COUNT(*) > 1
) duplicatas;

-- ============================================================================
SELECT '=== FIM DO DIAGNÓSTICO ===' as info;
-- ============================================================================
